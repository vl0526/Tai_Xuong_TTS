
import os
import json
import time
import threading
from enum import Enum
from pathlib import Path
from PyQt6.QtCore import (
    Qt, QPoint, QPointF, QRect, QRectF, QSize, QTimer, QElapsedTimer, QUrl, QBuffer, QByteArray, QIODevice,
    pyqtSignal, pyqtProperty, pyqtSlot, QObject,
    QPropertyAnimation, QParallelAnimationGroup, QVariantAnimation, QEasingCurve, QEvent, QThread,
    QAbstractAnimation
)
from PyQt6.QtGui import (
    QPainter, QPainterPath, QColor, QLinearGradient, QRadialGradient, QPen, QBrush, QFont, QGuiApplication, QRegion, QGradient, QDesktopServices
)
from PyQt6.QtWidgets import QWidget, QLabel, QApplication, QStackedWidget, QGraphicsOpacityEffect, QVBoxLayout, QHBoxLayout, QSlider, QProgressBar, QListView, QListWidget, QListWidgetItem, QComboBox, QTextEdit, QLineEdit, QFileDialog, QFrame, QScrollArea, QScrollBar, QSizePolicy

from App.theme import THEME, accent_color, PRESETS
from App.liquid_glass import paint_liquid_glass, paint_metal_panel, paint_metal_button, metal_tone
from App.core import _SVG_CLOSE, _SVG_MINIMIZE, _SVG_PLAY_FILLED, _SVG_BOLT, _SVG_SAVE, _SVG_FOLDER, _SVG_FOLDER_OPEN, _SVG_SETTINGS, _SVG_BACK, _SVG_SUBTITLE, _SVG_SPEECH, _SVG_INFO, _icon, is_srt_nonempty, read_subtitle_lines, play_droplet, play_ting, init_sound_effects, apply_app_css, app_icon
from Speech.tiktok_engine import TIKTOK_VOICE_MAP
from Speech.inworld_engine import (
    INWORLD_VOICE_LABELS,
    DEFAULT_INWORLD_LABEL,
)

# Nha cung cap TTS. "TikTok" giu nguyen 100% dong cu; "Inworld" dung network
# TTS sieu don gian rieng (Speech/inworld_engine.py).
PROVIDERS = ["TikTok", "Inworld"]


def _voice_items_for_provider(provider: str):
    if provider == "Inworld":
        return list(INWORLD_VOICE_LABELS)
    return list(TIKTOK_VOICE_MAP.keys())

# Pause: hai thanh bo goc tron, dong bo phong cach voi _SVG_PLAY_FILLED.
_SVG_PAUSE = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#FFFFFF" stroke="#FFFFFF" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round">'
    '<rect x="6.5" y="4.5" width="4" height="15" rx="1.4"/>'
    '<rect x="13.5" y="4.5" width="4" height="15" rx="1.4"/>'
    '</svg>'
)

# Update (Cap nhat): hai mui ten xoay vong tron - bieu tuong dong bo/refresh cao cap.
_SVG_UPDATE = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round">'
    '<path d="M20.5 11a8.5 8.5 0 0 0-14.6-5.1L3 8.5"/>'
    '<polyline points="3 3.5 3 8.5 8 8.5"/>'
    '<path d="M3.5 13a8.5 8.5 0 0 0 14.6 5.1L21 15.5"/>'
    '<polyline points="21 20.5 21 15.5 16 15.5"/>'
    '</svg>'
)

def normalize_text(text):
    import re as _re
    if not text:
        return text
    text = _re.sub(r"[ \t]+", " ", text)
    text = _re.sub(r" *\n *", "\n", text).strip()
    text = _re.sub(r"\s+([,.;:!?…])", r"\1", text)
    def _up(m):
        return m.group(1) + m.group(2).upper()
    text = _re.sub(r"(^|[.!?…]\s+|\n\s*)([a-zà-ỹ])", _up, text)
    return text

_ACCENT_WIDGETS = []

def _apply_accent_tokens(template):
    _b = THEME.bright()
    br, bg, bb = _b.red(), _b.green(), _b.blue()
    bhex = THEME.bright_hex()
    btx = THEME.bright_text_hex()
    return (template
            .replace("__ACCT__", btx)
            .replace("__ACCSOFT__", "rgba(%d,%d,%d,0.55)" % (br, bg, bb))
            .replace("__ACC6__", bhex[1:])
            .replace("__ACC__", bhex))

def _styled(widget, template):
    _ACCENT_WIDGETS.append((widget, template))
    widget.setStyleSheet(_apply_accent_tokens(template))
    return widget

def _restyle_accent_widgets():
    alive = []
    for w, t in _ACCENT_WIDGETS:
        try:
            w.setStyleSheet(_apply_accent_tokens(t))
            alive.append((w, t))
        except RuntimeError:
            pass
    _ACCENT_WIDGETS[:] = alive

def _repaint_all():
    try:
        app = QApplication.instance()
        if app is None:
            return
        for top in app.topLevelWidgets():
            top.update()
            for child in top.findChildren(QWidget):
                child.update()
    except Exception:
        pass

try:
    THEME.themeChanged.connect(_restyle_accent_widgets)
    THEME.themeChanged.connect(_repaint_all)
except Exception:
    pass

class _GradientDriver(QObject):
    """Bo dieu phoi Gradient tu doi mau - 60fps, anti-lag.

    Mỗi frame trang trí mặc định ~33ms để giữ UI mượt mà không ăn CPU khi TTS chạy.
    Stylesheet (combo arrow, scrollbar...) chi refresh ~10fps de khong nghen.
    """
    def __init__(self):
        super().__init__()
        self._timer = QTimer(self)
        self._timer.setInterval(int(os.environ.get("INTRO_PRO_UI_FRAME_MS", "16")))  # ~60 FPS default
        self._timer.setTimerType(Qt.TimerType.PreciseTimer)
        self._timer.timeout.connect(self._tick)
        self._clock = QElapsedTimer()
        self._targets = []
        self._cache_accum = 0.0
        self._busy = 0
        try:
            THEME.themeChanged.connect(self._sync)
        except Exception:
            pass
        self._sync()

    def _sync(self):
        try:
            on = THEME.gradient()
        except Exception:
            on = False
        if on and not self._busy and not self._timer.isActive():
            self._targets = []
            self._cache_accum = 0.0
            self._clock.restart()
            self._timer.start()
        elif not on and self._timer.isActive():
            self._timer.stop()
            self._targets = []
            # Tat gradient: dong bo stylesheet DUNG 1 LAN (khong lam moi lien tuc).
            try:
                apply_app_css(); _restyle_accent_widgets()
            except Exception:
                pass

    def set_busy(self, on):
        if on:
            self._busy += 1
        else:
            self._busy = max(0, self._busy - 1)
        if self._busy > 0:
            if self._timer.isActive():
                self._timer.stop()
                self._targets = []
        else:
            self._sync()

    def eventFilter(self, obj, event):
        try:
            if event.type() in (QEvent.Type.Resize, QEvent.Type.Show):
                self._cache_accum = 1000.0
        except Exception:
            pass
        return False

    def _refresh_targets(self):
        # Chi cache widget DANG HIEN & DANG LO TREN MAN HINH -> bo qua phan bi che/cuon khuat.
        targets = []
        try:
            app = QApplication.instance()
            if app is not None:
                for top in app.topLevelWidgets():
                    if not top.isVisible():
                        continue
                    for w in [top] + top.findChildren(QWidget):
                        try:
                            if w.isVisible() and not w.visibleRegion().isEmpty():
                                targets.append(w)
                                try:
                                    w.installEventFilter(self)
                                except Exception:
                                    pass
                        except RuntimeError:
                            pass
        except Exception:
            targets = []
        self._targets = targets

    def _tick(self):
        # THUAT TOAN MOI: dua tren THOI GIAN THUC (delta-time) -> muot deu o moi may,
        # khong giat ngay ca khi timer bi tre. Mau xoay ~40 do/giay (1 vong ~9s).
        dt = self._clock.restart()
        if dt <= 0:
            dt = 16
        elif dt > 64:
            dt = 64                            # chong "nhay" sau khi treo / sleep
        THEME.advance_gradient(dt * 0.04)
        # Lam moi danh sach widget on-screen ~1s/lan (re) - KHONG quet cay moi frame.
        self._cache_accum += dt
        if not self._targets or self._cache_accum >= 1000:
            self._cache_accum = 0.0
            self._refresh_targets()
        # CHI repaint (cuc re). KHONG goi setStyleSheet/apply_app_css moi frame -
        # do chinh la nguyen nhan giat dinh ky truoc day -> nay da loai bo hoan toan.
        for w in self._targets:
            try:
                w.update()
            except RuntimeError:
                self._refresh_targets()
                break

_GRADIENT_DRIVER = None

def _ensure_gradient_driver():
    return None

def _pause_gradient_for_work():
    d = _ensure_gradient_driver()
    if d is not None:
        try:
            d.set_busy(True)
        except Exception:
            pass

def _resume_gradient_after_work():
    d = _GRADIENT_DRIVER
    if d is not None:
        try:
            d.set_busy(False)
        except Exception:
            pass

class ErrorCode(Enum):
    NO_SESSION = "no_session"
    NO_TEXT = "no_text"
    NO_SUBTITLE = "no_subtitle"
    NETWORK_ERROR = "network_error"
    DECODER_ERROR = "decoder_error"
    CANCELLED = "cancelled"
    UNKNOWN = "unknown"


class SynthesisWorker(QThread):
    message = pyqtSignal(str)
    progress = pyqtSignal(int)
    stage_progress = pyqtSignal(str, int)  # ("tts"|"mp3wav", 0..100)
    completed = pyqtSignal(bool, str, str)

    def __init__(self, mode="", text="", subtitle_path="", output_dir="", output_name="",
                 voice="", speed=1.0, pitch=False, session_ids=None, provider="TikTok", parent=None):
        super().__init__(parent)
        self.session_ids = session_ids or []
        self.provider = provider or "TikTok"
        self.mode = mode
        self.text = text
        self.subtitle_path = subtitle_path
        self.output_dir = output_dir
        self.output_name = output_name
        self.voice = voice
        self.speed = float(speed) if speed else 1.0
        self.pitch = bool(pitch)
        self._cancel_event = threading.Event()

    def cancel(self):
        self._cancel_event.set()
        self.message.emit("[i] Đang hủy tác vụ...")

    def run(self):
        try:
            if self.provider == "Inworld":
                from Speech.inworld_engine import run_full
            else:
                from Speech.tiktok_engine import run_full
        except Exception as e:
            self.message.emit(f"[-] Không tải được Speech Engine: {e}")
            self.completed.emit(False, "", ErrorCode.DECODER_ERROR.value)
            return
        try:
            ok, out_path = run_full(
                mode=self.mode,
                text=self.text,
                subtitle_path=self.subtitle_path,
                output_dir=self.output_dir,
                output_name=self.output_name,
                voice=self.voice,
                speed=self.speed,
                pitch=self.pitch,
                session_ids=self.session_ids,
                log=self.message.emit,
                progress=None,
                stage_progress=self.stage_progress.emit,
                cancel_event=self._cancel_event,
            )
        except Exception:
            import traceback
            self.message.emit("[-] Lỗi không mong muốn khi tạo audio (raw):\n" + traceback.format_exc().strip())
            self.completed.emit(False, "", ErrorCode.DECODER_ERROR.value)
            return
        if self._cancel_event.is_set():
            self.completed.emit(False, "", ErrorCode.CANCELLED.value)
        else:
            self.completed.emit(ok, out_path, "" if ok else ErrorCode.UNKNOWN.value)

class GlassPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
    def paintEvent(self, event):

        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(0.8, 0.8, -0.8, -0.8)
        bk = 20.0
        body = QPainterPath(); body.addRoundedRect(r, bk, bk)
        p.save(); p.setClipPath(body)
        g = QLinearGradient(r.topLeft(), r.bottomLeft())
        g.setColorAt(0.0, QColor(58, 62, 68))
        g.setColorAt(0.5, QColor(42, 45, 51))
        g.setColorAt(1.0, QColor(26, 28, 32))
        p.fillPath(body, g)
        sheen = QLinearGradient(r.topLeft(), r.bottomLeft())
        sheen.setColorAt(0.0, QColor(255, 255, 255, 22))
        sheen.setColorAt(0.10, QColor(255, 255, 255, 6))
        sheen.setColorAt(0.5, QColor(255, 255, 255, 0))
        p.fillPath(body, sheen)
        p.restore()
        p.setBrush(Qt.BrushStyle.NoBrush)
        inner = QPainterPath(); inner.addRoundedRect(r.adjusted(1.4, 1.4, -1.4, -1.4), bk - 1.4, bk - 1.4)
        p.setPen(QPen(QColor(120, 128, 138, 90), 1.0))
        p.drawPath(inner)
        p.setPen(QPen(QColor(8, 9, 11, 235), 1.4))
        p.drawPath(body)
        p.end()

class GlassBox(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
    def paintEvent(self, event):

        p = QPainter(self)
        paint_liquid_glass(p, self.rect(), radius=12.0, opacity=1.0)
        p.end()

class SettingsCard(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(480, 350)
        self._opacity = 0.0

    def paintEvent(self, e):

        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setOpacity(self._opacity)
        paint_liquid_glass(p, self.rect(), radius=12.0, opacity=1.0)
        p.end()

class PushButton(QWidget):
    clicked = pyqtSignal()
    def __init__(self, text, svg=None, primary=True, parent=None):
        super().__init__(parent)
        self._primary = primary; self._text = text.strip(); self._icon = _icon(svg) if svg else None
        self.setMinimumHeight(46); self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._hover_val = 0.0; self._press_val = 0.0
        self._anim_hover = QPropertyAnimation(self, b"hover_progress"); self._anim_hover.setDuration(300); self._anim_hover.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim_press = QPropertyAnimation(self, b"press_progress"); self._anim_press.setDuration(150); self._anim_press.setEasingCurve(QEasingCurve.Type.OutBounce)

    @pyqtProperty(float)
    def hover_progress(self): return self._hover_val
    @hover_progress.setter
    def hover_progress(self, v): self._hover_val = v; self.update()

    @pyqtProperty(float)
    def press_progress(self): return self._press_val
    @press_progress.setter
    def press_progress(self, v): self._press_val = v; self.update()

    def paintEvent(self, event):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        if self._primary:
            tone = metal_tone(THEME.accent_rgb()); accent_edge = False
        else:
            tone = ((84, 90, 98), (54, 59, 66), (32, 35, 40)); accent_edge = False
        if not self.isEnabled():
            tone = ((58, 61, 66), (44, 47, 52), (30, 32, 36)); accent_edge = False
        body_rect = paint_metal_button(p, self.rect(), radius=None, hover=self._hover_val, press=self._press_val, accent_edge=accent_edge, tone=tone)
        if self._primary and self.isEnabled():
            _tr, _tg, _tb = THEME.accent_rgb()
            _lum = 0.299 * _tr + 0.587 * _tg + 0.114 * _tb
            co = QColor(18, 20, 24) if _lum > 150 else QColor(255, 255, 255)
        else:
            co = QColor(255, 255, 255) if self.isEnabled() else QColor(255, 255, 255, 70)
        p.setPen(co); p.setFont(QFont("Rosemary", 14, QFont.Weight.Black))
        fm = p.fontMetrics()
        icon_w = 20 if self._icon else 0
        spacing = 8 if (self._icon and self._text) else 0
        avail = body_rect.width() - icon_w - spacing - 16
        disp = fm.elidedText(self._text, Qt.TextElideMode.ElideRight, max(10, int(avail)))
        txt_w = fm.horizontalAdvance(disp)
        total_w = icon_w + spacing + txt_w
        start_x = body_rect.left() + (body_rect.width() - total_w) / 2
        if self._icon:
            self._icon.paint(p, QRect(int(start_x), int(body_rect.top()+(body_rect.height()-20)/2), 20, 20))
        text_x = start_x + icon_w + spacing
        p.drawText(QRectF(text_x, body_rect.top(), txt_w + 10, body_rect.height()), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, disp)
        p.end()

    def enterEvent(self, e):
        if self.isEnabled(): self._anim_hover.setEndValue(1.0); self._anim_hover.start()
    def leaveEvent(self, e):
        if self.isEnabled(): self._anim_hover.setEndValue(0.0); self._anim_hover.start()
    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton and self.isEnabled(): self._anim_press.setEndValue(1.0); self._anim_press.start()
    def mouseReleaseEvent(self, e):
        if self.isEnabled():
            self._anim_press.setEndValue(0.0); self._anim_press.start()
            if self.rect().contains(e.position().toPoint()):
                play_droplet()
                self.clicked.emit()

class IconButton(QWidget):
    clicked = pyqtSignal()
    def __init__(self, svg, kind="minimize", parent=None, side=36):
        super().__init__(parent)
        self._side = side; self._isz = 22 if side >= 40 else 16
        self.setFixedSize(side, side); self._icon = _icon(svg, self._isz); self._kind = kind
        self.setCursor(Qt.CursorShape.PointingHandCursor); self._hover_val = 0.0; self._press_val = 0.0
        self._anim_h = QPropertyAnimation(self, b"h_val_prop"); self._anim_h.setDuration(250)
        self._anim_p = QPropertyAnimation(self, b"p_val_prop"); self._anim_p.setDuration(100)

    @pyqtProperty(float)
    def h_val_prop(self): return self._hover_val
    @h_val_prop.setter
    def h_val_prop(self, v): self._hover_val = v; self.update()

    @pyqtProperty(float)
    def p_val_prop(self): return self._press_val
    @p_val_prop.setter
    def p_val_prop(self, v): self._press_val = v; self.update()

    def paintEvent(self, event):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        ht = self._hover_val; sink = 1.5 * self._press_val
        shadow_r = QRectF(4, 6, self._side - 8, self._side - 8)
        p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor(0, 0, 0, 190))
        sp = QPainterPath(); sp.addRoundedRect(shadow_r, 12, 12); p.drawPath(sp)
        rc = QRectF(4, 4 + sink, self._side - 8, self._side - 8)
        dd = QPainterPath(); dd.addRoundedRect(rc, 12, 12)
        if self._kind == "close":
            top = (255, 46 + int(40 * ht), 46 + int(40 * ht)); mid = (255, 0, 0); bot = (150, 0, 0)
        else:
            hb = int(22 * ht); top = (86 + hb, 92 + hb, 100 + hb); mid = (56, 61, 68); bot = (34, 37, 42)
        gr = QLinearGradient(rc.left(), rc.top(), rc.left(), rc.bottom())
        gr.setColorAt(0.0, QColor(*top)); gr.setColorAt(0.5, QColor(*mid)); gr.setColorAt(1.0, QColor(*bot))
        p.setBrush(gr); p.drawPath(dd)
        sr = QRectF(rc).adjusted(3, 2, -3, 0); sr.setHeight(rc.height() * 0.42); sp2 = QPainterPath(); sp2.addRoundedRect(sr, 8, 8)
        gs = QLinearGradient(0, sr.top(), 0, sr.bottom()); gs.setColorAt(0.0, QColor(255, 255, 255, int(70 + 50 * ht))); gs.setColorAt(1.0, QColor(255, 255, 255, 0)); p.fillPath(sp2, gs)
        p.setBrush(Qt.BrushStyle.NoBrush); p.setPen(QPen(QColor(8, 9, 11, 235), 1.3)); p.drawPath(dd)
        if self._icon:
            t_x = int(rc.left() + (rc.width() - self._isz) / 2)
            t_y = int(rc.top() + (rc.height() - self._isz) / 2)
            self._icon.paint(p, QRect(t_x, t_y, self._isz, self._isz))
        p.end()

    def enterEvent(self, e): self._anim_h.setEndValue(1.0); self._anim_h.start()
    def leaveEvent(self, e): self._anim_h.setEndValue(0.0); self._anim_h.start()
    def mousePressEvent(self, e): self._anim_p.setEndValue(1.0); self._anim_p.start()
    def mouseReleaseEvent(self, e):
        self._anim_p.setEndValue(0.0); self._anim_p.start()
        if self.rect().contains(e.position().toPoint()):
            play_droplet()
            self.clicked.emit()

class SettingsButton(QWidget):
    clicked = pyqtSignal()
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(40, 40)
        self._icon = _icon(_SVG_SETTINGS, 22)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._hover_val = 0.0
        self._press_val = 0.0
        self._anim_h = QPropertyAnimation(self, b"h_val_prop")
        self._anim_h.setDuration(250)
        self._anim_p = QPropertyAnimation(self, b"p_val_prop")
        self._anim_p.setDuration(100)

    @pyqtProperty(float)
    def h_val_prop(self): return self._hover_val
    @h_val_prop.setter
    def h_val_prop(self, v):
        self._hover_val = v
        self.update()

    @pyqtProperty(float)
    def p_val_prop(self): return self._press_val
    @p_val_prop.setter
    def p_val_prop(self, v): self._press_val = v; self.update()

    def paintEvent(self, event):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        ht = self._hover_val; sink = 1.5 * self._press_val
        shadow_r = QRectF(4, 6, 32, 32)
        p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor(0, 0, 0, 190))
        sp = QPainterPath(); sp.addRoundedRect(shadow_r, 12, 12); p.drawPath(sp)
        rc = QRectF(4, 4 + sink, 32, 32)
        dd = QPainterPath(); dd.addRoundedRect(rc, 12, 12)
        hb = int(22 * ht)
        gr = QLinearGradient(rc.left(), rc.top(), rc.left(), rc.bottom())
        gr.setColorAt(0.0, QColor(86 + hb, 92 + hb, 100 + hb)); gr.setColorAt(0.5, QColor(56, 61, 68)); gr.setColorAt(1.0, QColor(34, 37, 42))
        p.setBrush(gr); p.drawPath(dd)
        sr = QRectF(rc).adjusted(3, 2, -3, 0); sr.setHeight(rc.height() * 0.42); sp2 = QPainterPath(); sp2.addRoundedRect(sr, 8, 8)
        gs = QLinearGradient(0, sr.top(), 0, sr.bottom()); gs.setColorAt(0.0, QColor(255, 255, 255, int(70 + 50 * ht))); gs.setColorAt(1.0, QColor(255, 255, 255, 0)); p.fillPath(sp2, gs)
        p.setBrush(Qt.BrushStyle.NoBrush); p.setPen(QPen(QColor(8, 9, 11, 235), 1.3)); p.drawPath(dd)
        if self._icon:
            p.save()
            p.translate(rc.center())
            p.rotate(ht * 90)
            self._icon.paint(p, QRect(-11, -11, 22, 22))
            p.restore()
        p.end()

    def enterEvent(self, e): self._anim_h.setEndValue(1.0); self._anim_h.start()
    def leaveEvent(self, e): self._anim_h.setEndValue(0.0); self._anim_h.start()
    def mousePressEvent(self, e): self._anim_p.setEndValue(1.0); self._anim_p.start()
    def mouseReleaseEvent(self, e):
        self._anim_p.setEndValue(0.0); self._anim_p.start()
        if self.rect().contains(e.position().toPoint()):
            play_droplet()
            self.clicked.emit()

class Slider(QSlider):
    _GROOVE_H  = 7; _HANDLE_R = 11; _MARGIN = 12
    def __init__(self, step=10, parent=None):
        super().__init__(Qt.Orientation.Horizontal, parent)
        self._step = step; self.setFixedHeight(28); self._hover = False; self._pressed = False
        self.setCursor(Qt.CursorShape.PointingHandCursor); self.setSingleStep(step); self.setPageStep(step)
    def _groove(self):
        w = self.width(); cy = self.height()/2; return QRectF(self._MARGIN, cy-self._GROOVE_H/2, w-2*self._MARGIN, self._GROOVE_H)
    def _handle_pos(self):
        k = self._groove(); t = (self.value()-self.minimum()) / max(1, self.maximum()-self.minimum())
        x_min = self._HANDLE_R + 3
        x_max = self.width() - self._HANDLE_R - 3
        cx = k.left() + t * k.width()
        cx = max(x_min, min(x_max, cx))
        return QPointF(cx, self.height()/2)
    def paintEvent(self, event):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        khe = self._groove(); tc = self._handle_pos(); bk = self._HANDLE_R - (1 if self._pressed else 0)
        grad_r = khe.height() / 2.0
        dk = QPainterPath(); dk.addRoundedRect(khe, grad_r, grad_r)
        gk = QLinearGradient(0, khe.top(), 0, khe.bottom())
        gk.setColorAt(0.0, QColor(20, 22, 26)); gk.setColorAt(1.0, QColor(40, 44, 50)); p.fillPath(dk, gk)
        if self.value() > self.minimum():
            kr = QRectF(khe.left(), khe.top(), tc.x()-khe.left(), khe.height())
            if kr.width() > 0:
                dp = QPainterPath(); dp.addRoundedRect(kr, grad_r, grad_r)
                acc = accent_color(255)
                gd = QLinearGradient(0, kr.top(), 0, kr.bottom())
                gd.setColorAt(0.0, QColor(min(255, acc.red()+45), min(255, acc.green()+45), min(255, acc.blue()+45)))
                gd.setColorAt(1.0, acc); p.fillPath(dp, gd)
        p.setPen(QPen(QColor(8, 9, 11, 200), 1.2)); p.setBrush(Qt.BrushStyle.NoBrush); p.drawPath(dk)
        p.setPen(Qt.PenStyle.NoPen)
        sh = QPainterPath(); sh.addEllipse(QPointF(tc.x(), tc.y()+1.8), bk, bk)
        p.setBrush(QColor(70, 74, 80, 150)); p.drawPath(sh)
        dt = QPainterPath(); dt.addEllipse(tc, bk, bk)
        gt = QLinearGradient(tc.x(), tc.y()-bk, tc.x(), tc.y()+bk)
        gt.setColorAt(0.0, QColor(255, 255, 255)); gt.setColorAt(0.5, QColor(228, 232, 238)); gt.setColorAt(1.0, QColor(188, 194, 202))
        p.setBrush(gt); p.drawPath(dt)
        dss = QPainterPath(); dss.addEllipse(QPointF(tc.x(), tc.y()-bk*0.35), bk*0.55, bk*0.32)
        gss2 = QLinearGradient(tc.x(), tc.y()-bk, tc.x(), tc.y()); gss2.setColorAt(0.0, QColor(255,255,255,185)); gss2.setColorAt(1.0, QColor(255,255,255,0)); p.fillPath(dss, gss2)
        p.setBrush(Qt.BrushStyle.NoBrush); p.setPen(QPen(QColor(8, 9, 11, 210), 1.3)); p.drawEllipse(tc, bk, bk)
        p.end()
    def _update(self, mx):
        k = self._groove(); t = max(0.0, min(1.0, (mx-k.left())/max(1, k.width())))
        raw_val = self.minimum() + t * (self.maximum() - self.minimum()); snap_val = round(raw_val / self._step) * self._step
        snap_val = max(self.minimum(), min(self.maximum(), snap_val)); self.setValue(int(snap_val))
    def enterEvent(self, e): self._hover=True; self.update(); super().enterEvent(e)
    def leaveEvent(self, e): self._hover=False; self.update(); super().leaveEvent(e)
    def mousePressEvent(self, e):
        if e.button()==Qt.MouseButton.LeftButton: self._pressed=True; self._update(e.position().x()); self.update()
        else: super().mousePressEvent(e)
    def mouseMoveEvent(self, e):
        if self._pressed: self._update(e.position().x())
        else: super().mouseMoveEvent(e)
    def mouseReleaseEvent(self, e):
        if self._pressed: self._pressed=False; self.update()
        else: super().mouseReleaseEvent(e)

class ToggleSwitch(QWidget):
    toggled = pyqtSignal(bool)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(58, 30)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._checked = False
        self._circle_val = 3.0
        self._hover_val = 0.0
        self._anim = QPropertyAnimation(self, b"c_val"); self._anim.setDuration(350); self._anim.setEasingCurve(QEasingCurve.Type.OutBack)
        self._anim_h = QPropertyAnimation(self, b"h_val"); self._anim_h.setDuration(200)
        QTimer.singleShot(0, init_sound_effects)

    @pyqtProperty(float)
    def c_val(self): return self._circle_val
    @c_val.setter
    def c_val(self, v): self._circle_val = v; self.update()

    @pyqtProperty(float)
    def h_val(self): return self._hover_val
    @h_val.setter
    def h_val(self, v): self._hover_val = v; self.update()

    def isChecked(self): return self._checked
    def setChecked(self, s):
        if self._checked != s:
            self._checked = s
            self._anim.stop(); self._anim.setEndValue(31.0 if s else 3.0); self._anim.start()
            self.toggled.emit(s)
            play_droplet(s)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton: self.setChecked(not self._checked)
    def enterEvent(self, e): self._anim_h.setEndValue(1.0); self._anim_h.start()
    def leaveEvent(self, e): self._anim_h.setEndValue(0.0); self._anim_h.start()

    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(1, 1, 56, 28); bk = 12.0
        prg = max(0.0, min(1.0, (self._circle_val - 3.0) / 28.0))
        tr = QPainterPath(); tr.addRoundedRect(r, bk, bk)
        track_g = QLinearGradient(0, r.top(), 0, r.bottom())
        if prg > 0.01:
            acc = accent_color(255)
            track_g.setColorAt(0.0, QColor(min(255, acc.red() + 42), min(255, acc.green() + 42), min(255, acc.blue() + 42)))
            track_g.setColorAt(0.5, acc)
            track_g.setColorAt(1.0, QColor(int(acc.red() * 0.55), int(acc.green() * 0.55), int(acc.blue() * 0.55)))
        else:
            track_g.setColorAt(0.0, QColor(58, 63, 70))
            track_g.setColorAt(0.5, QColor(40, 44, 50))
            track_g.setColorAt(1.0, QColor(24, 26, 30))
        p.fillPath(tr, track_g)
        p.setPen(QPen(QColor(8, 9, 11, 220), 1.4)); p.setBrush(Qt.BrushStyle.NoBrush); p.drawPath(tr)
        thumb_r = QRectF(self._circle_val, 3.0, 24.0, 24.0)
        p.setPen(Qt.PenStyle.NoPen)
        sh = QPainterPath(); sh.addEllipse(thumb_r.translated(0, 1.8))
        p.setBrush(QColor(70, 74, 80, 148)); p.drawPath(sh)
        th_path = QPainterPath(); th_path.addEllipse(thumb_r)
        tg = QLinearGradient(thumb_r.topLeft(), thumb_r.bottomLeft())
        tg.setColorAt(0.0, QColor(255, 255, 255))
        tg.setColorAt(0.5, QColor(228, 232, 238))
        tg.setColorAt(1.0, QColor(188, 194, 202))
        p.setBrush(tg); p.drawPath(th_path)
        spec = QRectF(thumb_r.left() + 4.5, thumb_r.top() + 3.2, 15.0, 7.5)
        sp = QPainterPath(); sp.addEllipse(spec)
        sg = QLinearGradient(0, spec.top(), 0, spec.bottom())
        sg.setColorAt(0.0, QColor(255, 255, 255, 175)); sg.setColorAt(1.0, QColor(255, 255, 255, 0))
        p.fillPath(sp, sg)
        p.setBrush(Qt.BrushStyle.NoBrush); p.setPen(QPen(QColor(8, 9, 11, 210), 1.2)); p.drawEllipse(thumb_r)
        p.end()

class ProgressBar(QProgressBar):

    _RAINBOW = [
        (255, 45, 85),
        (255, 149, 0),
        (255, 214, 10),
        (52, 199, 89),
        (0, 209, 214),
        (10, 132, 255),
        (175, 82, 222),
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(16); self.setTextVisible(False)
        self._solid = None
        self._anim = QPropertyAnimation(self, b"value"); self._anim.setDuration(280); self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)

    def set_solid_color(self, color):
        self._solid = color; self.update()

    def set_rainbow(self):
        self._solid = None; self.setValue(self.maximum()); self.update()

    @pyqtSlot(int)
    def set_progress(self, v):
        self._anim.stop(); self._anim.setStartValue(self.value()); self._anim.setEndValue(v); self._anim.start()

    def paintEvent(self, event):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        rc = QRectF(0, 0, w, h).adjusted(1, 1, -1, -1)
        bk = min(12.0, rc.height() / 2.0)
        track = QPainterPath(); track.addRoundedRect(rc, bk, bk)
        tg = QLinearGradient(0, rc.top(), 0, rc.bottom())
        tg.setColorAt(0.0, QColor(20, 22, 26)); tg.setColorAt(1.0, QColor(36, 39, 45))
        p.fillPath(track, tg)
        if self.value() > 0:
            t = self.value() / max(1, self.maximum())
            cw = max(0.0, (w - 4) * t)
            if cw > 2:
                cr = QRectF(2, 2, cw, h - 4)
                cbk = min(bk, cr.height() / 2.0)
                fp = QPainterPath(); fp.addRoundedRect(cr, cbk, cbk)
                col = self._solid if self._solid is not None else accent_color(255)
                g = QLinearGradient(0, cr.top(), 0, cr.bottom())
                g.setColorAt(0.0, QColor(min(255, col.red()+55), min(255, col.green()+55), min(255, col.blue()+55)))
                g.setColorAt(0.5, col)
                g.setColorAt(1.0, QColor(int(col.red()*0.6), int(col.green()*0.6), int(col.blue()*0.6)))
                p.fillPath(fp, g)
                sr = QRectF(cr).adjusted(1, 1, -1, 0); sr.setHeight(cr.height()*0.45)
                sp = QPainterPath(); sp.addRoundedRect(sr, cbk, cbk)
                sg = QLinearGradient(0, sr.top(), 0, sr.bottom())
                sg.setColorAt(0.0, QColor(255,255,255,120)); sg.setColorAt(1.0, QColor(255,255,255,0))
                p.fillPath(sp, sg)
        p.setPen(QPen(QColor(8, 9, 11, 220), 1.2)); p.setBrush(Qt.BrushStyle.NoBrush); p.drawPath(track)
        p.end()

class StackedProgressBar(QProgressBar):
    """Một thanh tiến trình duy nhất cho TTS và Audio Core RAM.

    Pitch/Speed đã nằm bên trong Audio Core nên không còn thanh riêng.
    """
    _RAINBOW = ProgressBar._RAINBOW
    _COLORS = {
        "tts": QColor(255, 214, 10),
        "mp3wav": QColor(10, 132, 255),
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(18)
        self.setTextVisible(False)
        self._values = {"tts": 0, "mp3wav": 0}
        self._rainbow = False

    def reset_stages(self):
        self._values = {"tts": 0, "mp3wav": 0}
        self._rainbow = False
        self.setValue(0); self.update()

    def set_solid_color(self, color):
        self._rainbow = False; self.update()

    def set_stage_progress(self, stage, value):
        if stage not in self._values:
            return
        self._values[stage] = max(0, min(100, int(value)))
        self.setValue(max(self._values.values())); self.update()

    @pyqtSlot(int)
    def set_progress(self, value):
        self.set_stage_progress("tts", value)

    def set_rainbow(self):
        self._rainbow = True
        self._values = {"tts": 100, "mp3wav": 100}
        self.setValue(100); self.update()

    def paintEvent(self, event):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        rc = QRectF(0, 0, w, h).adjusted(1, 1, -1, -1)
        bk = min(12.0, rc.height() / 2.0)
        inner = rc
        stages = ("tts", "mp3wav")
        gap = 6.0
        zone_w = (inner.width() - gap * (len(stages) - 1)) / len(stages)
        zh = inner.height()
        rad = min(bk, zh / 2.0)
        for i, stage in enumerate(stages):
            zx = inner.left() + i * (zone_w + gap)
            track = QRectF(zx, inner.top(), zone_w, zh)
            tp = QPainterPath(); tp.addRoundedRect(track, rad, rad)
            tg = QLinearGradient(0, track.top(), 0, track.bottom())
            tg.setColorAt(0.0, QColor(20, 22, 26)); tg.setColorAt(1.0, QColor(36, 39, 45))
            p.fillPath(tp, tg)
            frac = max(0.0, min(1.0, self._values.get(stage, 0) / 100.0))
            fill_w = zone_w * frac
            if fill_w > 1.5:
                color = accent_color(255) if self._rainbow else self._COLORS[stage]
                fr = QRectF(zx, inner.top(), fill_w, zh)
                fp = QPainterPath(); fp.addRoundedRect(fr, rad, rad)
                p.save(); p.setClipPath(fp)
                g = QLinearGradient(0, fr.top(), 0, fr.bottom())
                g.setColorAt(0.0, QColor(min(255, color.red()+60), min(255, color.green()+60), min(255, color.blue()+60)))
                g.setColorAt(0.5, color)
                g.setColorAt(1.0, QColor(int(color.red()*0.6), int(color.green()*0.6), int(color.blue()*0.6)))
                p.fillRect(fr, g)
                gs = QLinearGradient(0, fr.top(), 0, fr.bottom())
                gs.setColorAt(0.0, QColor(255,255,255,120)); gs.setColorAt(0.5, QColor(255,255,255,20)); gs.setColorAt(1.0, QColor(0,0,0,40))
                p.fillRect(fr, gs)
                p.restore()
            p.setPen(QPen(QColor(8,9,11,220), 1.1)); p.setBrush(Qt.BrushStyle.NoBrush); p.drawPath(tp)
        p.end()

class SmoothListView(QListView):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QListView.Shape.NoFrame)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.viewport().setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setAutoFillBackground(False)
        self.viewport().setAutoFillBackground(False)

    def _update_mask(self):

        path = QPainterPath()
        path.addRoundedRect(QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5), 12.0, 12.0)
        self.setMask(QRegion(path.toFillPolygon().toPolygon()))

    def resizeEvent(self, e):
        super().resizeEvent(e); self._update_mask()

    def showEvent(self, e):
        super().showEvent(e); self._update_mask()

    def paintEvent(self, e):
        p = QPainter(self.viewport())
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(self.viewport().rect()).adjusted(1.5, 1.5, -1.5, -1.5)
        bk = 12.0
        paint_liquid_glass(p, r, radius=bk, opacity=1.0)
        super().paintEvent(e)

class _CenteredComboBox(QComboBox):
    """QComboBox KHONG editable nhung ve van ban CAN GIUA.

    Khong dung lineEdit chi-doc (gay loi popup hien roi an ngay lap tuc) ->
    chon giong noi hoat dong 100% on dinh, van can giua dep mat.
    """
    def showPopup(self):
        opener = getattr(self, "_open_search", None)
        if callable(opener):
            opener()   # Popup TIM KIEM tuy bien thay cho popup mac dinh
            return
        super().showPopup()

    def paintEvent(self, e):
        from PyQt6.QtWidgets import QStylePainter, QStyle, QStyleOptionComboBox
        sp = QStylePainter(self)
        opt = QStyleOptionComboBox()
        self.initStyleOption(opt)
        txt = opt.currentText
        opt.currentText = ""                       # khong cho style ve chu (mac dinh canh trai)
        sp.drawComplexControl(QStyle.ComplexControl.CC_ComboBox, opt)
        full = QRectF(self.rect())
        sp.setPen(QColor(255, 255, 255))
        sp.setFont(self.font())
        fm = sp.fontMetrics()
        disp = fm.elidedText(txt, Qt.TextElideMode.ElideRight, max(10, int(full.width()) - 30))
        sp.drawText(full, int(Qt.AlignmentFlag.AlignCenter), disp)


class _MetalScrollBar(QScrollBar):
    """Thanh keo doc kim loai 3D: TAY KEO BEO CO DINH, luon bo goc gon trong long
    ray -> het 'luc to luc be' + het 'cuc den khong bo vien'. Ve thu cong, chi
    repaint khi cuon/di chuot -> toi uu cuc han, khong ton tai nguyen nen."""
    _W = 12
    _HANDLE = 46.0

    def __init__(self, parent=None):
        super().__init__(Qt.Orientation.Vertical, parent)
        self.setFixedWidth(self._W)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._drag = False
        self.setStyleSheet("background: transparent; border: none;")

    def sizeHint(self):
        return QSize(self._W, 40)

    def _groove(self):
        return max(1.0, self.height() - 6.0)

    def _handle_h(self):
        return min(self._HANDLE, self._groove())

    def _handle_y(self):
        rng = self.maximum() - self.minimum()
        if rng <= 0:
            return 3.0
        frac = (self.value() - self.minimum()) / float(rng)
        return 3.0 + frac * (self._groove() - self._handle_h())

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w = self.width()
        # Ray nen mo nhe, bo goc tron -> khong con cuc den vuong tho.
        track = QRectF(w / 2.0 - 2.5, 3.0, 5.0, self.height() - 6.0)
        tp = QPainterPath(); tp.addRoundedRect(track, 2.5, 2.5)
        p.fillPath(tp, QColor(10, 11, 14, 90))
        if self.maximum() - self.minimum() <= 0:
            p.end(); return
        # Tay keo kim loai 3D, KICH THUOC CO DINH, bo goc gon trong ray.
        hy = self._handle_y(); hh = self._handle_h()
        hr = QRectF(w / 2.0 - 4.0, hy, 8.0, hh)
        hp = QPainterPath(); hp.addRoundedRect(hr, 4.0, 4.0)
        hover = self.underMouse() or self._drag
        g = QLinearGradient(hr.left(), 0, hr.right(), 0)
        if hover:
            g.setColorAt(0.0, QColor(0x83, 0x8B, 0x95)); g.setColorAt(0.5, QColor(0x54, 0x5A, 0x62)); g.setColorAt(1.0, QColor(0x2A, 0x2E, 0x34))
        else:
            g.setColorAt(0.0, QColor(0x6E, 0x75, 0x7E)); g.setColorAt(0.5, QColor(0x46, 0x4B, 0x52)); g.setColorAt(1.0, QColor(0x22, 0x25, 0x2A))
        p.fillPath(hp, g)
        # Anh sang doc dinh -> khoi 3D noi.
        sh = QLinearGradient(hr.left(), hr.top(), hr.left(), hr.bottom())
        sh.setColorAt(0.0, QColor(255, 255, 255, 60)); sh.setColorAt(0.5, QColor(255, 255, 255, 0))
        p.fillPath(hp, sh)
        p.setPen(QPen(QColor(10, 11, 14, 230), 1.0)); p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPath(hp)
        p.end()

    def _value_from_y(self, y):
        groove = self._groove(); hh = self._handle_h()
        span = groove - hh
        rng = self.maximum() - self.minimum()
        if span <= 0 or rng <= 0:
            return
        frac = (float(y) - 3.0 - hh / 2.0) / span
        frac = max(0.0, min(1.0, frac))
        self.setValue(int(round(self.minimum() + frac * rng)))

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._drag = True
            self._value_from_y(e.position().y())
            self.update()

    def mouseMoveEvent(self, e):
        if self._drag:
            self._value_from_y(e.position().y())

    def mouseReleaseEvent(self, e):
        self._drag = False
        self.update()

    def enterEvent(self, e):
        self.update()

    def leaveEvent(self, e):
        self.update()


class _VoicePopupFrame(QFrame):
    """Khung popup tim giong: TU VE nen bo goc DAC (opaque) + vien accent, giu
    goc trong suot -> het loi 'trong suot' xuyen thau (QSS nen khong an tren
    popup translucent vi bi global 'QWidget{background:transparent}' de len)."""
    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(self.rect()).adjusted(0.75, 0.75, -0.75, -0.75)
        path = QPainterPath(); path.addRoundedRect(r, 12.0, 12.0)
        p.fillPath(path, QColor(30, 33, 38, 255))
        p.setPen(QPen(QColor(120, 128, 138, 235), 1.6)); p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPath(path)
        p.end()


class ComboBox(QWidget):
    def __init__(self, parent=None, searchable=False):
        super().__init__(parent)
        self._searchable = bool(searchable)
        self.setFixedHeight(48)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self._accent_t = 0.0          # 0 = vien trang, 1 = vien accent SONG (doc gradient real-time)
        self._hover_alpha = 0.0

        self._anim = QVariantAnimation(self)
        self._anim.setDuration(280); self._anim.setEasingCurve(QEasingCurve.Type.InOutCubic)
        self._anim.valueChanged.connect(self._update_accent_t)

        self._anim_hover = QVariantAnimation(self)
        self._anim_hover.setDuration(200)
        self._anim_hover.valueChanged.connect(self._update_hover)

        lo = QVBoxLayout(self); lo.setContentsMargins(3, 3, 3, 3)
        self._cb = _CenteredComboBox()
        self._cb.setCursor(Qt.CursorShape.PointingHandCursor)
        self._view = SmoothListView()
        self._cb.setView(self._view)
        self._cb.setMaxVisibleItems(24)

        # Van ban giong noi duoc _CenteredComboBox ve CAN GIUA (khong dung lineEdit -> chon giong 100%).
        self._cb.setFont(QFont("Rosemary", 13, QFont.Weight.Black))

        from PyQt6.QtGui import QPalette as _QPalette
        _cpal = self._cb.palette()
        for _group in (_QPalette.ColorGroup.Active, _QPalette.ColorGroup.Inactive, _QPalette.ColorGroup.Disabled):
            for _role in (_QPalette.ColorRole.Text, _QPalette.ColorRole.ButtonText, _QPalette.ColorRole.WindowText, _QPalette.ColorRole.HighlightedText, _QPalette.ColorRole.BrightText):
                _cpal.setColor(_group, _role, QColor(255, 255, 255))
            _cpal.setColor(_group, _QPalette.ColorRole.Base, QColor(34, 38, 44))
            _cpal.setColor(_group, _QPalette.ColorRole.Window, QColor(34, 38, 44))
            _cpal.setColor(_group, _QPalette.ColorRole.Highlight, THEME.bright())
        self._cb.setPalette(_cpal)
        self._view.setPalette(_cpal)

        popup_window = self._cb.view().window()
        popup_window.setWindowFlags(Qt.WindowType.Popup | Qt.WindowType.FramelessWindowHint | Qt.WindowType.NoDropShadowWindowHint)
        popup_window.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        container = self._cb.view().parentWidget()
        if container:
            container.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        arrow_svg = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 24 24' fill='none' stroke='%23FFFFFF' stroke-width='2.8' stroke-linecap='round' stroke-linejoin='round'><polyline points='6 9 12 15 18 9'/></svg>"
        arrow_svg_hover = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 24 24' fill='none' stroke='%23__ACC6__' stroke-width='3.0' stroke-linecap='round' stroke-linejoin='round'><polyline points='6 9 12 15 18 9'/></svg>"

        combo_qss = """
            QComboBox {
                background: transparent;
                border: none;
                padding: 0px 36px 4px 36px;
                font-size: 14px;
                font-weight: 700;
                color: #FFFFFF;
                selection-color: #FFFFFF;
                selection-background-color: __ACC__;
            }
            QComboBox:focus { outline: none; color: #FFFFFF; }
            QComboBox::drop-down {
                subcontrol-origin: padding;
                subcontrol-position: top right;
                width: 36px;
                border: none;
                background: transparent;
            }
            QComboBox::down-arrow {
                image: url("__ARROW__");
                width: 14px;
                height: 14px;
                margin-right: 12px;
            }
            QComboBox::down-arrow:on, QComboBox::down-arrow:hover {
                image: url("__ARROWH__");
            }

            QComboBox QAbstractItemView {
                background-color: #22262C;
                background: #22262C;
                border: 1px solid #5A616B;
                border-radius: 12px;
                padding: 6px 4px 6px 4px;
                outline: 0px;
                color: #FFFFFF;
                selection-background-color: __ACC__;
                selection-color: #FFFFFF;
                show-decoration-selected: 1;
            }
            QComboBox QAbstractItemView::item {
                min-height: 30px;
                height: 30px;
                border-radius: 6px;
                padding-left: 10px;
                padding-right: 10px;
                margin: 1px 2px 1px 2px;
                color: #FFFFFF;
                background-color: transparent;
            }
            QComboBox QAbstractItemView::item:!selected {
                color: #FFFFFF;
                background-color: transparent;
            }
            QComboBox QAbstractItemView::item:hover,
            QComboBox QAbstractItemView::item:selected {
                color: #FFFFFF;
                background-color: __ACC__;
            }
        """.replace("__ARROW__", arrow_svg).replace("__ARROWH__", arrow_svg_hover)
        _styled(self._cb, combo_qss)

        view_qss = """
            QListView {
                background-color: #22262C;
                background: #22262C;
                border: 1px solid #5A616B;
                border-radius: 12px;
                padding: 6px 4px 6px 4px;
                outline: 0px;
                color: #FFFFFF;
                selection-background-color: __ACC__;
                selection-color: #FFFFFF;
                show-decoration-selected: 1;
            }
            QListView::item {
                min-height: 30px;
                height: 30px;
                border-radius: 6px;
                padding-left: 10px;
                padding-right: 10px;
                margin: 1px 2px 1px 2px;
                color: #FFFFFF;
                background-color: transparent;
            }
            QListView::item:!selected {
                color: #FFFFFF;
                background-color: transparent;
            }
            QListView::item:hover,
            QListView::item:selected {
                color: #FFFFFF;
                background-color: __ACC__;
            }
            QScrollBar:vertical, QScrollBar:horizontal {
                width: 0px; height: 0px; background: transparent; border: none;
            }
            QScrollBar::handle { background: transparent; }
            QScrollBar::add-line, QScrollBar::sub-line { width: 0px; height: 0px; }
        """
        _styled(self._view, view_qss)

        # Popup TIM KIEM tuy bien (chi bat khi searchable=True, vd: combo giong).
        if self._searchable:
            self._build_search_popup()

        self._cb.installEventFilter(self)
        lo.addWidget(self._cb)

    def eventFilter(self, obj, e):
        if obj == self._cb:
            if e.type() == e.Type.FocusIn:
                self._anim.stop(); self._anim.setStartValue(self._accent_t); self._anim.setEndValue(1.0); self._anim.start()
            elif e.type() == e.Type.FocusOut:
                self._anim.stop(); self._anim.setStartValue(self._accent_t); self._anim.setEndValue(0.0); self._anim.start()
            elif e.type() == e.Type.Enter:
                self._anim_hover.stop(); self._anim_hover.setStartValue(self._hover_alpha); self._anim_hover.setEndValue(1.0); self._anim_hover.start()
            elif e.type() == e.Type.Leave:
                self._anim_hover.stop(); self._anim_hover.setStartValue(self._hover_alpha); self._anim_hover.setEndValue(0.0); self._anim_hover.start()
        return super().eventFilter(obj, e)

    def _update_accent_t(self, v): self._accent_t = float(v); self.update()
    def _update_hover(self, v): self._hover_alpha = v; self.update()

    def paintEvent(self, e):
        # O chon = 100% giong nut bam 3D kim loai (nen kim loai + bong den 3D duoi +
        # vien den). Copy y het paint_metal_button.
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        tone = ((84, 90, 98), (54, 59, 66), (32, 35, 40))
        paint_metal_button(p, self.rect(), radius=12.0, hover=self._hover_alpha, press=0.0, accent_edge=False, tone=tone)
        p.end()

    def _apply_item_colors(self):

        m = self._cb.model()
        bg = QColor(34, 38, 44, 255)
        fg = QColor(255, 255, 255, 255)
        for i in range(self._cb.count()):
            idx = m.index(i, 0)
            m.setData(idx, fg, Qt.ItemDataRole.ForegroundRole)
            m.setData(idx, bg, Qt.ItemDataRole.BackgroundRole)
            m.setData(idx, int(Qt.AlignmentFlag.AlignCenter), Qt.ItemDataRole.TextAlignmentRole)

    def addItems(self, it):
        self._cb.addItems(it)
        self._apply_item_colors()

    def addItem(self, it):
        self._cb.addItem(it)
        self._apply_item_colors()

    def currentText(self): return self._cb.currentText()

    def _build_search_popup(self):
        """Dropdown tim kiem tuy bien: MOT khung bo goc gom o tim + danh sach giong,
        neo ngay duoi combo -> nhin lien khoi, cao cap, khong bi tach roi."""
        self._popup = _VoicePopupFrame(self)
        self._popup.setWindowFlags(
            Qt.WindowType.Popup | Qt.WindowType.FramelessWindowHint | Qt.WindowType.NoDropShadowWindowHint)
        self._popup.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        pl = QVBoxLayout(self._popup)
        pl.setContentsMargins(6, 6, 6, 6)
        pl.setSpacing(6)

        self._search = QLineEdit()
        self._search.setPlaceholderText("Tìm giọng...")
        self._search.setClearButtonEnabled(True)
        self._search.setFixedHeight(38)
        self._search.setFont(QFont("Rosemary", 11, QFont.Weight.Bold))
        try:
            self._search.addAction(_icon(_SVG_SEARCH, 16), QLineEdit.ActionPosition.LeadingPosition)
        except Exception:
            pass
        _styled(self._search, """
            QLineEdit {
                background-color: rgba(255,255,255,20);
                border: 1px solid rgba(255,255,255,60);
                border-radius: 9px;
                padding: 6px 10px 6px 6px;
                color: #FFFFFF; font-weight: 700; font-size: 14px;
                selection-background-color: __ACC__; selection-color: #FFFFFF;
            }
            QLineEdit:focus { border: 1px solid __ACC__; }
        """)
        from PyQt6.QtGui import QPalette as _QPalSearch
        _spal = self._search.palette()
        _spal.setColor(_QPalSearch.ColorRole.PlaceholderText, QColor(255, 255, 255, 150))
        self._search.setPalette(_spal)
        self._search.textChanged.connect(self._filter_items)
        self._search.returnPressed.connect(self._pick_first_visible)
        pl.addWidget(self._search)

        self._plist = QListWidget()
        self._plist.setFrameShape(QFrame.Shape.NoFrame)
        self._plist.setFont(QFont("Rosemary", 11, QFont.Weight.Bold))
        self._plist.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._plist.setVerticalScrollBar(_MetalScrollBar(self._plist))
        self._plist.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self._plist.setCursor(Qt.CursorShape.PointingHandCursor)
        self._plist.viewport().setAutoFillBackground(False)
        _styled(self._plist, """
            QListWidget {
                background: transparent; border: none; outline: 0px; color: #FFFFFF;
            }
            QListWidget::item {
                min-height: 28px; border-radius: 6px; margin: 1px 2px;
                color: #FFFFFF; background-color: transparent;
            }
            QListWidget::item:hover, QListWidget::item:selected {
                background-color: __ACC__; color: #FFFFFF;
            }
            /* Thanh keo doc: dung _MetalScrollBar tu ve (BEO co dinh, kim loai 3D). */
        """)
        self._plist.itemClicked.connect(self._on_pick)
        pl.addWidget(self._plist)

        self._cb._open_search = self._open_search_popup

    def _open_search_popup(self):
        if not getattr(self, "_popup", None):
            return
        cur = self._cb.currentText()
        self._plist.clear()
        for i in range(self._cb.count()):
            t = self._cb.itemText(i)
            it = QListWidgetItem(t)
            it.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self._plist.addItem(it)
            if t == cur:
                self._plist.setCurrentItem(it)
        self._search.blockSignals(True); self._search.clear(); self._search.blockSignals(False)

        w = max(self.width(), 240)
        row_h = 30
        visible = min(max(self._plist.count(), 1), 9)
        self._plist.setFixedHeight(visible * row_h + 4)
        self._popup.setFixedWidth(w)
        self._popup.adjustSize()
        gp = self._cb.mapToGlobal(QPoint(0, self._cb.height() + 4))
        self._popup.move(gp)
        self._popup.show()
        self._popup.raise_()
        self._search.setFocus()
        cur_item = self._plist.currentItem()
        if cur_item is not None:
            self._plist.scrollToItem(cur_item)

    def _filter_items(self, text):
        if not getattr(self, "_plist", None):
            return
        q = (text or "").strip().lower()
        for i in range(self._plist.count()):
            it = self._plist.item(i)
            it.setHidden(bool(q) and (q not in it.text().lower()))

    def _pick_first_visible(self):
        for i in range(self._plist.count()):
            it = self._plist.item(i)
            if not it.isHidden():
                self._on_pick(it)
                return

    def _on_pick(self, item):
        if item is None:
            return
        idx = self._cb.findText(item.text())
        if idx >= 0:
            self._cb.setCurrentIndex(idx)
        try:
            self._popup.hide()
        except Exception:
            pass


# Kinh lup — icon o tim kiem giong tich hop trong popup danh sach giong.
_SVG_SEARCH = (
    '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="#FFFFFF" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">'
    '<circle cx="11" cy="11" r="7"/>'
    '<line x1="20.5" y1="20.5" x2="16.5" y2="16.5"/>'
    '</svg>'
)


class TextInput(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self._border = QColor(255, 255, 255, 90)
        self._focused = False
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(300); self._anim.setEasingCurve(QEasingCurve.Type.InOutCubic)
        self._anim.valueChanged.connect(self._update)

        lo = QVBoxLayout(self); lo.setContentsMargins(14, 12, 14, 12)
        self._txt = QTextEdit()
        self._txt.setFrameShape(QTextEdit.Shape.NoFrame)
        self._txt.setFont(QFont("Rosemary", 12, QFont.Weight.Bold))
        self._txt.viewport().setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        _styled(self._txt, """
            QTextEdit {
                background: transparent; border: none;
                font-family: "Rosemary","Segoe UI",sans-serif;
                font-size: 15px; font-weight: 700; color: #FFFFFF; selection-background-color: __ACC__;
            }
        """)
        from PyQt6.QtGui import QPalette
        _pal = self._txt.palette()
        _pal.setColor(QPalette.ColorRole.PlaceholderText, QColor(255, 255, 255, 255))
        self._txt.setPalette(_pal)
        self._txt.installEventFilter(self)
        lo.addWidget(self._txt)

    def eventFilter(self, obj, e):
        if obj == self._txt:
            if e.type() == e.Type.FocusIn:
                self._focused = True
                self._anim.stop(); self._anim.setStartValue(self._border); self._anim.setEndValue(accent_color(255)); self._anim.start()
            elif e.type() == e.Type.FocusOut:
                self._focused = False
                self._anim.stop(); self._anim.setStartValue(self._border); self._anim.setEndValue(QColor(255, 255, 255, 90)); self._anim.start()
        return super().eventFilter(obj, e)

    def _update(self, c): self._border = c; self.update()

    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(self.rect())
        dd = QPainterPath(); dd.addRoundedRect(r, 12, 12)

        paint_liquid_glass(p, r, radius=12.0, opacity=1.0)

        # Mau vien: dang fade focus -> dung gia tri noi suy cho muot; da on dinh &
        # dang focus -> doc accent SONG moi frame (bam theo gradient nhu cac widget
        # khac), het loi "phai bam cho khac moi dong bo".
        if self._anim.state() == QAbstractAnimation.State.Running:
            _border = self._border
        elif self._focused:
            _border = accent_color(255)
        else:
            _border = QColor(255, 255, 255, 90)
        p.setPen(QPen(_border, 2.5)); p.setBrush(Qt.BrushStyle.NoBrush)
        inset = QPainterPath(); inset.addRoundedRect(r.adjusted(1, 1, -1, -1), 11, 11)
        p.drawPath(inset)

    def setPlaceholderText(self, t): self._txt.setPlaceholderText(t)
    def setPlainText(self, t): self._txt.setPlainText(t)
    def toPlainText(self): return self._txt.toPlainText()
    def clear(self): self._txt.clear()

class LogView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        lo = QVBoxLayout(self); lo.setContentsMargins(8, 8, 8, 8)
        self._txt = QTextEdit()
        self._txt.setReadOnly(True)
        self._txt.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._txt.setFrameShape(QTextEdit.Shape.NoFrame)
        self._txt.viewport().setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        _styled(self._txt, """
            QTextEdit {
                background: transparent; border: none; font-family: Consolas; font-size: 14px; font-weight: 800; color: #00FF80; selection-background-color: __ACC__;
            }
        """)
        lo.addWidget(self._txt)

    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(self.rect())
        dd = QPainterPath(); dd.addRoundedRect(r, 12, 12)

        paint_liquid_glass(p, r, radius=12.0, opacity=1.0)

        p.setPen(QPen(accent_color(220), 2.0)); p.setBrush(Qt.BrushStyle.NoBrush)
        inset = QPainterPath(); inset.addRoundedRect(r.adjusted(1, 1, -1, -1), 11, 11)
        p.drawPath(inset)

    def append(self, t): self._txt.append(t)
    def clear(self): self._txt.clear()
    def verticalScrollBar(self): return self._txt.verticalScrollBar()

class SubtitleDropZone(QWidget):
    file_selected = pyqtSignal(str)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setMinimumHeight(120)
        self.file_path = ""
        self._border = QColor(255, 255, 255, 90)
        self._hover = False
        self._drag = False
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(250)
        self._anim.valueChanged.connect(self._update_border)
        lo = QVBoxLayout(self)
        lo.setContentsMargins(14, 12, 14, 12)
        lo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_icon = QLabel()
        self.lbl_icon.setPixmap(_icon(_SVG_SUBTITLE, 32).pixmap(32, 32))
        self.lbl_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lo.addWidget(self.lbl_icon)
        self.lbl_text = QLabel("Kéo thả hoặc click để tải file phụ đề (.srt, .vtt)")
        self.lbl_text.setStyleSheet("color: #FFFFFF; font-size: 14px; font-weight: 800; letter-spacing: 0.3px;")
        self.lbl_text.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lo.addWidget(self.lbl_text)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setAcceptDrops(True)

    def _update_border(self, c):
        self._border = c
        self.update()

    def enterEvent(self, e):
        self._hover = True
        self._anim.stop()
        self._anim.setStartValue(self._border)
        self._anim.setEndValue(accent_color(230))
        self._anim.start()

    def leaveEvent(self, e):
        self._hover = False
        self._anim.stop()
        self._anim.setStartValue(self._border)
        self._anim.setEndValue(QColor(255, 255, 255, 90))
        self._anim.start()

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            file_name, _ = QFileDialog.getOpenFileName(
                self, "Chọn file phụ đề", "", "Subtitle Files (*.srt *.vtt);;All Files (*)"
            )
            if file_name:
                self.set_file(file_name)

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()
            self._drag = True
            self._border = QColor(0, 255, 120, 255)
            self.update()

    def dragLeaveEvent(self, e):
        self._drag = False
        self._border = accent_color(230) if self._hover else QColor(255, 255, 255, 90)
        self.update()

    def dropEvent(self, e):
        for url in e.mimeData().urls():
            file_name = url.toLocalFile()
            if file_name.lower().endswith(('.srt', '.vtt')):
                self.set_file(file_name)
                break
        self._drag = False
        self._border = accent_color(230) if self._hover else QColor(255, 255, 255, 90)
        self.update()

    def set_file(self, path):
        self.file_path = path
        fn = os.path.basename(path)
        self.lbl_text.setText(f"Đã tải: {fn}")
        self.lbl_text.setStyleSheet("color: #00FF80; font-size: 14px; font-weight: 900; letter-spacing: 0.3px;")
        self.lbl_icon.setPixmap(_icon(_SVG_SAVE, 32).pixmap(32, 32))
        self.file_selected.emit(path)

    def clear_file(self):
        self.file_path = ""
        self.lbl_text.setText("Kéo thả hoặc click để tải file phụ đề (.srt, .vtt)")
        self.lbl_text.setStyleSheet("color: #FFFFFF; font-size: 14px; font-weight: 800; letter-spacing: 0.3px;")
        self.lbl_icon.setPixmap(_icon(_SVG_SUBTITLE, 32).pixmap(32, 32))

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(self.rect())
        dd = QPainterPath(); dd.addRoundedRect(r, 12, 12)
        paint_liquid_glass(p, r, radius=12.0, opacity=1.0)
        # Cung nguyen tac voi TextInput: dang fade -> noi suy; keo-tha -> giu vien
        # xanh bao hieu; dang hover & on dinh -> doc accent SONG (bam gradient).
        if self._anim.state() == QAbstractAnimation.State.Running or self._drag:
            _bcol = self._border
        elif self._hover:
            _bcol = accent_color(230)
        else:
            _bcol = QColor(255, 255, 255, 90)
        pen = QPen(_bcol, 2.5)
        if not self.file_path:
            pen.setStyle(Qt.PenStyle.DashLine)
            pen.setDashPattern([6, 4])
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        inset = QPainterPath(); inset.addRoundedRect(r.adjusted(1, 1, -1, -1), 11, 11)
        p.drawPath(inset)

class ModeCard(QWidget):
    clicked = pyqtSignal()
    def __init__(self, title, desc, svg_str, parent=None):
        super().__init__(parent)
        self.title = title
        self.desc = desc
        self.svg_icon = _icon(svg_str, 36)
        self.setFixedSize(220, 138)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._hover_val = 0.0
        self._press_val = 0.0
        self._anim_hover = QPropertyAnimation(self, b"hover_progress")
        self._anim_hover.setDuration(250)
        self._anim_hover.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim_press = QPropertyAnimation(self, b"press_progress")
        self._anim_press.setDuration(120)
        self._anim_press.setEasingCurve(QEasingCurve.Type.OutBounce)

    @pyqtProperty(float)
    def hover_progress(self): return self._hover_val
    @hover_progress.setter
    def hover_progress(self, v): self._hover_val = v; self.update()

    @pyqtProperty(float)
    def press_progress(self): return self._press_val
    @press_progress.setter
    def press_progress(self, v): self._press_val = v; self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        # Dong nhat 100% voi cac nut 3D kim loai: nen kim loai + bong den 3D o duoi +
        # vien den. Copy y het paint_metal_button (nhu nut bam).
        tone = ((84, 90, 98), (54, 59, 66), (32, 35, 40))
        body_rect = paint_metal_button(p, self.rect(), radius=12.0, hover=self._hover_val, press=self._press_val, accent_edge=False, tone=tone)
        cx = body_rect.center().x()
        cy = body_rect.top() + body_rect.height() * 0.34
        if self.svg_icon:
            isz = 46.0 + 6.0 * self._hover_val
            self.svg_icon.paint(p, QRectF(cx - isz / 2.0, cy - isz / 2.0, isz, isz))
        p.setPen(QColor(255, 255, 255) if self._hover_val > 0.5 else QColor(240, 244, 248))
        p.setFont(QFont("Rosemary", 17, QFont.Weight.Black))
        p.drawText(QRectF(body_rect.left() + 10, body_rect.top() + body_rect.height() * 0.60, body_rect.width() - 20, 34), Qt.AlignmentFlag.AlignCenter, self.title)
        p.end()

    def enterEvent(self, e):
        self._anim_hover.setEndValue(1.0); self._anim_hover.start()
    def leaveEvent(self, e):
        self._anim_hover.setEndValue(0.0); self._anim_hover.start()
    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton: self._anim_press.setEndValue(1.0); self._anim_press.start()
    def mouseReleaseEvent(self, e):
        self._anim_press.setEndValue(0.0); self._anim_press.start()
        if self.rect().contains(e.position().toPoint()):
            play_droplet()
            self.clicked.emit()

class TitleBar(QWidget):
    def __init__(self, parent_window):
        super().__init__(parent_window); self.parent_window = parent_window
        self.setFixedHeight(50); self._drag_origin = None
        lo = QHBoxLayout(self); lo.setContentsMargins(4,0,24,0)

        self.btn_back = IconButton(_SVG_BACK, kind="back", parent=self)
        self.btn_back.clicked.connect(parent_window.go_back)
        self.btn_back.setToolTip("Quay lại chọn Chế độ")
        lo.addWidget(self.btn_back)
        lo.addSpacing(14)

        self.title_bar = QLabel("TTS_Pro_V2.0.6")
        self.title_bar.setFont(QFont("Rosemary", 16, QFont.Weight.Bold))
        self.title_bar.setStyleSheet("color:#FFFFFF; letter-spacing:1.8px; font-weight:900; font-family:\"Rosemary\",\"Segoe UI\",sans-serif; border: none;")

        bt = IconButton(_SVG_MINIMIZE, kind="minimize", parent=self)
        bd = IconButton(_SVG_CLOSE, kind="close", parent=self)

        bt.clicked.connect(parent_window.minimize_window); bd.clicked.connect(parent_window.close_window)
        lo.addWidget(self.title_bar); lo.addStretch(); lo.addWidget(bt); lo.addWidget(bd)

    def set_back_visible(self, visible):
        self.btn_back.setVisible(visible)

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._drag_origin = e.globalPosition().toPoint() - self.parent_window.frameGeometry().topLeft()
    def mouseMoveEvent(self, e):
        if self._drag_origin:
            self.parent_window.move(e.globalPosition().toPoint() - self._drag_origin)
    def mouseReleaseEvent(self, e):
        self._drag_origin = None

class ModeSelector(QWidget):
    mode_selected = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(40, 4, 40, 18)
        main_layout.setSpacing(0)

        caption = QLabel("Chọn Chế Độ Để Bắt Đầu")
        caption.setFont(QFont("Rosemary", 30, QFont.Weight.Black))
        caption.setAlignment(Qt.AlignmentFlag.AlignCenter)
        caption.setStyleSheet("color:#FFFFFF; letter-spacing: 1.6px; font-weight:900; font-family:\"Rosemary\",\"Segoe UI\",sans-serif; border: none; background: transparent;")
        main_layout.addWidget(caption)

        main_layout.addSpacing(22)

        cards_layout = QHBoxLayout()
        cards_layout.setSpacing(26)
        cards_layout.setAlignment(Qt.AlignmentFlag.AlignHCenter)

        self.card_sub = ModeCard(
            "PHỤ ĐỀ",
            "",
            _SVG_SUBTITLE,
            self
        )
        self.card_text = ModeCard(
            "VĂN BẢN",
            "",
            _SVG_SPEECH,
            self
        )

        self.card_sub.clicked.connect(lambda: self.mode_selected.emit("Phụ Đề"))
        self.card_text.clicked.connect(lambda: self.mode_selected.emit("Văn Bản"))

        cards_layout.addWidget(self.card_sub)
        cards_layout.addWidget(self.card_text)
        main_layout.addLayout(cards_layout)

class ModeSelectorWindow(QWidget):
    mode_selected = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowSystemMenuHint | Qt.WindowType.WindowStaysOnTopHint)
        try:
            self.setWindowIcon(app_icon())
        except Exception:
            pass
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        # Ty le vang phi = 1.618 (560 / 346) cho cua so chon che do.
        W, H = 560, 346
        self.resize(W, H)
        mh = QGuiApplication.primaryScreen().availableGeometry()

        start_w, start_h = 432, 267
        start_rect = QRect((mh.width() - W) // 2 + (W - start_w)//2, (mh.height() - H) // 2 + (H - start_h)//2, start_w, start_h)
        end_rect = QRect((mh.width() - W) // 2, (mh.height() - H) // 2, W, H)
        self.setGeometry(start_rect)

        self.glass = GlassPanel(self)
        lo = QVBoxLayout(self)
        lo.setContentsMargins(0, 0, 0, 0)
        lo.addWidget(self.glass)

        self.mode_widget = ModeSelector(self.glass)
        self.mode_widget.mode_selected.connect(self._select_mode)

        main_layout = QVBoxLayout(self.glass)
        main_layout.setContentsMargins(0, 10, 0, 0)

        header = QHBoxLayout()
        header.setContentsMargins(32, 10, 32, 0)
        header.addStretch()
        self.btn_min = IconButton(_SVG_MINIMIZE, "minimize", self)
        self.btn_min.clicked.connect(self.showMinimized)
        header.addWidget(self.btn_min)
        self.btn_close = IconButton(_SVG_CLOSE, "close", self)
        self.btn_close.clicked.connect(QApplication.quit)
        header.addWidget(self.btn_close)

        main_layout.addLayout(header)
        main_layout.addStretch(1)
        main_layout.addWidget(self.mode_widget)
        main_layout.addStretch(1)

        self.setWindowOpacity(0)

        self._expand_group = QParallelAnimationGroup(self)

        self._fade_in = QPropertyAnimation(self, b"windowOpacity")
        self._fade_in.setDuration(520)
        self._fade_in.setStartValue(0.0)
        self._fade_in.setEndValue(1.0)
        self._fade_in.setEasingCurve(QEasingCurve.Type.OutQuad)

        self._scale_in = QPropertyAnimation(self, b"geometry")
        self._scale_in.setDuration(560)
        self._scale_in.setStartValue(start_rect)
        self._scale_in.setEndValue(end_rect)
        self._scale_in.setEasingCurve(QEasingCurve.Type.OutQuint)

        self._expand_group.addAnimation(self._fade_in)
        self._expand_group.addAnimation(self._scale_in)
        self._expand_group.start()
        _ensure_gradient_driver()

        try:
            from PyQt6.QtCore import QTimer
            QTimer.singleShot(50, self._apply_acrylic_init)
        except Exception:
            pass

    def _apply_acrylic_init(self):
        # Khong con dat region cung / acrylic -> cua so trong suot, lop kinh ve
        # khu rang cua cho goc bo tron muot, het vo pixel.
        try:
            from App.core import clear_window_region
            clear_window_region(int(self.winId()))
        except Exception:
            pass

    def _select_mode(self, mode):
        self._fade_out = QPropertyAnimation(self, b"windowOpacity")
        self._fade_out.setDuration(300)
        self._fade_out.setStartValue(self.windowOpacity())
        self._fade_out.setEndValue(0.0)
        self._fade_out.setEasingCurve(QEasingCurve.Type.InCubic)
        def transition():
            self.hide()
            self.mode_selected.emit(mode)
        self._fade_out.finished.connect(transition)
        self._fade_out.start()

class _ColorSwatch(QWidget):
    clicked = pyqtSignal()

    def __init__(self, rgb=None, custom=False, gradient=False, parent=None):
        super().__init__(parent)
        self.setFixedSize(40, 40)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._rgb = rgb
        self._custom = custom
        self._gradient = gradient
        self._selected = False
        self._hover = 0.0
        self._spin = 0.0
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(160)
        self._anim.valueChanged.connect(self._set_hover)
        self._spin_timer = None
        if gradient:
            self._spin_timer = QTimer(self)
            self._spin_timer.setInterval(33)
            self._spin_timer.timeout.connect(self._do_spin)

    def _do_spin(self):
        self._spin = (self._spin + 4.0) % 360.0
        self.update()

    def showEvent(self, e):
        if self._spin_timer is not None and not self._spin_timer.isActive():
            self._spin_timer.start()
        super().showEvent(e)

    def hideEvent(self, e):
        if self._spin_timer is not None and self._spin_timer.isActive():
            self._spin_timer.stop()
        super().hideEvent(e)

    def _set_hover(self, v):
        self._hover = float(v); self.update()

    def set_rgb(self, rgb):
        self._rgb = rgb; self.update()

    def set_custom(self, on):
        self._custom = bool(on); self.update()

    def set_selected(self, on):
        self._selected = bool(on); self.update()

    def enterEvent(self, e):
        self._anim.stop(); self._anim.setStartValue(self._hover)
        self._anim.setEndValue(1.0); self._anim.start()

    def leaveEvent(self, e):
        self._anim.stop(); self._anim.setStartValue(self._hover)
        self._anim.setEndValue(0.0); self._anim.start()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()

    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        lift = 1.6 * self._hover
        r = QRectF(self.rect()).adjusted(5 - lift, 5 - lift, -5 + lift, -5 + lift)
        shadow = QPainterPath(); shadow.addEllipse(r.translated(0, 2.2))
        p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor(0, 0, 0, 175)); p.drawPath(shadow)
        path = QPainterPath(); path.addEllipse(r)
        rr, gg, bb = self._rgb if self._rgb else (200, 200, 200)
        grad = QLinearGradient(r.topLeft(), r.bottomLeft())
        grad.setColorAt(0.0, QColor(min(255, rr + 42), min(255, gg + 42), min(255, bb + 42)))
        grad.setColorAt(0.5, QColor(rr, gg, bb))
        grad.setColorAt(1.0, QColor(int(rr * 0.55), int(gg * 0.55), int(bb * 0.55)))
        p.setBrush(QBrush(grad)); p.drawPath(path)
        spec = QRectF(r.left() + r.width() * 0.2, r.top() + r.height() * 0.14,
                      r.width() * 0.44, r.height() * 0.32)
        sg = QLinearGradient(spec.topLeft(), spec.bottomLeft())
        sg.setColorAt(0.0, QColor(255, 255, 255, int(150 + 60 * self._hover))); sg.setColorAt(1.0, QColor(255, 255, 255, 0))
        sp = QPainterPath(); sp.addEllipse(spec); p.fillPath(sp, sg)
        p.setBrush(Qt.BrushStyle.NoBrush)
        if self._selected:
            p.setPen(QPen(QColor(255, 255, 255, 245), 2.6))
            p.drawEllipse(QRectF(self.rect()).adjusted(1.5, 1.5, -1.5, -1.5))
        else:
            p.setPen(QPen(QColor(8, 9, 11, 220), 1.4))
            p.drawEllipse(r)
        p.end()

class ColorPicker(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(120)
        self.setCursor(Qt.CursorShape.CrossCursor)
        self._h = 210; self._s = 220; self._v = 255
        self._drag = None
        self._last = 0.0
        self._hue_w = 22
        self._gap = 14

    def _rects(self):
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        hue = QRectF(r.right() - self._hue_w, r.top(), self._hue_w, r.height())
        sv = QRectF(r.left(), r.top(), r.width() - self._hue_w - self._gap, r.height())
        return sv, hue

    def sync_from_theme(self):
        if self._drag is not None:
            return
        c = THEME.accent()
        h, s, v, _ = c.getHsv()
        if h is not None and h >= 0:
            self._h = h
        self._s = s; self._v = v
        self.update()

    def _emit(self, save):
        col = QColor.fromHsv(int(self._h) % 360,
                             max(0, min(255, int(self._s))),
                             max(0, min(255, int(self._v))))
        if save:
            play_droplet(); THEME.set_custom(col)
            return
        now = time.time()
        if now - self._last < 0.03:
            return
        self._last = now
        THEME._gradient = False
        THEME._accent = QColor(col.red(), col.green(), col.blue())
        THEME._index = -1
        THEME.themeChanged.emit()

    def _set_from_pos(self, pos):
        sv, hue = self._rects()
        if self._drag == 'hue':
            t = max(0.0, min(1.0, (pos.y() - hue.top()) / max(1.0, hue.height())))
            self._h = int(t * 359)
        else:
            tx = max(0.0, min(1.0, (pos.x() - sv.left()) / max(1.0, sv.width())))
            ty = max(0.0, min(1.0, (pos.y() - sv.top()) / max(1.0, sv.height())))
            self._s = int(tx * 255)
            self._v = int((1.0 - ty) * 255)
        self.update()

    def mousePressEvent(self, e):
        if e.button() != Qt.MouseButton.LeftButton:
            return
        sv, hue = self._rects()
        pos = e.position()
        self._drag = 'hue' if hue.adjusted(-6, 0, 6, 0).contains(pos) else 'sv'
        self._set_from_pos(pos); self._emit(False)

    def mouseMoveEvent(self, e):
        if self._drag:
            self._set_from_pos(e.position()); self._emit(False)

    def mouseReleaseEvent(self, e):
        if self._drag:
            self._set_from_pos(e.position()); self._emit(True); self._drag = None

    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        sv, hue = self._rects()

        sv_path = QPainterPath(); sv_path.addRoundedRect(sv, 12, 12)
        p.save(); p.setClipPath(sv_path)
        base = QColor.fromHsv(int(self._h) % 360, 255, 255)
        gx = QLinearGradient(sv.topLeft(), sv.topRight())
        gx.setColorAt(0.0, QColor(255, 255, 255)); gx.setColorAt(1.0, base)
        p.fillPath(sv_path, QBrush(gx))
        gy = QLinearGradient(sv.topLeft(), sv.bottomLeft())
        gy.setColorAt(0.0, QColor(0, 0, 0, 0)); gy.setColorAt(1.0, QColor(0, 0, 0, 255))
        p.fillPath(sv_path, QBrush(gy))
        mx = sv.left() + (self._s / 255.0) * sv.width()
        my = sv.top() + (1.0 - self._v / 255.0) * sv.height()
        mx = max(sv.left() + 8, min(sv.right() - 8, mx))
        my = max(sv.top() + 8, min(sv.bottom() - 8, my))
        p.setPen(QPen(QColor(0, 0, 0, 210), 2.6)); p.drawEllipse(QPointF(mx, my), 7.0, 7.0)
        p.setPen(QPen(QColor(255, 255, 255, 255), 1.8)); p.drawEllipse(QPointF(mx, my), 7.0, 7.0)
        p.restore()
        p.setPen(QPen(QColor(255, 255, 255, 160), 1.4)); p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPath(sv_path)

        hue_path = QPainterPath(); hue_path.addRoundedRect(hue, hue.width() / 2.0, hue.width() / 2.0)
        p.save(); p.setClipPath(hue_path)
        hg = QLinearGradient(hue.topLeft(), hue.bottomLeft())
        for i in range(7):
            hg.setColorAt(i / 6.0, QColor.fromHsv(int(360 * i / 6) % 360, 255, 255))
        p.fillPath(hue_path, QBrush(hg))
        hy = hue.top() + (self._h / 359.0) * hue.height()
        hy = max(hue.top() + 2, min(hue.bottom() - 2, hy))
        p.setPen(QPen(QColor(0, 0, 0, 210), 3.0)); p.drawLine(QPointF(hue.left() + 1, hy), QPointF(hue.right() - 1, hy))
        p.setPen(QPen(QColor(255, 255, 255, 255), 1.8)); p.drawLine(QPointF(hue.left() + 1, hy), QPointF(hue.right() - 1, hy))
        p.restore()
        p.setPen(QPen(QColor(255, 255, 255, 160), 1.4)); p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPath(hue_path)
        p.end()

class ColorPickerPanel(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        v = QVBoxLayout(self); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(10)
        self._swatches = []
        for r in range(2):
            row = QHBoxLayout(); row.setContentsMargins(0, 0, 0, 0); row.setSpacing(9)
            row.addStretch()
            for c in range(6):
                i = r * 6 + c
                name, rgb = PRESETS[i]
                sw = _ColorSwatch(rgb=rgb, parent=self)
                sw.setToolTip(name)
                sw.clicked.connect(lambda _i=i: self._select_preset(_i))
                row.addWidget(sw); self._swatches.append(sw)
            row.addStretch()
            v.addLayout(row)
        THEME.themeChanged.connect(self._sync)
        self._sync()

    def _select_preset(self, i):
        play_droplet(); THEME.set_preset(i)

    def _sync(self):
        idx = THEME.accent_index()
        for i, sw in enumerate(self._swatches):
            sw.set_selected(i == idx)

class UpdateWorker(QThread):
    """Chạy kiểm tra / tải cập nhật ở luồng nền -> UI không bị đứng hình.

    Phát tín hiệu về luồng UI:
        checked(bool available, dict info)
        progress(int percent)
        downloaded(str path, dict info)
        failed(str message)
    """
    checked = pyqtSignal(bool, dict)
    progress = pyqtSignal(int)
    downloaded = pyqtSignal(str, dict)
    failed = pyqtSignal(str)

    def __init__(self, mode, current_version="", info=None, parent=None):
        super().__init__(parent)
        self._mode = mode            # "check" | "download"
        self._version = current_version
        self._info = dict(info or {})

    def run(self):
        try:
            from App import updater
        except Exception:
            try:
                import updater  # fallback khi sys.path đặt thẳng vào App/
            except Exception as exc:  # noqa: BLE001
                self.failed.emit("Không nạp được bộ cập nhật.")
                return
        try:
            if self._mode == "check":
                info = updater.check_for_update(self._version)
                self.checked.emit(bool(info.get("available")), info)
            else:
                path = updater.download_update(
                    self._info,
                    progress_cb=lambda pct, *_: self.progress.emit(int(pct)),
                )
                self.downloaded.emit(path, self._info)
        except updater.UpdateError as exc:
            self.failed.emit(str(exc))
        except Exception:  # noqa: BLE001
            self.failed.emit("Đã xảy ra l��i khi cập nhật.")


class UpdateButton3D(QWidget):
    """Nút 'Cập Nhật' 3D cao cấp — cùng ngôn ngữ Liquid Glass với PushButton.

    - Viền accent, gradient dọc, dải sáng đỉnh (sheen), lúm xuống khi nhấn (3D).
    - Biết tự đổi trạng thái: idle / checking / available / downloading / ready / error.
    - Khi đang kiểm tra: biểu tượng xoay tròn. Khi tải: thanh tiến độ chạy trong nút.
    - Khi có bản mới: vầng sáng nhị nhàng để thu hút (glow).
    """
    clicked = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._icon = _icon(_SVG_UPDATE, 20)
        self.setMinimumHeight(48)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._state = "idle"
        self._text = "Kiểm Tra Cập Nhật"
        self._pct = 0            # % muc tieu (tu tien trinh tai thuc te)
        self._pct_display = 0.0  # % hien thi -> noi suy 60FPS cho muot
        self._hover_val = 0.0
        self._press_val = 0.0
        self._spin = 0.0
        self._glow = 0.0

        self._anim_hover = QPropertyAnimation(self, b"hover_progress")
        self._anim_hover.setDuration(300)
        self._anim_hover.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim_press = QPropertyAnimation(self, b"press_progress")
        self._anim_press.setDuration(150)
        self._anim_press.setEasingCurve(QEasingCurve.Type.OutBounce)

        # Timer xoay biểu tượng khi kiểm tra / tải.
        self._spin_timer = QTimer(self)
        self._spin_timer.setInterval(16)
        self._spin_timer.timeout.connect(self._tick_spin)

        # Timer nhịp glow khi có bản mới.
        self._glow_timer = QTimer(self)
        self._glow_timer.setInterval(33)
        self._glow_timer.timeout.connect(self._tick_glow)
        self._glow_dir = 1.0

    # --- Thuộc tính animation ---------------------------------------------
    @pyqtProperty(float)
    def hover_progress(self): return self._hover_val
    @hover_progress.setter
    def hover_progress(self, v): self._hover_val = v; self.update()

    @pyqtProperty(float)
    def press_progress(self): return self._press_val
    @press_progress.setter
    def press_progress(self, v): self._press_val = v; self.update()

    def _tick_spin(self):
        # Chay ~60FPS (16ms). Ngoai xoay icon, con NOI SUY % hien thi that muot
        # -> thanh tien trinh 'stream' tu 0% den 100% khong giat cuc.
        self._spin = (self._spin + 6.0) % 360.0
        if self._state == "downloading":
            diff = self._pct - self._pct_display
            if abs(diff) < 0.25:
                self._pct_display = float(self._pct)
            else:
                self._pct_display += diff * 0.20
        self.update()

    def _tick_glow(self):
        self._glow += 0.05 * self._glow_dir
        if self._glow >= 1.0:
            self._glow = 1.0; self._glow_dir = -1.0
        elif self._glow <= 0.0:
            self._glow = 0.0; self._glow_dir = 1.0
        self.update()

    # --- API trạng thái --------------------------------------------------
    def set_state(self, state, text=None, pct=0):
        prev = self._state
        self._state = state
        if text is not None:
            self._text = text
        self._pct = int(pct)
        # Vao trang thai tai moi -> bat dau stream tu 0%. Roi trang thai tai ->
        # dong bo % hien thi = % that (vi du 'ready' hien 100%).
        if state == "downloading" and prev != "downloading":
            self._pct_display = 0.0
        elif state != "downloading":
            self._pct_display = float(self._pct)
        spinning = state in ("checking", "downloading")
        if spinning and not self._spin_timer.isActive():
            self._spin_timer.start()
        elif not spinning and self._spin_timer.isActive():
            self._spin_timer.stop()
        glowing = state in ("available", "ready")
        if glowing and not self._glow_timer.isActive():
            self._glow_timer.start()
        elif not glowing and self._glow_timer.isActive():
            self._glow_timer.stop(); self._glow = 0.0
        self.update()

    def state(self):
        return self._state

    # --- Vẽ nút 3D -------------------------------------------------------
    def paintEvent(self, event):
        """Nut 3D noi KIM LOAI CAO CAP — dung chung ngon ngu voi PushButton/ModeCard.

        Moi trang thai deu giu than kim loai 3D (bong do, sheen dinh, vien
        accent) -> KHONG bao gio bi bien thanh nut phang. Loi chi doi sang
        tone kim loai do, van noi 3D nhu cu.
        """
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        ht = self._hover_val
        st = self._state
        danger = (st == "error")
        muted = (st == "done")
        acc = THEME.accent_rgb()

        # Tone KIM LOAI GRAPHITE cao cap (chrome toi) -> min, sang trong, chuyen nghiep.
        if danger:
            base_tone = metal_tone((172, 54, 54))
        elif muted:
            base_tone = ((74, 79, 87), (50, 54, 61), (30, 33, 39))
        else:
            base_tone = ((98, 104, 114), (60, 65, 73), (34, 37, 43))

        # Vầng sáng phía sau (glow) khi co ban moi / san sang cai.
        if self._glow > 0.0 and not danger and not muted:
            gr_, gg_, gb_ = acc
            grect = QRectF(2, 2, self.width() - 4, self.height() - 6)
            gp = QPainterPath(); gp.addRoundedRect(grect.adjusted(-3, -2, 3, 4), 20, 20)
            rg = QRadialGradient(grect.center(), grect.width() * 0.7)
            a = int(80 * self._glow)
            rg.setColorAt(0.0, QColor(gr_, gg_, gb_, a))
            rg.setColorAt(1.0, QColor(gr_, gg_, gb_, 0))
            p.fillPath(gp, rg)

        # Than nut kim loai 3D (bong do + sheen + VIEN DEN) — giong het nut chinh.
        # accent_edge=False -> paint_metal_button tu ve DUY NHAT 1 vien den sach se.
        body_rect = paint_metal_button(
            p, self.rect(), radius=None,
            hover=self._hover_val, press=self._press_val,
            accent_edge=False, tone=base_tone,
        )
        bk = body_rect.height() / 2.0

        # NUT BIEN THANH THANH TIEN TRINH MAU: to DAM phan % da tai bang accent,
        # clip DUNG than nut -> goc bo khop nut (khong bo qua muc). 60FPS muot.
        if st == "downloading":
            p.save()
            clip = QPainterPath(); clip.addRoundedRect(body_rect, bk, bk)
            p.setClipPath(clip)
            frac = max(0.0, min(1.0, self._pct_display / 100.0))
            done_w = body_rect.width() * frac
            if done_w > 0.5:
                ar2, ag2, ab2 = acc
                fill = QRectF(body_rect.left(), body_rect.top(), done_w, body_rect.height())
                fg = QLinearGradient(0, fill.top(), 0, fill.bottom())
                # TO DAM: accent bao hoa, do net cao (alpha 255).
                fg.setColorAt(0.0, QColor(min(255, ar2 + 58), min(255, ag2 + 58), min(255, ab2 + 58), 255))
                fg.setColorAt(0.5, QColor(ar2, ag2, ab2, 255))
                fg.setColorAt(1.0, QColor(int(ar2 * 0.70), int(ag2 * 0.70), int(ab2 * 0.70), 255))
                p.fillRect(fill, fg)
                # Dai sang dinh (chrome sheen) cua phan da tai.
                top = QRectF(fill.left(), fill.top(), fill.width(), fill.height() * 0.46)
                sg = QLinearGradient(0, top.top(), 0, top.bottom())
                sg.setColorAt(0.0, QColor(255, 255, 255, 160))
                sg.setColorAt(1.0, QColor(255, 255, 255, 0))
                p.fillRect(top, sg)
                # Vach sang dau song tai (chi khi chua day) -> cam giac 'stream'.
                if frac < 0.998:
                    p.setPen(QPen(QColor(255, 255, 255, 225), 2.2))
                    p.drawLine(int(fill.right()), int(fill.top() + 2), int(fill.right()), int(fill.bottom() - 2))
            p.restore()

        # Chu trang tren kim loai graphite toi -> ro net, sang trong o moi trang thai.
        co = QColor(238, 242, 247) if muted else QColor(255, 255, 255)

        # Biểu tượng (xoay khi kiem tra/tai) + chữ, canh giữa.
        p.setPen(co); p.setFont(QFont("Rosemary", 13, QFont.Weight.Black))
        fm = p.fontMetrics()
        label = self._text
        if st == "downloading":
            label = "Đang Tải  %d%%" % int(round(self._pct_display))
        icon_w = 20
        spacing = 9
        avail = body_rect.width() - icon_w - spacing - 20
        disp = fm.elidedText(label, Qt.TextElideMode.ElideRight, max(10, int(avail)))
        txt_w = fm.horizontalAdvance(disp)
        total_w = icon_w + spacing + txt_w
        start_x = body_rect.left() + (body_rect.width() - total_w) / 2
        icon_y = body_rect.top() + (body_rect.height() - icon_w) / 2
        p.save()
        p.translate(start_x + icon_w / 2, icon_y + icon_w / 2)
        if st in ("checking", "downloading"):
            p.rotate(self._spin)
        self._icon.paint(p, QRect(-icon_w // 2, -icon_w // 2, icon_w, icon_w))
        p.restore()
        text_x = start_x + icon_w + spacing
        trect = QRectF(text_x, body_rect.top(), txt_w + 10, body_rect.height())
        # Bong khac chim tinh te -> chu noi khoi cao cap.
        p.setPen(QColor(0, 0, 0, 90))
        p.drawText(trect.translated(0, 1.2), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, disp)
        p.setPen(co)
        p.drawText(trect, Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, disp)
        p.end()

    # --- Tương tác ---------------------------------------------------------
    def enterEvent(self, e):
        self._anim_hover.setEndValue(1.0); self._anim_hover.start()
    def leaveEvent(self, e):
        self._anim_hover.setEndValue(0.0); self._anim_hover.start()
    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._anim_press.setEndValue(1.0); self._anim_press.start()
    def mouseReleaseEvent(self, e):
        self._anim_press.setEndValue(0.0); self._anim_press.start()
        if self.rect().contains(e.position().toPoint()):
            play_droplet()
            self.clicked.emit()


class SettingsPanel(QWidget):
    save_clicked = pyqtSignal(dict)
    close_clicked = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.hide()

        self._opacity = 0.0
        self._hiding = False

        self.card = SettingsCard(self)
        self.card.setFixedSize(500, 452)

        # Hieu ung mo DONG BO 100% ca the (nen + moi widget con) -> dong khong con bong ma.
        self._card_fx = QGraphicsOpacityEffect(self.card)
        self._card_fx.setOpacity(0.0)
        self.card.setGraphicsEffect(self._card_fx)

        self._update_worker = None
        self._update_pkg = None
        self._update_kind = "installer"

        self._anim = QPropertyAnimation(self, b"val_prop")
        self._anim.setDuration(300)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.finished.connect(self._on_hide_finished)

        _outer = QVBoxLayout(self.card)
        _outer.setContentsMargins(0, 0, 0, 0)
        _scroll = QScrollArea(self.card)
        _scroll.setWidgetResizable(True)
        _scroll.setFrameShape(QFrame.Shape.NoFrame)
        _scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        _scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        _scroll.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        _scroll.viewport().setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        _styled(_scroll,
            "QScrollArea{background:transparent;border:none;}"
            "QScrollArea>QWidget>QWidget{background:transparent;}"
            "QScrollBar{width:0px;height:0px;background:transparent;border:none;}"
            "QScrollBar::handle{background:transparent;}"
            "QScrollBar::add-line,QScrollBar::sub-line{width:0px;height:0px;}"
            "QScrollBar::add-page,QScrollBar::sub-page{background:transparent;}")
        _inner = QWidget()
        _inner.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        _outer.addWidget(_scroll)
        _scroll.setWidget(_inner)
        card_layout = QVBoxLayout(_inner)
        card_layout.setContentsMargins(30, 22, 30, 26)
        card_layout.setSpacing(14)
        card_layout.setAlignment(Qt.AlignmentFlag.AlignHCenter)

        header = QHBoxLayout()
        header.setContentsMargins(0, 0, 0, 0)
        title = QLabel("Cài Đặt")
        title.setFont(QFont("Rosemary", 18, QFont.Weight.Bold))
        _styled(title, "color: __ACCT__; letter-spacing: 1.8px; font-weight: 900; font-family: \"Rosemary\",\"Segoe UI\",sans-serif;")

        self.btn_close = IconButton(_SVG_CLOSE, kind="close", parent=self.card)
        self.btn_close.clicked.connect(self.hide_panel)

        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        # Chua khoang trai = be rong nut close -> tieu de can giua TUYET DOI.
        header.addSpacing(self.btn_close.width())
        header.addStretch()
        header.addWidget(title)
        header.addStretch()
        header.addWidget(self.btn_close)
        card_layout.addLayout(header)

        lbl_mau = QLabel("Màu Giao Diện")
        lbl_mau.setStyleSheet("color:#FFFFFF; font-size:14px; font-weight:900; letter-spacing: 1.0px;")
        lbl_mau.setAlignment(Qt.AlignmentFlag.AlignCenter)
        card_layout.addWidget(lbl_mau, 0, Qt.AlignmentFlag.AlignHCenter)

        self.color_picker = ColorPickerPanel(self.card)
        card_layout.addWidget(self.color_picker, 0, Qt.AlignmentFlag.AlignHCenter)

        divider_top = QFrame()
        divider_top.setFrameShape(QFrame.Shape.HLine)
        divider_top.setFixedHeight(1)
        divider_top.setFixedWidth(380)
        _styled(divider_top, "background-color: __ACCSOFT__; border: none;")
        card_layout.addSpacing(4)
        card_layout.addWidget(divider_top, 0, Qt.AlignmentFlag.AlignHCenter)

        # ===== Cap Nhat Ung Dung (nut 3D cao cap) ============================ #
        # Khoi "Cap Nhat" dong khung cao cap, can giua tuyet doi.
        update_box = QFrame(self.card)
        update_box.setObjectName("updateBox")
        update_box.setFixedWidth(408)
        _styled(update_box,
            "#updateBox{background: rgba(255,255,255,0.035);"
            " border: 1px solid __ACCSOFT__; border-radius: 16px;}")
        ub = QVBoxLayout(update_box)
        ub.setContentsMargins(22, 16, 22, 18)
        ub.setSpacing(12)
        ub.setAlignment(Qt.AlignmentFlag.AlignHCenter)

        lbl_update = QLabel("CẬP NHẬT ỨNG DỤNG")
        lbl_update.setStyleSheet("color:#FFFFFF; font-size:13px; font-weight:900; letter-spacing: 1.6px; background: transparent; border: none;")
        lbl_update.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ub.addWidget(lbl_update, 0, Qt.AlignmentFlag.AlignHCenter)

        self.btn_update = UpdateButton3D(update_box)
        self.btn_update.setFixedHeight(50)
        self.btn_update.setFixedWidth(324)
        self.btn_update.clicked.connect(self._on_update_clicked)
        ub.addWidget(self.btn_update, 0, Qt.AlignmentFlag.AlignHCenter)

        self.lbl_update_status = QLabel("Phiên bản hiện tại: v%s" % self._app_version())
        self.lbl_update_status.setWordWrap(True)
        self.lbl_update_status.setFixedWidth(348)
        self.lbl_update_status.setStyleSheet("color:rgba(255,255,255,180); font-size:12px; font-weight:700; letter-spacing:0.3px; background: transparent; border: none;")
        self.lbl_update_status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ub.addWidget(self.lbl_update_status, 0, Qt.AlignmentFlag.AlignHCenter)

        card_layout.addSpacing(4)
        card_layout.addWidget(update_box, 0, Qt.AlignmentFlag.AlignHCenter)

        card_layout.addStretch(1)

        # Da an van ban "Session TikTok" theo yeu cau (chi an hien thi - app van chay 100%).
        self.btn_save = PushButton("Lưu & Áp Dụng", _SVG_SAVE, True, self.card)
        self.btn_save.setFixedSize(220, 48)
        self.btn_save.clicked.connect(self._gui_save)

        btn_layout = QHBoxLayout()
        btn_layout.setContentsMargins(0, 0, 0, 0)
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_save)
        btn_layout.addStretch()

        card_layout.addLayout(btn_layout)

    def _root_dir(self):
        w = self.window()
        rd = getattr(w, "ROOT_DIR", None)
        if rd:
            return rd
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    def _update_status(self, msg):
        # Nhan trang thai Session da an; van giu ham de khong vo luong chay cua app.
        if hasattr(self, "lbl_session_status"):
            self.lbl_session_status.setText(msg)

    @pyqtProperty(float)
    def val_prop(self):
        return self._opacity

    @val_prop.setter
    def val_prop(self, v):
        self._opacity = max(0.0, min(1.0, v))
        self.card._opacity = 1.0
        self._card_fx.setEnabled(self._opacity < 0.999)
        self._card_fx.setOpacity(self._opacity)
        self.card.update()
        cx = (self.width() - self.card.width()) // 2
        cy = (self.height() - self.card.height()) // 2
        offset = int(50 * (1.0 - v))
        self.card.move(cx, cy + offset)
        self.update()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        v = self._opacity
        self.card._opacity = 1.0
        self._card_fx.setEnabled(v < 0.999)
        self._card_fx.setOpacity(v)
        self.card.update()
        cx = (self.width() - self.card.width()) // 2
        cy = (self.height() - self.card.height()) // 2
        offset = int(50 * (1.0 - v))
        self.card.move(cx, cy + offset)

    def paintEvent(self, event):

        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        _scrim_path = QPainterPath()
        _scrim_path.addRoundedRect(QRectF(self.rect()).adjusted(0.8, 0.8, -0.8, -0.8), 26.0, 26.0)
        p.setClipPath(_scrim_path)
        p.fillRect(self.rect(), QColor(6, 9, 16, int(150 * self._opacity)))
        p.end()

    def show_panel(self, conf):
        self._update_status("Tự động lấy danh sách Session ID từ GitHub khi tạo TTS. Không dùng Login Chrome.")

        self._hiding = False
        self.show()
        self.raise_()
        self._anim.stop()
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.setDuration(260)
        self._anim.setStartValue(self._opacity)
        self._anim.setEndValue(1.0)
        self._anim.start()

    def hide_panel(self):
        self._anim.stop()
        self._hiding = True
        self._anim.setEasingCurve(QEasingCurve.Type.InCubic)
        self._anim.setDuration(150)
        self._anim.setStartValue(self._opacity)
        self._anim.setEndValue(0.0)
        self._anim.start()

    def _on_hide_finished(self):
        # Chi xu ly khi dang DONG -> an NGAY + ep cha ve lai -> KHONG con bong ma 1-2s.
        if self._hiding:
            self._hiding = False
            self._opacity = 0.0
            self.card._opacity = 1.0
            self._card_fx.setEnabled(True)
            self._card_fx.setOpacity(0.0)
            self.hide()
            pw = self.parentWidget()
            if pw is not None:
                pw.update()
            self.close_clicked.emit()

    def _gui_save(self):
        play_droplet()
        data = {}
        self.save_clicked.emit(data)
        self.hide_panel()

    # ===== Auto-Update ==================================================== #
    def _app_version(self):
        """Phiên bản hiện tại: ưu tiên App.py, fallback changelog.json."""
        try:
            import App as _appmod
            v = getattr(_appmod, "APP_VERSION", None)
            if v:
                return str(v)
        except Exception:
            pass
        try:
            return str(read_changelog().get("version", "2.0.6"))
        except Exception:
            return "2.0.6"

    def _on_update_clicked(self):
        """Điều phối theo trạng thái nút 3D: kiểm tra -> tải -> cài đặt lại."""
        st = self.btn_update.state()
        if st in ("checking", "downloading"):
            return  # đang bận -> bỏ qua nhấn thêm
        if st == "available":
            self._start_download()
            return
        if st == "ready" and self._update_pkg:
            self._apply_update()
            return
        # idle / done / error -> kiểm tra lại
        self._start_check()

    def _start_check(self):
        self.btn_update.set_state("checking", "Đang Kiểm Tra...")
        self.lbl_update_status.setText("Đang kết nối máy chủ cập nhật...")
        self._update_worker = UpdateWorker("check", current_version=self._app_version(), parent=self)
        self._update_worker.checked.connect(self._on_checked)
        self._update_worker.failed.connect(self._on_update_failed)
        self._update_worker.start()

    def _on_checked(self, available, info):
        if available:
            ver = info.get("version", "")
            self._update_info = dict(info)
            self._update_kind = info.get("kind", "installer")
            notes = info.get("notes", "").strip()
            self.btn_update.set_state("available", "Tải Bản Mới  v%s" % ver)
            # Update = Yes (bắt buộc) -> KHÔNG so phiên bản, TỰ ĐỘNG tải ngay.
            if info.get("force"):
                self.lbl_update_status.setText(
                    ("Bắt buộc cập nhật v%s — đang tự động tải..." % ver)
                    + (("  " + notes) if notes else ""))
                self._start_download()
                return
            msg = "Đã có phiên bản v%s." % ver
            if notes:
                msg += "  " + notes
            self.lbl_update_status.setText(msg)
        else:
            self.btn_update.set_state("done", "Đã Là Mới Nhất")
            self.lbl_update_status.setText("Bạn đang dùng phiên bản mới nhất (v%s)." % self._app_version())

    def _start_download(self):
        info = getattr(self, "_update_info", None)
        if not info:
            self._start_check()
            return
        self.btn_update.set_state("downloading", "Đang Tải", pct=0)
        self.lbl_update_status.setText("Đang tải gói cập nhật an toàn (HTTPS)...")
        self._update_worker = UpdateWorker("download", info=info, parent=self)
        self._update_worker.progress.connect(self._on_progress)
        self._update_worker.downloaded.connect(self._on_downloaded)
        self._update_worker.failed.connect(self._on_update_failed)
        self._update_worker.start()

    def _on_progress(self, pct):
        self.btn_update.set_state("downloading", pct=pct)

    def _on_downloaded(self, path, info):
        self._update_pkg = path
        self._update_kind = info.get("kind", "installer")
        self.btn_update.set_state("ready", "Cài Đặt & Khởi Động Lại")
        self.lbl_update_status.setText("✓ Đã tải & xác minh gói chuẩn. Sẵn sàng cài đặt.")
        # Update = Yes (bắt buộc) -> tự động cài luôn cho trọn chu trình.
        if info.get("force"):
            self.lbl_update_status.setText("✓ Đã xác minh. Tự động cài đặt & khởi động lại...")
            QTimer.singleShot(900, self._apply_update)

    def _apply_update(self):
        self.lbl_update_status.setText("Đang áp dụng bản cập nhật...")
        try:
            try:
                from App import updater
            except Exception:
                import updater
            try:
                accent = THEME.accent_rgb()
            except Exception:
                accent = (255, 0, 0)
            updater.apply_update_and_restart(
                self._update_pkg, self._update_kind,
                accent=accent, install_dir=self._root_dir())
        except Exception as exc:  # noqa: BLE001
            self._on_update_failed(str(exc))

    def _on_update_failed(self, msg):
        self.btn_update.set_state("error", "Thử Lại")
        self.lbl_update_status.setText(str(msg))

CONFIG_SCHEMA_VERSION = 4
DEFAULT_CONFIG = {
    "config_version": CONFIG_SCHEMA_VERSION,
    "provider": "TikTok",
    "voice": "Thanh Niên Tự Tin",
    "speed": 120,
    "pitch": True,
    "mute_sound": False,
    "bg_opacity": 100,
    "che_do": "",
    "last_text": "",
    "last_subtitle": "",
    "output_dir": "",
    "use_cache": True,
    "concurrency": 256,
    "hedge_ms": 500,
    "enable_acrylic": True,
}


def migrate_config(old_config: dict) -> dict:
    new = dict(DEFAULT_CONFIG)
    if isinstance(old_config, dict):
        new.update(old_config)
    if "speed_val" in new and "speed" not in old_config:
        new["speed"] = new.pop("speed_val")
    new["config_version"] = CONFIG_SCHEMA_VERSION
    return new


class MainWindow(QWidget):
    back_clicked = pyqtSignal()

    def __init__(self, mode=None):
        super().__init__()
        self.initial_mode = mode
        self.mode = mode

        self.ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.CONFIG_PATH = os.path.join(self.ROOT_DIR, "config.json")

        self.config = dict(DEFAULT_CONFIG)
        if os.path.exists(self.CONFIG_PATH):
            try:
                with open(self.CONFIG_PATH, "r", encoding="utf-8") as f:
                    self.config = migrate_config(json.load(f))
            except Exception:
                self.config = dict(DEFAULT_CONFIG)

        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowSystemMenuHint)
        try:
            self.setWindowIcon(app_icon())
        except Exception:
            pass
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        mh = QGuiApplication.primaryScreen().availableGeometry()
        # Ty le vang phi = 1.618 (778/480 va 970/600) cho cua so chinh.
        if self.mode is None:
            W, H = 720, 540
        else:
            # Giao dien lam viec: noi rong vua du de 4 nut hanh dong nam can xung 1 hang.
            W, H = 772, 640
        self.resize(W, H)
        self._cx = (mh.width() - W) // 2
        self._cy = (mh.height() - H) // 2

        self._worker = None
        self._prev_pos = None
        self._fade_mode = QGraphicsOpacityEffect(self)
        self._fade_workspace = QGraphicsOpacityEffect(self)
        self._fade_mode.setOpacity(1.0)
        self._fade_workspace.setOpacity(1.0)
        self.glass = GlassPanel(self)
        lo = QVBoxLayout(self); lo.setContentsMargins(0,0,0,0); lo.addWidget(self.glass)
        self._build_ui()
        if self.page_mode_select is not None:
            self.page_mode_select.setGraphicsEffect(self._fade_mode)
        if self.page_workspace is not None:
            self.page_workspace.setGraphicsEffect(self._fade_workspace)

        self._fade_mode.setEnabled(False)
        self._fade_workspace.setEnabled(False)
        self.load_config_to_ui()
        self._animate_in()

    def _update_mask(self):
        # Khong dung mask/region cung (gay vo pixel goc). Cua so trong suot +
        # lop kinh ve antialiasing -> goc bo tron muot tren Win10/Win11.
        self.clearMask()
        try:
            from App.core import clear_window_region
            clear_window_region(int(self.winId()))
        except Exception:
            pass

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_mask()
        if hasattr(self, "_settings_panel"):
            self._settings_panel.setGeometry(self.rect())
        if hasattr(self, "_about_panel"):
            self._about_panel.setGeometry(self.rect())

    def _animate_in(self):
        # Chi fade windowOpacity (GPU composited) -> khong resize/relayout moi frame
        # -> sieu muot, ~0% CPU.
        if self.mode is None:
            W, H = 778, 480
        else:
            W, H = 970, 600
        self.setGeometry(QRect(self._cx, self._cy, W, H))
        self.setWindowOpacity(0)
        a1 = QPropertyAnimation(self, b"windowOpacity")
        a1.setDuration(200); a1.setStartValue(0.0); a1.setEndValue(1.0); a1.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._enter_anim = a1; a1.start()

    def _build_ui(self):
        lo = QVBoxLayout(self.glass); lo.setContentsMargins(0,0,0,0); lo.setSpacing(0)
        self.title_bar = TitleBar(self); lo.addWidget(self.title_bar)

        self.stack = QStackedWidget(self)
        lo.addWidget(self.stack)

        self.page_mode_select = ModeSelector(self)
        self.page_mode_select.mode_selected.connect(self.select_mode_and_switch)
        self.stack.addWidget(self.page_mode_select)

        self.page_workspace = QWidget(self)
        self.stack.addWidget(self.page_workspace)

        ln = QVBoxLayout(self.page_workspace); ln.setContentsMargins(22, 8, 22, 14); ln.setSpacing(8)

        col_layout = QHBoxLayout()
        col_layout.setSpacing(0)

        bp_tts = GlassBox()
        lbp_tts = QVBoxLayout(bp_tts); lbp_tts.setContentsMargins(20, 12, 20, 14); lbp_tts.setSpacing(10)

        self.lbl_title = QLabel("Cấu Hình Text To Speech")
        self.lbl_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        _styled(self.lbl_title, """
            color: __ACCT__;
            font-size: 19px;
            font-weight: 900;
            letter-spacing: 1.1px;
            border: none;
            background: transparent;
            padding: 0;
            font-family: "Rosemary","Segoe UI",sans-serif;
        """)
        lbp_tts.addWidget(self.lbl_title, 0, Qt.AlignmentFlag.AlignCenter)

        h_controls = QHBoxLayout()
        h_controls.setSpacing(20)

        # ===== O chon Nha Cung Cap (TikTok / Inworld) — cung style ComboBox ===== #
        vlp = QVBoxLayout()
        vlp.setSpacing(8)
        l_provider = QLabel("Nhà Cung Cấp")
        l_provider.setAlignment(Qt.AlignmentFlag.AlignCenter)
        l_provider.setStyleSheet("color:#FFFFFF; font-size:15px; font-weight:900; letter-spacing: 1.5px; border: none; background: transparent;")
        vlp.addWidget(l_provider, 0, Qt.AlignmentFlag.AlignHCenter)

        self.combo_provider = ComboBox()
        self.combo_provider.addItems(list(PROVIDERS))
        self.combo_provider.setFixedWidth(170)
        vlp.addWidget(self.combo_provider, 0, Qt.AlignmentFlag.AlignHCenter)
        h_controls.addLayout(vlp)

        vl = QVBoxLayout()
        vl.setSpacing(8)
        l_voice = QLabel("Giọng Đọc")
        l_voice.setAlignment(Qt.AlignmentFlag.AlignCenter)
        l_voice.setStyleSheet("color:#FFFFFF; font-size:15px; font-weight:900; letter-spacing: 1.5px; border: none; background: transparent;")
        vl.addWidget(l_voice, 0, Qt.AlignmentFlag.AlignHCenter)

        self.combo_voice = ComboBox(searchable=True)
        self.combo_voice.addItems(_voice_items_for_provider("TikTok"))
        self.combo_voice.setFixedWidth(240)
        vl.addWidget(self.combo_voice, 0, Qt.AlignmentFlag.AlignHCenter)
        h_controls.addLayout(vl)

        # Ket noi SAU khi combo da ton tai -> tranh fire som luc addItems.
        self.combo_provider._cb.currentTextChanged.connect(self._on_provider_changed)

        tl = QVBoxLayout()
        tl.setSpacing(8)

        hb = QHBoxLayout()
        l_speed = QLabel("Tốc Độ")
        l_speed.setStyleSheet("color:#FFFFFF; font-size:15px; font-weight:900; letter-spacing: 1.5px; border: none; background: transparent;")

        vl_lbl = QLabel("1.00x")
        vl_lbl.setFixedWidth(54)
        vl_lbl.setAlignment(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft)
        _styled(vl_lbl, "color: __ACCT__; font-weight:900; font-size:18px; border: none; background: transparent; letter-spacing: 0.3px;")

        hb.addStretch()
        hb.addWidget(l_speed)
        hb.addSpacing(12)
        hb.addWidget(vl_lbl)
        hb.addStretch()
        tl.addLayout(hb)

        sl_container = QWidget()
        sl_container.setFixedHeight(42)
        sl_layout = QVBoxLayout(sl_container)
        sl_layout.setContentsMargins(0, 0, 0, 0)
        sl_layout.setAlignment(Qt.AlignmentFlag.AlignVCenter)

        self.slider_speed = Slider(step=5)
        self.slider_speed.setRange(50, 200)
        self.slider_speed.setValue(100)
        self.slider_speed.setMinimumWidth(170)
        self.slider_speed.setMaximumWidth(220)
        self.slider_speed.valueChanged.connect(lambda v, l=vl_lbl: l.setText(f"{v/100:.2f}x"))
        sl_layout.addWidget(self.slider_speed, 0, Qt.AlignmentFlag.AlignHCenter)

        tl.addWidget(sl_container)
        h_controls.addLayout(tl, 1)

        t2 = QVBoxLayout()
        t2.setSpacing(8)

        hb2 = QHBoxLayout()
        l_cd = QLabel("Cao Độ")
        l_cd.setStyleSheet("color:#FFFFFF; font-size:15px; font-weight:900; letter-spacing: 1.5px; border: none; background: transparent;")
        hb2.addStretch()
        hb2.addWidget(l_cd)
        hb2.addStretch()
        t2.addLayout(hb2)

        sw_container = QWidget()
        sw_container.setFixedHeight(42)
        sw_container_layout = QHBoxLayout(sw_container)
        sw_container_layout.setContentsMargins(0, 0, 0, 0)
        sw_container_layout.setSpacing(10)
        sw_container_layout.setAlignment(Qt.AlignmentFlag.AlignVCenter)

        self.switch_pitch = ToggleSwitch()
        sw_container_layout.addStretch()
        sw_container_layout.addWidget(self.switch_pitch)
        sw_container_layout.addStretch()

        t2.addWidget(sw_container)
        h_controls.addLayout(t2)

        lbp_tts.addLayout(h_controls)
        col_layout.addWidget(bp_tts)
        ln.addLayout(col_layout)

        self.input_text = TextInput()
        self.input_text.setPlaceholderText("Nhập văn bản cần tổng hợp giọng nói...")
        self.input_text.setFixedHeight(84)

        self.drop_subtitle = SubtitleDropZone()
        self.drop_subtitle.setFixedHeight(84)

        ln.addWidget(self.input_text)
        ln.addWidget(self.drop_subtitle)

        # === HÀNG HÀNH ĐỘNG HỢP NHẤT: 4 nút trên CÙNG MỘT hàng, cân bằng tuyệt đối ===
        # Thứ tự chuẩn: [D:/] [Mở Thư Mục] [Lưu Cấu Hình] [Tạo Ngay]
        self.output_dir = self.config.get("output_dir", "") or ""

        self.btn_output = PushButton("Chọn Đầu Ra", _SVG_FOLDER, False)
        self.btn_output.clicked.connect(self._choose_output_dir)

        self.btn_open_output = PushButton("Mở Thư Mục", _SVG_FOLDER_OPEN, False)
        self.btn_open_output.clicked.connect(self._open_output_dir)

        self.btn_save = PushButton("Lưu Cấu Hình", _SVG_SAVE, False)
        self.btn_save.clicked.connect(self.save_config)

        self.btn_generate = PushButton("Tạo Ngay", _SVG_BOLT, True)
        self.btn_generate.clicked.connect(self.start_generation)

        action_row = QHBoxLayout()
        action_row.setContentsMargins(0, 0, 0, 0)
        action_row.setSpacing(12)
        for _btn in (self.btn_output, self.btn_open_output, self.btn_save, self.btn_generate):
            _btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            _btn.setMinimumWidth(0)
            _btn.setFixedHeight(50)
            action_row.addWidget(_btn, 1)  # stretch = 1 cho từng nút -> rộng bằng nhau chuẩn xác
        ln.addLayout(action_row)
        self._refresh_output_button()

        # Một thanh tiến trình duy nhất: TTS / Audio Core RAM.
        self.progress = StackedProgressBar()
        self.progress.setRange(0, 100); self.progress.reset_stages()
        ln.addWidget(self.progress)

        self.log_view = LogView()
        ln.addWidget(self.log_view, 1)

        bottom_bar = QHBoxLayout()
        bottom_bar.setContentsMargins(2, 0, 2, 0)
        bottom_bar.setSpacing(10)

        self.btn_settings = SettingsButton(self)
        self.btn_settings.clicked.connect(self.open_settings)
        bottom_bar.addWidget(self.btn_settings)

        self.btn_info = IconButton(_SVG_INFO, kind="info", parent=self, side=40)
        self.btn_info.clicked.connect(self.open_about)
        bottom_bar.addWidget(self.btn_info)

        bottom_bar.addStretch()

        # ===== Thanh phát xem trước CAO CẤP: play/pause + seek + thời gian =====
        self._preview_updating = False
        self.preview_bar = QWidget()
        _pv = QHBoxLayout(self.preview_bar)
        _pv.setContentsMargins(0, 0, 0, 0); _pv.setSpacing(10)
        self.btn_preview = PushButton("Nghe Thử", _SVG_PLAY_FILLED, False)
        self.btn_preview.setFixedWidth(150); self.btn_preview.setFixedHeight(44)
        self.btn_preview.clicked.connect(self._toggle_preview)
        _pv.addWidget(self.btn_preview)
        self.preview_seek = Slider(step=1)
        self.preview_seek.setRange(0, 0)
        self.preview_seek.valueChanged.connect(self._on_preview_seek_changed)
        _pv.addWidget(self.preview_seek, 1)
        self.preview_time = QLabel("0:00 / 0:00")
        self.preview_time.setStyleSheet(
            "color: rgba(255,255,255,210); font-family:'Rosemary'; font-size:13px;")
        _pv.addWidget(self.preview_time)
        self.preview_bar.hide()
        bottom_bar.addWidget(self.preview_bar, 1)

        ln.addLayout(bottom_bar)

        if self.mode is None:
            self.stack.setCurrentIndex(0)
            self.title_bar.set_back_visible(False)
        else:
            self.stack.setCurrentIndex(1)
            self.title_bar.set_back_visible(True)
            self.set_mode(self.mode)

        self._settings_panel = SettingsPanel(self)
        self._settings_panel.save_clicked.connect(self.apply_settings)
        self._settings_panel.close_clicked.connect(self._disable_bg_blur)
        self._about_panel = AboutPanel(self)
        self._about_panel.setGeometry(self.rect())
        self._preview_bytes = None
        self._player = None
        self._bg_blur = None
        self._prewarmed = False
        self._kick_prewarm()

    def save_config(self):
        self.config["provider"] = self.combo_provider.currentText()
        self.config["voice"] = self.combo_voice.currentText()
        self.config["speed"] = self.slider_speed.value()
        self.config["pitch"] = self.switch_pitch.isChecked()
        self.config["output_dir"] = getattr(self, "output_dir", "") or ""
        self.config["che_do"] = self.mode or "Văn Bản"
        try:
            self.config["last_text"] = self.input_text.toPlainText()
        except Exception:
            pass
        try:
            if self.drop_subtitle.file_path:
                self.config["last_subtitle"] = self.drop_subtitle.file_path
        except Exception:
            pass

        self._write_config()

    def _write_config(self):
        from App.theme import THEME
        on_disk = {}
        try:
            if os.path.exists(self.CONFIG_PATH):
                with open(self.CONFIG_PATH, "r", encoding="utf-8") as f:
                    on_disk = json.load(f)
        except Exception:
            on_disk = {}
        on_disk.update(self.config)
        on_disk["accent_color"] = THEME.accent_hex()
        on_disk["accent_index"] = THEME.accent_index()
        on_disk["liquid_refraction"] = round(THEME.refraction(), 3)
        on_disk["liquid_chromatic"] = bool(THEME.chromatic())
        on_disk["liquid_engine"] = THEME.engine()
        self.config = on_disk
        try:
            with open(self.CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
        except Exception as e:
            self.log_message(f"[-] Lỗi lưu cấu hình: {e}")

    def open_settings(self):
        play_droplet()

        try:
            if self._bg_blur is not None:
                self._bg_blur.setEnabled(False)
            self.glass.setGraphicsEffect(None)
        except Exception:
            pass
        self._settings_panel.show_panel(self.config)

    def _disable_bg_blur(self):

        try:
            if self._bg_blur is not None:
                self._bg_blur.setEnabled(False)
            self.glass.setGraphicsEffect(None)
        except Exception:
            pass

    def open_about(self):
        play_droplet()
        self._about_panel.setGeometry(self.rect())
        self._about_panel.show_panel()

    def _fmt_ms(self, ms):
        s = max(0, int(ms)) // 1000
        return f"{s // 60}:{s % 60:02d}"

    def _kick_prewarm(self):
        # Làm nóng DNS+TCP+TLS trong nền -> request đầu tiên không dính độ trễ
        # handshake ('bấm phát xong luôn').
        if getattr(self, "_prewarmed", False):
            return
        self._prewarmed = True
        def _bg():
            try:
                from Speech.audio_engines import prewarm_network
                prewarm_network()
            except Exception:
                pass
        try:
            threading.Thread(target=_bg, name="tts-prewarm", daemon=True).start()
        except Exception:
            pass

    def _ensure_player(self):
        if getattr(self, "_player", None) is None:
            from PyQt6.QtMultimedia import QMediaPlayer, QAudioOutput
            self._audio_out = QAudioOutput()
            self._audio_out.setVolume(1.0)
            self._player = QMediaPlayer()
            self._player.setAudioOutput(self._audio_out)
            self._player.positionChanged.connect(self._on_preview_position)
            self._player.durationChanged.connect(self._on_preview_duration)
            self._player.playbackStateChanged.connect(self._on_preview_state)
            self._player.mediaStatusChanged.connect(self._on_preview_media_status)

    def _set_preview_playing(self, playing):
        btn = getattr(self, "btn_preview", None)
        if btn is None:
            return
        btn._icon = _icon(_SVG_PAUSE if playing else _SVG_PLAY_FILLED)
        btn._text = "Tạm Dừng" if playing else "Nghe Thử"
        btn.update()

    def _hide_preview(self):
        try:
            if getattr(self, "_player", None) is not None:
                self._player.stop()
        except Exception:
            pass
        self._preview_bytes = None
        bar = getattr(self, "preview_bar", None)
        if bar is not None:
            bar.hide()
        self._set_preview_playing(False)

    def _load_preview(self, autoplay=False):
        # ��ƯỜNG NẠP DUY NHẤT: reset sạch nguồn cũ rồi nạp lại -> triệt tiêu lỗi
        # preview phát lại 2 lần (âm cũ còn k���t trong player/buffer).
        if not getattr(self, "_preview_bytes", None):
            return
        try:
            self._ensure_player()
            self._player.stop()
            try:
                self._player.setSourceDevice(None)
            except Exception:
                pass
            old_buf = getattr(self, "_buf", None)
            if old_buf is not None:
                try:
                    old_buf.close()
                except Exception:
                    pass
            self._buf = QBuffer(self)
            self._buf.setData(QByteArray(self._preview_bytes))
            self._buf.open(QIODevice.OpenModeFlag.ReadOnly)
            self._player.setSourceDevice(self._buf, QUrl("preview.wav"))
            self._preview_updating = True
            self.preview_seek.setRange(0, 0)
            self.preview_seek.setValue(0)
            self._preview_updating = False
            self.preview_time.setText("0:00 / 0:00")
            self._set_preview_playing(False)
            if autoplay:
                self._player.play()
        except Exception:
            pass

    def _toggle_preview(self):
        if not getattr(self, "_preview_bytes", None):
            return
        try:
            from PyQt6.QtMultimedia import QMediaPlayer
            self._ensure_player()
            st = self._player.playbackState()
            if st == QMediaPlayer.PlaybackState.PlayingState:
                self._player.pause()
                return
            if self._player.mediaStatus() == QMediaPlayer.MediaStatus.EndOfMedia:
                self._player.setPosition(0)
            self._player.play()
        except Exception:
            pass

    def _on_preview_seek_changed(self, val):
        if getattr(self, "_preview_updating", False):
            return
        if getattr(self, "_player", None) is not None:
            self._player.setPosition(int(val))

    def _on_preview_position(self, pos):
        seek = getattr(self, "preview_seek", None)
        if seek is None:
            return
        if not seek._pressed:
            self._preview_updating = True
            seek.setValue(int(pos))
            self._preview_updating = False
        dur = self._player.duration() if getattr(self, "_player", None) else 0
        self.preview_time.setText(f"{self._fmt_ms(pos)} / {self._fmt_ms(dur)}")

    def _on_preview_duration(self, dur):
        seek = getattr(self, "preview_seek", None)
        if seek is None:
            return
        self._preview_updating = True
        seek.setRange(0, max(0, int(dur)))
        self._preview_updating = False
        pos = self._player.position() if getattr(self, "_player", None) else 0
        self.preview_time.setText(f"{self._fmt_ms(pos)} / {self._fmt_ms(dur)}")

    def _on_preview_state(self, st):
        from PyQt6.QtMultimedia import QMediaPlayer
        self._set_preview_playing(st == QMediaPlayer.PlaybackState.PlayingState)

    def _on_preview_media_status(self, status):
        from PyQt6.QtMultimedia import QMediaPlayer
        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            self._set_preview_playing(False)
            seek = getattr(self, "preview_seek", None)
            if seek is not None:
                self._preview_updating = True
                seek.setValue(seek.maximum())
                self._preview_updating = False

    def apply_settings(self, data):
        self.config.update(data)
        self._write_config()
        if "bg_opacity" in data:
            self.update_opacity(int(data["bg_opacity"]))

    def update_opacity(self, value):
        from App.core import set_bg_opacity
        set_bg_opacity(int(value))
        self.update()
        if hasattr(self, "glass") and self.glass is not None:
            self.glass.update()
        if hasattr(self, "_settings_panel") and self._settings_panel is not None:
            self._settings_panel.update()

    def showEvent(self, event):
        super().showEvent(event)
        self._update_mask()
        try:
            from App.core import get_bg_opacity, _apply_acrylic
            _apply_acrylic(int(self.winId()), get_bg_opacity() / 100.0)
        except Exception:
            pass

    def _on_provider_changed(self, provider):
        """Doi nha cung cap -> nap lai danh sach giong tuong ung (giu style)."""
        if not hasattr(self, "combo_voice"):
            return
        self.combo_voice._cb.blockSignals(True)
        self.combo_voice._cb.clear()
        self.combo_voice.addItems(_voice_items_for_provider(provider))
        if provider == "Inworld":
            idx = self.combo_voice._cb.findText(DEFAULT_INWORLD_LABEL)
            if idx >= 0:
                self.combo_voice._cb.setCurrentIndex(idx)
        self.combo_voice._cb.blockSignals(False)
        self.combo_voice.update()

    def load_config_to_ui(self):
        prov = self.config.get("provider", "TikTok")
        idx_p = self.combo_provider._cb.findText(prov)
        if idx_p >= 0:
            self.combo_provider._cb.setCurrentIndex(idx_p)
        self.combo_voice._cb.blockSignals(True)
        self.combo_voice._cb.clear()
        self.combo_voice.addItems(_voice_items_for_provider(prov))
        self.combo_voice._cb.blockSignals(False)

        default_voice = DEFAULT_INWORLD_LABEL if prov == "Inworld" else "Cô Gái Hoạt Ngôn"
        idx_voice = self.combo_voice._cb.findText(self.config.get("voice", default_voice))
        if idx_voice >= 0:
            self.combo_voice._cb.setCurrentIndex(idx_voice)

        self.slider_speed.setValue(self.config.get("speed", 100))
        self.switch_pitch.setChecked(self.config.get("pitch", True))

        self.update_opacity(int(self.config.get("bg_opacity", 100)))

        try:
            _last_text = self.config.get("last_text", "")
            if _last_text:
                self.input_text.setPlainText(_last_text)
        except Exception:
            pass
        try:
            _last_sub = self.config.get("last_subtitle", "")
            if _last_sub and os.path.exists(_last_sub):
                self.drop_subtitle.set_file(_last_sub)
        except Exception:
            pass
        try:
            self.output_dir = self.config.get("output_dir", "") or ""
            self._refresh_output_button()
        except Exception:
            pass

    def log_message(self, t):
        if t == getattr(self, "_last_log", None):
            return
        self._last_log = t
        self.log_view.append(t)
        self.log_view.verticalScrollBar().setValue(self.log_view.verticalScrollBar().maximum())

    def _refresh_output_button(self):
        # Hien thi duong dan dau ra ngay tren nut "Chon Dau Ra".
        d = getattr(self, "output_dir", "") or ""
        if d:
            name = os.path.basename(d.rstrip("/\\")) or d
            if name.endswith(":"):  # o dia goc (vd 'D:') -> hien thi 'D:/' cho dep & ro nghia
                name = name + "/"
            self.btn_output._text = name
            self.btn_output.setToolTip(d)
        else:
            self.btn_output._text = "Chọn Đầu Ra"
            self.btn_output.setToolTip("")
        try:
            self.btn_output.update()
        except Exception:
            pass

    def _choose_output_dir(self):
        try:
            d = QFileDialog.getExistingDirectory(self, "Chọn thư mục đầu ra", self.output_dir or self.ROOT_DIR)
        except Exception:
            d = ""
        if d:
            self.output_dir = d
            self._refresh_output_button()
            self.config["output_dir"] = d
            try:
                self._write_config()
            except Exception:
                pass

    def _open_output_dir(self):
        d = getattr(self, "output_dir", "") or ""
        if not d:
            self.log_message("[-] Chưa chọn thư mục đầu ra.")
            return
        try:
            os.makedirs(d, exist_ok=True)
            QDesktopServices.openUrl(QUrl.fromLocalFile(d))
        except Exception as e:
            self.log_message(f"[-] Không mở được thư mục: {e}")

    @pyqtSlot(str, int)
    def _on_stage_progress(self, stage, value):
        if hasattr(self.progress, "set_stage_progress"):
            self.progress.set_stage_progress(stage, int(value))
        else:
            self.progress.set_progress(int(value))

    def start_generation(self):
        if self._worker and self._worker.isRunning():
            self._worker.cancel()
            return
        self.btn_generate.setEnabled(False); self.log_view.clear()
        self._hide_preview()
        if hasattr(self.progress, "reset_stages"):
            self.progress.reset_stages()
        else:
            self.progress.set_progress(0)

        txt = ""
        subtitle_path = ""
        if self.mode == "Phụ Đề":
            if not self.drop_subtitle.file_path:
                self.log_message("[-] Chưa tải file phụ đề.")
                self.btn_generate.setEnabled(True)
                return
            if not is_srt_nonempty(self.drop_subtitle.file_path):
                self.log_message("[-] File phụ đề rỗng / sai định dạng.")
                self.btn_generate.setEnabled(True)
                return
            subtitle_path = self.drop_subtitle.file_path
        else:
            txt = self.input_text.toPlainText().strip()
            if not txt:
                self.log_message("[-] Chưa nhập văn bản.")
                self.btn_generate.setEnabled(True)
                return
            txt = normalize_text(txt)
            self.input_text.setPlainText(txt)

        try:
            import Speech
        except Exception as e:
            self.log_message(f"[-] L���i Speech Engine: {e}")
            self.btn_generate.setEnabled(True)
            return

        out_dir = self.output_dir or ""
        if not out_dir:
            self.log_message("[-] Hãy chọn thư mục đầu ra trước.")
            self.btn_generate.setEnabled(True)
            return
        if self.mode == "Phụ Đề":
            base_name = Path(self.drop_subtitle.file_path).stem
            output_name = f"TTS_{base_name}.wav"
        else:
            output_name = f"TTS_Text_{time.strftime('%Y%m%d_%H%M%S')}.wav"

        session_ids = []

        if self._worker and self._worker.isRunning(): self._worker.quit(); self._worker.wait(2000)
        self._worker = SynthesisWorker(
            mode=self.mode or "Văn Bản",
            text=txt,
            subtitle_path=subtitle_path,
            output_dir=out_dir,
            output_name=output_name,
            voice=self.combo_voice.currentText(),
            speed=self.slider_speed.value() / 100.0,
            pitch=self.switch_pitch.isChecked(),
            session_ids=session_ids,
            provider=self.combo_provider.currentText(),
        )
        self._worker.message.connect(self.log_message)
        self._worker.stage_progress.connect(self._on_stage_progress)
        self._worker.completed.connect(self._on_completed); self._worker.finished.connect(self._cleanup_worker); _pause_gradient_for_work(); self._worker.start()
        self.btn_generate._text = "Hủy"
        self.btn_generate.update()

    def _cleanup_worker(self):
        _resume_gradient_after_work()
        self.btn_generate._text = "Tạo Ngay"
        self.btn_generate.setEnabled(True)
        self.btn_generate.update()
        if self._worker: self._worker.quit(); self._worker.wait(2000); self._worker = None

    @pyqtSlot(bool, str, str)
    def _on_completed(self, ok, _, error_code=""):
        self.btn_generate.setEnabled(True)
        if ok:
            try:
                self.progress.set_rainbow()
            except Exception:
                self.progress.set_progress(100)
            try:
                play_ting()
            except Exception:
                pass
            try:
                with open(_, "rb") as f:
                    self._preview_bytes = f.read()
                self.preview_bar.show()
                # NẠP MỘT LẦN qua đường thống nhất; text mode tự phát (autoplay)
                # đúng 1 lần -> hết lỗi preview phát lại 2 lần.
                self._load_preview(autoplay=(self.mode != "Phụ Đề"))
            except Exception:
                pass
        else:
            if hasattr(self.progress, "reset_stages"):
                self.progress.reset_stages()
            else:
                self.progress.set_progress(0)
            if error_code == ErrorCode.CANCELLED.value:
                self.log_message("[i] Đã hủy tác vụ.")
            else:
                self.log_message(f"[-] Tạo Speech thất bại: {error_code or _}")

    def minimize_window(self):
        play_droplet()
        self._prev_pos = self.pos()
        self._minimize_group = QParallelAnimationGroup(self)
        a1 = QPropertyAnimation(self, b"windowOpacity"); a1.setDuration(250); a1.setStartValue(1); a1.setEndValue(0); a1.setEasingCurve(QEasingCurve.Type.InCubic)
        a2 = QPropertyAnimation(self, b"pos"); a2.setDuration(250); a2.setStartValue(self.pos()); a2.setEndValue(QPoint(self.pos().x(), self.pos().y() + 50)); a2.setEasingCurve(QEasingCurve.Type.InCubic)
        self._minimize_group.addAnimation(a1); self._minimize_group.addAnimation(a2)
        self._minimize_group.finished.connect(self.showMinimized)
        self._minimize_group.start()

    def changeEvent(self, e):
        if e.type() == QEvent.Type.WindowStateChange:
            if e.oldState() & Qt.WindowState.WindowMinimized and not (self.windowState() & Qt.WindowState.WindowMinimized):
                self.setWindowOpacity(0)
                if self._prev_pos: self.move(self._prev_pos.x(), self._prev_pos.y() + 60)
                self._restore_group = QParallelAnimationGroup(self)
                a1 = QPropertyAnimation(self, b"windowOpacity"); a1.setDuration(450); a1.setStartValue(0); a1.setEndValue(1); a1.setEasingCurve(QEasingCurve.Type.OutCubic)
                a2 = QPropertyAnimation(self, b"pos"); a2.setDuration(450); a2.setStartValue(self.pos()); a2.setEndValue(self._prev_pos if self._prev_pos else self.pos()); a2.setEasingCurve(QEasingCurve.Type.OutBack)
                self._restore_group.addAnimation(a1); self._restore_group.addAnimation(a2)
                self._restore_group.start()
        super().changeEvent(e)

    def set_mode(self, mode):
        self.mode = mode
        # Đổi chế độ -> dừng & ẩn preview cũ (tránh audio chế độ trước còn phát).
        self._hide_preview()
        if self.mode == "Phụ Đề":
            self.input_text.hide()
            self.drop_subtitle.show()
            self.lbl_title.setText("Cấu Hình SRT To Speech")
            self.btn_generate._text = "Thuyết Minh"
        else:
            self.input_text.show()
            self.drop_subtitle.hide()
            self.lbl_title.setText("Cấu hình Text To Speech")
            self.btn_generate._text = "Tạo Ngay"
        self.btn_generate.update()

    def select_mode_and_switch(self, mode):
        if self._worker and self._worker.isRunning():
            self._worker.quit()
            self._worker.wait(2000)

        play_droplet()
        self.set_mode(mode)

        self._fade_mode.setEnabled(True)
        anim_fade = QPropertyAnimation(self._fade_mode, b"opacity")
        anim_fade.setDuration(180)
        anim_fade.setStartValue(1.0)
        anim_fade.setEndValue(0.0)
        anim_fade.setEasingCurve(QEasingCurve.Type.InQuad)

        mh = QGuiApplication.primaryScreen().availableGeometry()
        curr_geom = self.geometry()
        cx, cy = curr_geom.center().x(), curr_geom.center().y()
        target_rect = QRect(cx - 820 // 2, cy - 600 // 2, 820, 600)

        if target_rect.left() < mh.left(): target_rect.moveLeft(mh.left())
        if target_rect.right() > mh.right(): target_rect.moveRight(mh.right() - 820)
        if target_rect.top() < mh.top(): target_rect.moveTop(mh.top())
        if target_rect.bottom() > mh.bottom(): target_rect.moveBottom(mh.bottom() - 600)

        anim_size = QPropertyAnimation(self, b"geometry")
        anim_size.setDuration(280)
        anim_size.setStartValue(curr_geom)
        anim_size.setEndValue(target_rect)
        anim_size.setEasingCurve(QEasingCurve.Type.OutCubic)

        self.trans_group = QParallelAnimationGroup(self)
        self.trans_group.addAnimation(anim_fade)
        self.trans_group.addAnimation(anim_size)

        def switch_to_workspace():
            self.stack.setCurrentIndex(1)
            self.title_bar.set_back_visible(True)

            self._fade_workspace.setEnabled(True)
            self.anim_fade_in = QPropertyAnimation(self._fade_workspace, b"opacity")
            self.anim_fade_in.setDuration(200)
            self.anim_fade_in.setStartValue(0.0)
            self.anim_fade_in.setEndValue(1.0)
            self.anim_fade_in.setEasingCurve(QEasingCurve.Type.OutQuad)

            self.anim_fade_in.finished.connect(lambda: self._fade_workspace.setEnabled(False))
            self.anim_fade_in.start()

        self.trans_group.finished.connect(switch_to_workspace)
        self.trans_group.start()

    def go_back(self):
        if self._worker and self._worker.isRunning():
            self._worker.quit()
            self._worker.wait(2000)

        play_droplet()
        if self.initial_mode is not None:
            self._back_group = QParallelAnimationGroup(self)
            a1 = QPropertyAnimation(self, b"windowOpacity"); a1.setDuration(220); a1.setStartValue(1.0); a1.setEndValue(0.0); a1.setEasingCurve(QEasingCurve.Type.InCubic)
            a2 = QPropertyAnimation(self, b"pos"); a2.setDuration(220); a2.setStartValue(self.pos()); a2.setEndValue(QPoint(self.pos().x(), self.pos().y() + 60)); a2.setEasingCurve(QEasingCurve.Type.InCubic)
            self._back_group.addAnimation(a1); self._back_group.addAnimation(a2)
            def transitions():
                self.hide()
                self.back_clicked.emit()
            self._back_group.finished.connect(transitions)
            self._back_group.start()
        else:
            self._fade_workspace.setEnabled(True)
            anim_fade = QPropertyAnimation(self._fade_workspace, b"opacity")
            anim_fade.setDuration(180)
            anim_fade.setStartValue(1.0)
            anim_fade.setEndValue(0.0)
            anim_fade.setEasingCurve(QEasingCurve.Type.InQuad)

            mh = QGuiApplication.primaryScreen().availableGeometry()
            curr_geom = self.geometry()
            cx, cy = curr_geom.center().x(), curr_geom.center().y()
            target_rect = QRect(cx - 680 // 2, cy - 480 // 2, 680, 480)

            anim_size = QPropertyAnimation(self, b"geometry")
            anim_size.setDuration(280)
            anim_size.setStartValue(curr_geom)
            anim_size.setEndValue(target_rect)
            anim_size.setEasingCurve(QEasingCurve.Type.OutCubic)

            self.trans_group = QParallelAnimationGroup(self)
            self.trans_group.addAnimation(anim_fade)
            self.trans_group.addAnimation(anim_size)

            def back_to_selection():
                self.stack.setCurrentIndex(0)
                self.title_bar.set_back_visible(False)
                self.mode = None

                self._fade_mode.setEnabled(True)
                self.anim_fade_in = QPropertyAnimation(self._fade_mode, b"opacity")
                self.anim_fade_in.setDuration(200)
                self.anim_fade_in.setStartValue(0.0)
                self.anim_fade_in.setEndValue(1.0)
                self.anim_fade_in.setEasingCurve(QEasingCurve.Type.OutQuad)

                self.anim_fade_in.finished.connect(lambda: self._fade_mode.setEnabled(False))
                self.anim_fade_in.start()

            self.trans_group.finished.connect(back_to_selection)
            self.trans_group.start()

    def close_window(self):
        if self._worker and self._worker.isRunning(): self._worker.quit(); self._worker.wait(2000)
        play_droplet()
        # Fade windowOpacity muot (GPU) roi thoat -> khong keo pos moi frame.
        a1 = QPropertyAnimation(self, b"windowOpacity"); a1.setDuration(180); a1.setStartValue(1.0); a1.setEndValue(0.0); a1.setEasingCurve(QEasingCurve.Type.InCubic)
        a1.finished.connect(QApplication.quit)
        self._close_anim = a1; a1.start()


def read_changelog():
    import json as _json
    try:
        _root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        with open(os.path.join(_root, "changelog.json"), "r", encoding="utf-8") as f:
            return _json.load(f)
    except Exception:
        return {}


class AboutPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.hide()
        self._opacity = 0.0
        self.card = SettingsCard(self)
        self.card.setFixedSize(540, 540)
        self._anim = QPropertyAnimation(self, b"val_prop")
        self._anim.setDuration(340)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.finished.connect(self._on_hide_finished)

        outer = QVBoxLayout(self.card)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea(self.card)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        scroll.viewport().setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        _styled(scroll, "QScrollArea{background:transparent;border:none;}QScrollBar{width:0px;height:0px;background:transparent;border:none;}QScrollBar::handle{background:transparent;}QScrollBar::add-line,QScrollBar::sub-line{width:0px;height:0px;}QScrollBar::add-page,QScrollBar::sub-page{background:transparent;}")
        inner = QWidget()
        inner.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        outer.addWidget(scroll)
        scroll.setWidget(inner)
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(30, 24, 26, 26)
        lay.setSpacing(10)

        data = read_changelog()
        ver = data.get("version", "2.0.6")
        ch = data.get("channel", "Pro Beta")
        dev = data.get("developer", "HàoXD")
        rel = data.get("released", "")

        head = QHBoxLayout()
        ic = QLabel()
        ic.setPixmap(_icon(_SVG_INFO, 26).pixmap(26, 26))
        title = QLabel("THÔNG TIN ỨNG DỤNG")
        _styled(title, "color: __ACCT__; font-size:18px; letter-spacing:1.6px; font-weight:900;")
        self.btn_close = IconButton(_SVG_CLOSE, kind="close", parent=self.card)
        self.btn_close.clicked.connect(self.hide_panel)
        head.addWidget(ic)
        head.addSpacing(8)
        head.addWidget(title)
        head.addStretch()
        head.addWidget(self.btn_close)
        lay.addLayout(head)

        big = QLabel(f"TTS_Pro_V{ver}")
        big.setStyleSheet("color:#FFFFFF; font-size:30px; font-weight:900; letter-spacing:1.5px;")
        lay.addWidget(big)

        sub = QLabel(f"Kênh {ch}  •  Phát hành {rel}")
        sub.setStyleSheet("color:rgba(255,255,255,170); font-size:13px; font-weight:700;")
        lay.addWidget(sub)

        devl = QLabel(f"Nhà Phát Triển:  {dev}")
        _styled(devl, "color: __ACCT__; font-size:15px; font-weight:900; letter-spacing:0.6px;")
        lay.addWidget(devl)

        div = QFrame()
        div.setFrameShape(QFrame.Shape.HLine)
        div.setFixedHeight(1)
        _styled(div, "background-color: __ACCSOFT__; border:none;")
        lay.addWidget(div)

        _entries = data.get("changelog", [])
        if _entries:
            cl_title = QLabel("NHẬT KÝ CẬP NHẬT")
            cl_title.setStyleSheet("color:#FFFFFF; font-size:14px; font-weight:900; letter-spacing:1.0px;")
            lay.addWidget(cl_title)

        for entry in _entries:
            v = entry.get("version", "")
            d = entry.get("date", "")
            vh = QLabel(f"v{v}    {d}")
            _styled(vh, "color: __ACCT__; font-size:14px; font-weight:900;")
            lay.addWidget(vh)
            for c in entry.get("changes", []):
                cl = QLabel(f"•  {c}")
                cl.setWordWrap(True)
                cl.setStyleSheet("color:rgba(255,255,255,210); font-size:13px; font-weight:600; padding-left:6px;")
                lay.addWidget(cl)
            lay.addSpacing(6)
        lay.addStretch()

    @pyqtProperty(float)
    def val_prop(self):
        return self._opacity

    @val_prop.setter
    def val_prop(self, v):
        self._opacity = max(0.0, min(1.0, v))
        self.card._opacity = self._opacity
        self.card.update()
        cx = (self.width() - self.card.width()) // 2
        cy = (self.height() - self.card.height()) // 2
        offset = int(50 * (1.0 - self._opacity))
        self.card.move(cx, cy + offset)
        self.update()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        cx = (self.width() - self.card.width()) // 2
        cy = (self.height() - self.card.height()) // 2
        offset = int(50 * (1.0 - self._opacity))
        self.card.move(cx, cy + offset)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        sp = QPainterPath()
        sp.addRoundedRect(QRectF(self.rect()).adjusted(0.8, 0.8, -0.8, -0.8), 26.0, 26.0)
        p.setClipPath(sp)
        p.fillRect(self.rect(), QColor(6, 9, 16, int(150 * self._opacity)))
        p.end()

    def show_panel(self):
        self.show()
        self.raise_()
        self._anim.stop()
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.setStartValue(self._opacity)
        self._anim.setEndValue(1.0)
        self._anim.start()

    def hide_panel(self):
        play_droplet()
        self._anim.stop()
        self._anim.setEasingCurve(QEasingCurve.Type.InQuad)
        self._anim.setStartValue(self._opacity)
        self._anim.setEndValue(0.0)
        self._anim.start()

    def _on_hide_finished(self):
        if self._opacity <= 0.01:
            self.hide()
