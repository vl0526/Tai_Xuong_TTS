
import os
import re
import math
import struct
import json
import sys
from PyQt6.QtCore import Qt, QRectF, QUrl
from PyQt6.QtGui import QColor, QFontDatabase, QPainter, QPixmap

from App.theme import THEME, accent_hex

_SVG_CLOSE = (
    '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="#FFFFFF" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">'
    '<line x1="6.5" y1="6.5" x2="17.5" y2="17.5"/>'
    '<line x1="17.5" y1="6.5" x2="6.5" y2="17.5"/>'
    '</svg>'
)

_SVG_MINIMIZE  = (
    '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="#FFFFFF" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">'
    '<line x1="6.5" y1="12" x2="17.5" y2="12"/>'
    '</svg>'
)

# Play (Nghe thu): tam giac bo goc tron, vector net o moi kich thuoc.
_SVG_PLAY_FILLED = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#FFFFFF" stroke="#FFFFFF" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round">'
    '<path d="M7 4.6c0-1.05 1.16-1.68 2.04-1.1l10.5 6.95a1.32 1.32 0 0 1 0 2.2L9.04 19.6C8.16 20.18 7 19.55 7 18.5z"/>'
    '</svg>'
)
# Bolt (Tao ngay): tia set lien khoi, bo goc tron - sang & cao cap.
_SVG_BOLT  = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#FFFFFF" stroke="#FFFFFF" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round">'
    '<path d="M13.55 2.3 4.8 13.05c-.5.62-.06 1.55.74 1.55H10l-1.05 6.9c-.16 1.02 1.16 1.58 1.78.76l8.45-11.04c.48-.62.04-1.52-.74-1.52H13.9l1.16-6.83c.17-1.01-1.15-1.56-1.51-.77z"/>'
    '</svg>'
)

# Save (Luu cau hinh): dia mem bo goc, chot luu + nhan giay - vector net.
_SVG_SAVE = (
    '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
    '<path d="M5 3h10.2a2 2 0 0 1 1.42.6l2.78 2.8a2 2 0 0 1 .6 1.42V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/>'
    '<path d="M7.6 3v3.8a1 1 0 0 0 1 1h4.6a1 1 0 0 0 1-1V3.4"/>'
    '<rect x="7" y="12.4" width="10" height="6.6" rx="1.3"/>'
    '</svg>'
)

# Folder (Chon dau ra): thu muc dong, tab cong - vector net moi kich thuoc.
_SVG_FOLDER = (
    '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
    '<path d="M3 6.6A2.6 2.6 0 0 1 5.6 4h2.92a2 2 0 0 1 1.5.68l1.18 1.34a2 2 0 0 0 1.5.68h5.7A2.6 2.6 0 0 1 21 9.3V16.4A2.6 2.6 0 0 1 18.4 19H5.6A2.6 2.6 0 0 1 3 16.4z"/>'
    '</svg>'
)

# Folder Open (Mo thu muc): thu muc mo nap, vector net & can xung.
_SVG_FOLDER_OPEN = (
    '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
    '<path d="M3 9.5V6.6A2.6 2.6 0 0 1 5.6 4h2.9a2 2 0 0 1 1.5.68l1.18 1.34a2 2 0 0 0 1.5.68h5A2.4 2.4 0 0 1 20.1 9.1V10.5"/>'
    '<path d="M3.3 19.3 5.36 12.9A2 2 0 0 1 7.27 11.5H20.2a1.2 1.2 0 0 1 1.14 1.58l-1.86 5.6A2 2 0 0 1 17.58 20H4.25a1 1 0 0 1-.95-1.32z"/>'
    '</svg>'
)

_SVG_SETTINGS = (
    '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">'
    '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.1a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/>'
    '<circle cx="12" cy="12" r="3"/>'
    '</svg>'
)

_SVG_BACK = (
    '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="#FFFFFF" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">'
    '<line x1="19" y1="12" x2="5" y2="12"/>'
    '<polyline points="12 19 5 12 12 5"/>'
    '</svg>'
)

_SVG_SUBTITLE = (
    '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="#FFFFFF" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">'
    '<rect x="3" y="4" width="18" height="16" rx="2" ry="2"/>'
    '<path d="M7 15h10"/>'
    '<path d="M7 11h6"/>'
    '</svg>'
)

_SVG_INFO = (
    '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">'
    '<circle cx="12" cy="12" r="9"/>'
    '<line x1="12" y1="11" x2="12" y2="16"/>'
    '<circle cx="12" cy="7.6" r="0.9" fill="#FFFFFF" stroke="none"/>'
    '</svg>'
)

_SVG_SPEECH = (
    '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="#FFFFFF" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">'
    '<path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/>'
    '<path d="M19 10v1a7 7 0 0 1-14 0v-1"/>'
    '<line x1="12" y1="19" x2="12" y2="22"/>'
    '<line x1="8" y1="22" x2="16" y2="22"/>'
    '</svg>'
)

_CSS_TEMPLATE = '''
* { outline: none; }
QWidget { border: none; background: transparent; font-family:"Rosemary","Segoe UI",sans-serif; color:#FFFFFF; font-size:15px; font-weight:bold; }
QLabel { color:#FFFFFF; font-size:15px; font-weight:bold; font-family:"Rosemary","Segoe UI",sans-serif; background:transparent; border: none; }
QToolTip { color:#FFFFFF; background:transparent; background-color:transparent; border:none; font-weight:900; font-family:"Rosemary","Segoe UI",sans-serif; font-size:13px; letter-spacing:0.4px; padding:2px 4px; margin:0px; }
QScrollBar:vertical { background:transparent; width:8px; margin:0px; border:none; }
QScrollBar::handle:vertical { background:__ACCENT__; border-radius:4px; min-height:30px; }
QScrollBar::handle:vertical:hover { background:__ACCENT_HOVER__; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0px; width:0px; border:none; background:none; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background:none; border:none; }
QScrollBar:horizontal { height:0px; width:0px; background:none; border:none; }
QAbstractScrollArea::corner { background: transparent; border: none; }

QComboBoxPrivateContainer {
    background-color: transparent !important;
    background: transparent !important;
    border: none !important;
    margin: 0px; padding: 0px;
}
'''

def build_css():
    a = accent_hex()
    ac = THEME.accent()
    a_hover = QColor(min(255, ac.red() + 64), min(255, ac.green() + 64),
                     min(255, ac.blue() + 64)).name().upper()
    return _CSS_TEMPLATE.replace("__ACCENT_HOVER__", a_hover).replace("__ACCENT__", a)

def apply_app_css():
    try:
        from PyQt6.QtWidgets import QApplication
        app = QApplication.instance()
        if app is not None:
            app.setStyleSheet(build_css())
    except Exception:
        pass

def _load_font():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    candidates = []
    for base in (root, os.path.join(root, "Assets"), os.path.join(root, "App"), os.path.join(root, "fonts")):
        for name in ("Rosemary.ttf", "Rosemary.otf", "rosemary.ttf", "rosemary.otf"):
            candidates.append(os.path.join(base, name))
    for p in candidates:
        if os.path.exists(p):
            return p
    return None


def _register_font(dp):
    if dp and os.path.exists(dp):
        try:
            fid = QFontDatabase.addApplicationFont(dp)
            fams = QFontDatabase.applicationFontFamilies(fid)
            if fams:
                return fams[0]
        except Exception:
            pass
    try:
        fams = set(QFontDatabase.families())
        if "Rosemary" in fams:
            return "Rosemary"
    except Exception:
        pass
    return "Segoe UI"

_APP_ICON_CACHE = None

def app_icon():
    """QIcon logo ung dung tu Icon_App.png (uu tien .ico da kich thuoc cho taskbar).

    Tu dong do nhieu vi tri tai nguyen -> chuan taskbar/titlebar/shortcut, nen trong suot.
    """
    global _APP_ICON_CACHE
    if _APP_ICON_CACHE is not None:
        return _APP_ICON_CACHE
    from PyQt6.QtGui import QIcon
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    candidates = []
    for base in (os.path.join(root, "Assets"), root, os.path.join(root, "App")):
        for name in ("app.ico", "Icon_App.png", "logo_256.png"):
            candidates.append(os.path.join(base, name))
    icon = QIcon()
    for p in candidates:
        if os.path.exists(p):
            icon = QIcon(p)
            break
    _APP_ICON_CACHE = icon
    return icon


class _VectorIcon:
    """Vẽ SVG dạng vector trực tiếp -> sắc nét mọi kích thước, không vỡ pixel."""
    __slots__ = ("_svg", "_r", "_pix_cache")
    def __init__(self, svg):
        self._svg = svg
        self._r = None
        self._pix_cache = {}
    def _rend(self):
        if self._r is None:
            from PyQt6.QtSvg import QSvgRenderer
            self._r = QSvgRenderer(self._svg.encode())
            try:
                self._r.setAspectRatioMode(Qt.AspectRatioMode.KeepAspectRatio)
            except Exception:
                pass
        return self._r
    def paint(self, painter, rect, *a, **k):
        rf = rect if isinstance(rect, QRectF) else QRectF(rect)
        painter.save()
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        try:
            painter.setRenderHint(QPainter.RenderHint.LosslessImageRendering, True)
        except Exception:
            pass
        self._rend().render(painter, rf)
        painter.restore()
    def pixmap(self, w, h=None):
        from PyQt6.QtCore import QSize
        from PyQt6.QtGui import QGuiApplication
        if isinstance(w, QSize):
            ww, hh = w.width(), w.height()
        else:
            ww, hh = int(w), int(h if h is not None else w)
        try:
            dpr = QGuiApplication.primaryScreen().devicePixelRatio() or 1.0
        except Exception:
            dpr = 1.0
        key = (ww, hh, round(float(dpr), 2))
        hit = self._pix_cache.get(key)
        if hit is not None:
            return hit
        ss = max(2.0, float(dpr) * 2.0)
        pw, ph = int(round(ww * ss)), int(round(hh * ss))
        pm = QPixmap(pw, ph)
        pm.fill(Qt.GlobalColor.transparent)
        pp = QPainter(pm)
        pp.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        pp.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        try:
            pp.setRenderHint(QPainter.RenderHint.LosslessImageRendering, True)
        except Exception:
            pass
        self._rend().render(pp, QRectF(0, 0, pw, ph))
        pp.end()
        pm.setDevicePixelRatio(ss)
        if len(self._pix_cache) > 128:
            self._pix_cache.clear()
        self._pix_cache[key] = pm
        return pm

def _icon(svg, sz=32):
    hit = _ICON_CACHE.get(id(svg))
    if hit is not None:
        return hit
    ic = _VectorIcon(svg)
    _ICON_CACHE[id(svg)] = ic
    return ic

_ICON_CACHE = {}

_GLASS_CACHE = {}
_BG_OPACITY = 1.0

def clear_glass_cache():
    _GLASS_CACHE.clear()

try:
    THEME.themeChanged.connect(clear_glass_cache)
    THEME.themeChanged.connect(apply_app_css)
except Exception:
    pass

def set_bg_opacity(value):
    global _BG_OPACITY
    _BG_OPACITY = max(0.0, min(1.0, value / 100.0))
    clear_glass_cache()
    try:
        from PyQt6.QtWidgets import QApplication
        app = QApplication.instance()
        if app:
            for w in app.topLevelWidgets():
                if w.isVisible() and w.winId() is not None:
                    _apply_acrylic(int(w.winId()), _BG_OPACITY)
    except Exception:
        pass

def get_bg_opacity():
    return int(round(_BG_OPACITY * 100))

def _apply_acrylic(hwnd: int, intensity: float):
    """Da TAT acrylic blur-behind co chu dich.

    Ly do: SetWindowCompositionAttribute(ACCENT_ENABLE_ACRYLICBLURBEHIND) luon
    to lop blur theo HINH CHU NHAT cua winId. Voi cua so frameless bo tron 26px,
    4 goc vuong cua acrylic 'tho' ra sau lop kinh -> loi vien goc vuong tren
    Windows 10. Cat bang SetWindowRgn thi vien lai bi VO PIXEL (region 1-bit,
    khong khu rang cua). Khong co cach lay acrylic goc tron muot tren Win10 voi
    API nay, nen ta BO han acrylic: cua so van trong suot nho WA_TranslucentBackground
    va lop kinh ve bang QPainter (Antialiasing) -> goc bo tron MUOT 100%, khong
    con vien vuong cung khong con vo pixel.
    """
    return False


def _apply_acrylic_legacy(hwnd: int, intensity: float):
    if not sys.platform.startswith("win"):
        return False
    try:
        import ctypes

        class ACCENTPOLICY(ctypes.Structure):
            _fields_ = [
                ("nAccentState", ctypes.c_int),
                ("nFlags", ctypes.c_uint),
                ("nColor", ctypes.c_uint),
                ("nAnimationId", ctypes.c_uint),
            ]

        class WINCOMPATTRDATA(ctypes.Structure):
            _fields_ = [
                ("nAttribute", ctypes.c_int),
                ("pData", ctypes.c_void_p),
                ("ulDataSize", ctypes.c_size_t),
            ]

        accent = THEME.accent()
        alpha = max(0, min(255, int(float(intensity) * 180)))
        gradient_color = (alpha << 24) | (accent.blue() << 16) | (accent.green() << 8) | accent.red()
        policy = ACCENTPOLICY(4, 2, gradient_color, 0)  # ACCENT_ENABLE_ACRYLICBLURBEHIND
        data = WINCOMPATTRDATA(19, ctypes.addressof(policy), ctypes.sizeof(policy))
        fn = ctypes.windll.user32.SetWindowCompositionAttribute
        return bool(fn(int(hwnd), ctypes.byref(data)))
    except Exception:
        return False


def clear_window_region(hwnd: int) -> bool:
    """Go bo moi window-region cung (neu co) -> cua so tro lai trong suot hoan
    toan, de lop kinh ve khu rang cua hien thi goc bo tron MUOT, khong vo pixel.
    """
    if not sys.platform.startswith("win"):
        return False
    try:
        import ctypes
        ctypes.windll.user32.SetWindowRgn(int(hwnd), 0, True)
        return True
    except Exception:
        return False


def is_srt_nonempty(file_path: str) -> bool:
    try:
        from Speech.srt_parser import is_srt_nonempty as _check
        return bool(_check(file_path))
    except Exception:
        try:
            if not os.path.exists(file_path):
                return False
            with open(file_path, "rb") as f:
                return b"-->" in f.read(8192)
        except Exception:
            return False


def read_subtitle_lines(file_path):
    try:
        from Speech.srt_parser import parse_srt
        return [str(c.get("text", "")) for c in parse_srt(file_path) if c.get("text")]
    except Exception:
        return []

_SOUND_CACHE_DIR = os.path.join(os.path.expanduser("~"), ".tts_pro_code_assets")
_SOUND_CLICK_PATH = os.path.join(_SOUND_CACHE_DIR, "click_premium_v3.wav")
_CONFIG_PATH     = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.json")

# App CHI dung 1 am thanh cao cap duy nhat cho moi tuong tac.
_sound_click = None
_sounds_initialized = False

def _generate_click_wav(path, duration=0.11):
    """Sinh 1 am thanh 'click' cao cap DUY NHAT: mem, de chiu, muot ma.

    - Attack ~4ms de khong bi cheng tai (khong transient gat).
    - Blend 3 hai am am ap (330/660/990Hz) + tat dan exponential nhanh, gon.
    """
    sr = 44100
    try:
        import numpy as np
        n = int(sr * duration)
        t = np.arange(n, dtype=np.float32) / sr
        atk = np.clip(t / 0.004, 0.0, 1.0)
        env = atk * np.exp(-30.0 * t)
        body = (0.60 * np.sin(2 * np.pi * 660.0 * t)
                + 0.30 * np.sin(2 * np.pi * 990.0 * t) * np.exp(-16.0 * t)
                + 0.24 * np.sin(2 * np.pi * 330.0 * t))
        y = np.clip(body * env * 11500, -32767, 32767).astype("<i2").tobytes()
        header = struct.pack("<4sI4s4sIHHIIHH4sI", b"RIFF", 36 + len(y), b"WAVE", b"fmt ", 16, 1, 1, sr, sr * 2, 2, 16, b"data", len(y))
        with open(path, "wb") as f:
            f.write(header + y)
        return
    except Exception:
        pass
    n = int(sr * duration)
    data = bytearray()
    for i in range(n):
        t = i / sr
        atk = min(1.0, t / 0.004)
        env = atk * math.exp(-30.0 * t)
        s = (0.60 * math.sin(2 * math.pi * 660.0 * t)
             + 0.30 * math.sin(2 * math.pi * 990.0 * t) * math.exp(-16.0 * t)
             + 0.24 * math.sin(2 * math.pi * 330.0 * t))
        val = max(-32767, min(32767, int(s * env * 11500)))
        data.extend(struct.pack("<h", val))
    header = struct.pack("<4sI4s4sIHHIIHH4sI", b"RIFF", 36 + len(data), b"WAVE", b"fmt ", 16, 1, 1, sr, sr * 2, 2, 16, b"data", len(data))
    with open(path, "wb") as f:
        f.write(header + data)


def prepare_startup_assets():
    """Chuẩn bị file tài nguyên nhẹ trước, tránh giật khi click đầu tiên."""
    try:
        os.makedirs(_SOUND_CACHE_DIR, exist_ok=True)
        if not os.path.exists(_SOUND_CLICK_PATH):
            _generate_click_wav(_SOUND_CLICK_PATH)
    except Exception:
        pass


def _is_muted():
    try:
        if not os.path.exists(_CONFIG_PATH):
            return False
        with open(_CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        return bool(cfg.get("mute_sound", False))
    except Exception:
        return False

def init_sound_effects():
    global _sound_click, _sounds_initialized
    if _sounds_initialized:
        return
    _sounds_initialized = True
    try:
        prepare_startup_assets()
        from PyQt6.QtMultimedia import QSoundEffect
        _sound_click = QSoundEffect()
        _sound_click.setSource(QUrl.fromLocalFile(_SOUND_CLICK_PATH))
        _sound_click.setVolume(0.55)
    except Exception:
        _sound_click = None


def _play_click():
    """Phat 1 am thanh cao cap duy nhat cua app. Ton trong co tat tieng."""
    try:
        if _is_muted():
            return
        if not _sounds_initialized:
            init_sound_effects()
        if _sound_click is not None:
            _sound_click.play()
    except Exception:
        pass


def play_ting():
    _play_click()


def play_droplet(is_on=True):
    _play_click()
