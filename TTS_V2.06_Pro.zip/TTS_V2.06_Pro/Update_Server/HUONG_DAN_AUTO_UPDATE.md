# Hướng Dẫn Auto-Update TTS_Pro (Bản Đóng Gói, Không Lộ Mã Nguồn)

Mục tiêu: người dùng **không cần cài Python**, bạn **không phải chia sẻ mã nguồn**,
cập nhật **nhanh + bảo mật**, và có **nút "Cập Nhật" 3D** ngay trong phần Cài Đặt.

---

## 1. Cơ chế tổng quan

```
[App .exe của người dùng]  --HTTPS-->  [latest.json trên máy chủ]
        |  so sánh version
        v
  Có bản mới? --> Tải gói .exe/.msi --> Kiểm SHA-256 (+ chữ ký Ed25519) --> Cài & khởi động lại
```

- Bạn chỉ phát hành **file .exe đã build** (không có .py) → mã nguồn không bị lộ.
- Gói cập nhật cũng là **.exe/.msi đã build**, tải qua **HTTPS**.
- App bắt buộc kiểm **SHA-256**; tùy chọn kiểm **chữ ký số Ed25519** để chống giả mạo.

---

## 2. Đóng gói app thành .exe (PyInstaller)

```bat
pip install pyinstaller
pyinstaller --noconfirm --windowed --name TTS_Pro ^
  --icon Assets/app.ico ^
  --add-data "Assets;Assets" ^
  --add-data "changelog.json;." ^
  --add-data "Speech/native;Speech/native" ^
  App.py
```

- `--windowed`: không hiện cửa sổ console.
- Kết quả nằm trong `dist/TTS_Pro/` (bản onedir) hoặc dùng `--onefile` cho 1 file duy nhất.
- Muốn có **trình cài đặt** đẹp: dùng **Inno Setup** hoặc **NSIS** để đóng `dist/` thành
  `TTS_Pro_Setup_x.y.z.exe` (khuyên dùng — hỗ trợ tự thay bản cũ).

> Bảo mật thêm: ký số file .exe bằng chứng chỉ Authenticode (signtool) để Windows
> SmartScreen tin tưởng, tránh cảnh báo "Unknown Publisher".

---

## 3. Tạo khóa & ký gói (chạy trên máy của BẠN)

```bat
pip install cryptography
cd Update_Server
python sign_release.py keygen        &:: tạo 1 lần
```

- Sinh ra `private_key.pem` (**GIỮ BÍ MẬT**) và `public_key_b64.txt`.
- Mở `App/updater.py`, dán chuỗi trong `public_key_b64.txt` vào `PUBLIC_KEY_B64`.
  (Để trống nếu chưa muốn dùng chữ ký — app vẫn kiểm SHA-256.)

Mỗi lần phát hành bản mới:

```bat
python sign_release.py sign ^
  --file ..\dist\TTS_Pro_Setup_2.0.7.exe ^
  --version 2.0.7 ^
  --url https://github.com/HaoXD/TTS_Pro/releases/download/v2.0.7/TTS_Pro_Setup_2.0.7.exe ^
  --notes "Cải tiến tốc độ, sửa lỗi nhỏ" ^
  --kind installer
```

- Lệnh này tính SHA-256, ký, và ghi ra `latest.json` hoàn chỉnh.

---

## 4. Đưa lên máy chủ (chọn 1)

**Cách miễn phí, nhanh (khuyên dùng): GitHub Releases**
1. Tạo release `v2.0.7`, tải kèm `TTS_Pro_Setup_2.0.7.exe`.
2. Commit `latest.json` vào nhánh `main` của repo.
3. URL manifest công khai:
   `https://raw.githubusercontent.com/<user>/<repo>/main/latest.json`

**Hoặc:** Cloudflare R2 / AWS S3 / VPS có HTTPS — upload `.exe` + `latest.json`.

Sau đó cập nhật `DEFAULT_MANIFEST_URL` trong `App/updater.py`, hoặc đặt
`"update_url": "https://..."` trong `config.json` (ghi đè mà không cần build lại).

---

## 5. Người dùng cập nhật thế nào

1. Mở **Cài Đặt** → mục **Cập Nhật Ứng Dụng** → bấm nút 3D **"Kiểm Tra Cập Nhật"**.
2. Nút xoay khi kiểm tra. Có bản mới → hiện **"Tải Bản Mới vX.Y.Z"** (phát sáng).
3. Bấm để tải — thanh tiến độ **%** chạy ngay trong nút.
4. Tải xong + xác thực bảo mật → nút chuyển **"Cài Đặt & Khởi Động Lại"**.
5. Bấm — app chạy trình cài đặt và tự khởi động lại bản mới.

---

## 6. Định dạng manifest `latest.json`

| Trường      | Ý nghĩa                                             |
|-------------|-----------------------------------------------------|
| `version`   | Phiên bản mới (vd `2.0.7`)                           |
| `kind`      | `installer` (trình cài) hoặc `exe` (onefile hoán đổi)|
| `url`       | Link tải HTTPS                                       |
| `sha256`    | Mã băm SHA-256 (bắt buộc)                            |
| `signature` | Chữ ký Ed25519 base64 (tùy chọn, khuyên dùng)        |
| `notes`     | Ghi chú hiển thị cho người dùng                      |
| `mandatory` | Đánh dấu bản bắt buộc (dành cho mở rộng sau)         |

---

## 7. Vì sao an toàn & không lộ mã nguồn

- Chỉ phân phối **.exe đã compile** — không kèm `.py`.
- Tải qua **HTTPS** (chống nghe lén / sửa gói giữa đường).
- **SHA-256** đảm bảo file tải đúng, không hỏng.
- **Ed25519** đảm bảo gói do **chính bạn** phát hành (dù máy chủ bị chiếm quyền,
  kẻ tấn công không có khóa riêng để ký gói giả).
- Tải & kiểm tra chạy ở **luồng nền** → giao diện luôn mượt.
