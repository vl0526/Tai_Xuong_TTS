# -*- coding: utf-8 -*-
# =============================================================================
#  App.py  —  Diem khoi dong (entry point) cho  TTS_Pro_V2.0.6
# -----------------------------------------------------------------------------
#  Muc tieu thiet ke:
#    * Khoi dong CUC NHANH: chi lam dung viec toi thieu truoc khi cua so dau
#      tien hien ra; moi viec khong khan cap (am thanh...) duoc hoan lai sau
#      khung hinh dau tien (deferred init) -> nguoi dung thay UI gan nhu tuc thi.
#    * CHAC CHAN 100%, KHONG bao gio that bai am tham: moi loi khong bat duoc
#      deu duoc ghi log + in ra, thay vi lam app tu thoat khong dau vet.
#    * Dieu huong cua so vung chac: controller giu tham chieu manh den tung cua
#      so -> tranh bi trinh thu gom rac (GC) thu don nham, gay "mo roi tat ngay".
#
#  Kien truc:
#      main()
#        -> chuan bi moi truong (UTF-8, sys.path, excepthook)
#        -> tao QApplication (sau khi da dat chinh sach High-DPI)
#        -> nap & dang ky font, ap CSS theo accent
#        -> AppController dieu huong:  Chon che do  ->  Cua so chinh
#        -> hoan lai khoi tao am thanh sau khung hinh dau
# =============================================================================
from __future__ import annotations

import os
import sys

# --- Hang so dinh danh ung dung ------------------------------------------------
APP_NAME = "TTS_Pro"
APP_VERSION = "2.0.6"
APP_DISPLAY = "TTS_Pro_V2.0.6 Pro"
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_DIR = os.path.join(ROOT_DIR, "logs")


# =============================================================================
#  GIAI DOAN 1 — Chuan bi moi truong chay (truoc khi dung Qt)
# =============================================================================
def _harden_runtime_env() -> None:
    """Ep UTF-8 cho tien trinh + stdio -> log/console khong vo font tieng Viet."""
    os.environ.setdefault("PYTHONUTF8", "1")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        except Exception:
            pass


def _setup_import_paths() -> None:
    """Dam bao import duoc g6i 'App' du chay tu bat ky thu muc lam viec nao."""
    for path in (ROOT_DIR, os.path.join(ROOT_DIR, "App")):
        if path not in sys.path:
            sys.path.insert(0, path)


def _install_excepthook() -> None:
    """Bat moi exception khong duoc xu ly -> ghi logs/app.log + in ra stderr.

    Day la cot loi cua tieu chi 'KHONG bao gio that bai am tham': neu co loi
    bat ngo, ta luon co dau vet ro rang thay vi app bien mat khong ly do.
    """
    import datetime
    import traceback

    def _hook(exc_type, exc, tb):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc, tb)
            return
        detail = "".join(traceback.format_exception(exc_type, exc, tb))
        stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            os.makedirs(LOG_DIR, exist_ok=True)
            with open(os.path.join(LOG_DIR, "app.log"), "a",
                      encoding="utf-8", errors="replace") as f:
                f.write("\n===== %s | UNCAUGHT =====\n%s" % (stamp, detail))
        except Exception:
            pass
        try:
            sys.stderr.write(detail)
        except Exception:
            pass

    sys.excepthook = _hook


def _set_highdpi_policy() -> None:
    """Dat chinh sach lam tron ti le High-DPI TRUOC khi tao QApplication.

    PassThrough -> giu nguyen ti le man hinh (125%/150%...) khong lam tron,
    cho giao dien Liquid Glass sac net, can chinh dung pixel tren moi man hinh.
    """
    from PyQt6.QtCore import Qt
    from PyQt6.QtGui import QGuiApplication
    try:
        QGuiApplication.setHighDpiScaleFactorRoundingPolicy(
            Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
        )
    except Exception:
        pass


# =============================================================================
#  GIAI DOAN 2 — Dieu huong cua so (Controller)
# =============================================================================
class AppController:
    """Dieu phoi vong doi & dieu huong giua cac cua so.

    Giu tham chieu manh (self._selector, self._main) de Qt/Python KHONG thu gom
    rac cac cua so dang hien -> tranh hien tuong 'cua so mo roi dong ngay'.

    Luu y: KHONG dung __slots__ o day. PyQt6 can tao 'weak reference' toi doi
    tuong nhan tin hieu khi goi signal.connect(self._method); class co __slots__
    ma thieu '__weakref__' se chan weakref -> loi:
        TypeError: cannot create weak reference to 'AppController' object
    """

    def __init__(self, app):
        self._app = app
        self._selector = None  # ModeSelectorWindow
        self._main = None      # MainWindow
        self._fade = None      # giu tham chieu animation fade-in khi quay lai

    # --- Khoi dong: hien cua so chon che do --------------------------------
    def start(self) -> None:
        from App.widgets import ModeSelectorWindow
        self._selector = ModeSelectorWindow()
        self._selector.mode_selected.connect(self._on_mode_selected)
        self._selector.show()

    # --- Nguoi dung chon 1 che do -> mo cua so chinh -----------------------
    def _on_mode_selected(self, mode) -> None:
        from App.widgets import MainWindow
        self._main = MainWindow(mode)
        self._main.back_clicked.connect(self._on_back)
        self._main.show()

    # --- Nguoi dung bam 'Quay lai' -> hien lai cua so chon che do ----------
    def _on_back(self) -> None:
        from PyQt6.QtCore import QPropertyAnimation, QEasingCurve
        sel = self._selector
        if sel is None:
            # Phong truong hop selector da bi don -> dung lai mot cua so moi.
            self.start()
            return
        sel.show()
        sel.raise_()
        sel.activateWindow()
        sel.setWindowOpacity(0.0)
        anim = QPropertyAnimation(sel, b"windowOpacity")
        anim.setDuration(300)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        anim.start()
        self._fade = anim  # giu tham chieu -> animation khong bi GC giua chung


# =============================================================================
#  GIAI DOAN 3 — main()
# =============================================================================
def main() -> int:
    # 0) AUTO-SETUP: kiểm tra decoder native theo kiểu fail-fast, không tải mạng
    #    và không xin UAC trong lúc khởi động để UI hiện nhanh nhất có thể.
    _setup_import_paths()  # de import duoc goi 'App.autosetup'
    try:
        from App.autosetup import run_autosetup
        run_autosetup()
    except SystemExit:
        raise
    except Exception as _exc:  # noqa: BLE001
        print(f"[auto-setup] bo qua do loi: {_exc!r}", flush=True)

    # 1) Moi truong (truoc khi cham vao Qt).
    _harden_runtime_env()
    _setup_import_paths()
    _install_excepthook()
    _set_highdpi_policy()

    try:
        if sys.platform != "win32":
            import uvloop
            uvloop.install()
    except Exception:
        pass

    # 2) Cac import Qt + module noi bo (sau khi sys.path da san sang).
    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtGui import QFont
    from App.core import (
        _load_font, _register_font, apply_app_css, init_sound_effects, prepare_startup_assets, app_icon,
    )

    # 3) Font + tài nguyên siêu nhẹ: chuẩn bị trước để click đầu tiên phản hồi ngay.
    font_path = _load_font()
    prepare_startup_assets()

    # 4) QApplication duy nhat.
    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationDisplayName(APP_DISPLAY)
    app.setApplicationVersion(APP_VERSION)
    # Logo / icon taskbar chinh thuc tu Icon_App.png (da kich thuoc, nen trong suot).
    try:
        app.setWindowIcon(app_icon())
    except Exception:
        pass
    # Windows: gan AppUserModelID -> taskbar dung dung icon ung dung (khong gom nhom python).
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("HaoXD.TTS_Pro.2.0.6")
    except Exception:
        pass

    # 5) Dang ky & dat font ung dung; ap CSS theo mau accent hien tai.
    family = _register_font(font_path)
    app.setFont(QFont(family, 12))
    apply_app_css()

    # 6) Nạp âm thanh sau khi QApplication sẵn sàng; file đã được cache nên rất nhanh.
    init_sound_effects()

    try:
        import threading
        from Speech.turbo_tts.python import turbo_tts as _turbo_tts
        threading.Thread(target=_turbo_tts.warmup, name="tts-warmup", daemon=True).start()
    except Exception:
        pass

    # 7) Điều hướng: hiển thị cửa sổ ngay.
    controller = AppController(app)
    controller.start()

    # 8) Vòng lặp sự kiện.
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
