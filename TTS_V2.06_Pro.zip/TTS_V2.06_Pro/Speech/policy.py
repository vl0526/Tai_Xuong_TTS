"""Reliability policies: circuit breaker and adaptive concurrency helpers."""
from __future__ import annotations

import asyncio
import time


class CircuitBreaker:
    def __init__(self, fail_threshold: int = 5, window: float = 30.0, reset_timeout: float = 20.0):
        self.fail_threshold = int(fail_threshold)
        self.window = float(window)
        self.reset_timeout = float(reset_timeout)
        self._fails: list[float] = []
        self._state = "closed"
        self._opened_at = 0.0
        self._lock = asyncio.Lock()

    async def allow(self) -> bool:
        async with self._lock:
            if self._state == "open":
                if time.monotonic() - self._opened_at >= self.reset_timeout:
                    self._state = "half_open"
                    return True
                return False
            return True

    async def record_success(self) -> None:
        async with self._lock:
            self._fails.clear()
            self._state = "closed"
            self._opened_at = 0.0

    async def record_failure(self) -> None:
        async with self._lock:
            now = time.monotonic()
            cutoff = now - self.window
            self._fails = [t for t in self._fails if t >= cutoff]
            self._fails.append(now)
            if self._state == "half_open" or len(self._fails) >= self.fail_threshold:
                self._state = "open"
                self._opened_at = now


class Gradient2:
    """Small adaptive limit controller; keeps the app dependency-free."""
    def __init__(self, min_limit: int = 4, max_limit: int = 256, start: int = 64):
        self.min_limit = int(min_limit)
        self.max_limit = int(max_limit)
        self.limit = max(self.min_limit, min(int(start), self.max_limit))
        self._lat_ewma: float | None = None

    def sample(self, latency_ms: float, throttled: bool = False) -> int:
        lat = max(1.0, float(latency_ms))
        self._lat_ewma = lat if self._lat_ewma is None else self._lat_ewma * 0.8 + lat * 0.2
        if throttled or lat > self._lat_ewma * 1.8:
            self.limit = max(self.min_limit, int(self.limit * 0.7))
        elif lat <= self._lat_ewma * 1.15:
            self.limit = min(self.max_limit, self.limit + 1)
        return self.limit
