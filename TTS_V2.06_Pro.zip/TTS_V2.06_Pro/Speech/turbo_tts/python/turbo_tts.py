from __future__ import annotations

import asyncio
import base64
import collections
import functools
import os
import random
import re
import socket
import ssl
import time
import urllib.parse
from email.utils import parsedate_to_datetime

try:
    import orjson as _orjson

    def _loads(data):
        return _orjson.loads(data)
except Exception:
    import json as _json

    def _loads(data):
        if isinstance(data, (bytes, bytearray)):
            data = data.decode("utf-8")
        return _json.loads(data)

try:
    from Speech.audio_cache import (
        cache_key as _cache_key,
        get_audio as _cache_get,
        put_audio as _cache_put,
    )
except Exception:
    def _cache_key(text, voice, max_len=290):
        return ""

    def _cache_get(key):
        return None

    def _cache_put(key, audio):
        return None

TIKTOK_HOST = "api15-normal-alisg.tiktokv.com"
TIKTOK_PATH = "/media/api/text/speech/invoke/"
UA = (
    "com.zhiliaoapp.musically/2022600030 "
    "(Linux; U; Android 7.1.2; es_ES; SM-G988N; Build/NRD90M;tt-ok/3.12.13.1)"
)
BODY_SUFFIX = b"&speaker_map_type=0&aid=1233"

DEFAULT_HOSTS = [
    "api15-normal-alisg.tiktokv.com",
    "api21-normal-c-alisg.tiktokv.com",
    "api21-normal-n-alisg.tiktokv.com",
    "api33-normal-alisg.tiktokv.com",
    "api24-normal.tiktokv.com",
    "api19-normal-alisg.tiktokv.com",
    "api58-normal-c-alisg.tiktokv.com",
    "api58-normal-alisg.tiktokv.com",
    "api32-normal-alisg.tiktokv.com",
    "api21.tiktokv.com",
    "api19-normal.tiktokv.com",
    "api31-normal-alisg.tiktokv.com",
    "api21-normal.tiktokv.com",
]

_SSL = ssl.create_default_context()
_LAST_METRICS = {}
_PREFIX_CACHE = {}

SENT_RE = re.compile(r"[^.!?\n]+[.!?\n]*\s*")


def get_last_metrics():
    return dict(_LAST_METRICS)


def _hosts(override=None):
    if override:
        if isinstance(override, (list, tuple)):
            extra = [str(h).strip() for h in override if str(h or "").strip()]
        else:
            extra = [x.strip() for x in str(override).replace("\n", ",").split(",") if x.strip()]
    else:
        raw = os.environ.get("INTRO_PRO_TTS_HOSTS", "").strip()
        extra = ([x.strip() for x in raw.replace("\n", ",").split(",") if x.strip()]
                 if raw else list(DEFAULT_HOSTS))
    out = [TIKTOK_HOST] + [h for h in extra if h and h != TIKTOK_HOST]
    return list(dict.fromkeys(out))


def _text_len(t):
    return len(t.encode("utf-8"))


@functools.lru_cache(maxsize=8192)
def _chunk_cached(text, max_len=290):
    if not text or not text.strip():
        return ()
    sentences = SENT_RE.findall(text) or [text]
    chunks, buf = [], ""
    for s in sentences:
        if _text_len(s) > max_len:
            if buf.strip():
                chunks.append(buf.strip())
                buf = ""
            cur = ""
            for w in re.split(r"(\s+)", s):
                if _text_len(w) > max_len:
                    if cur.strip():
                        chunks.append(cur.strip())
                        cur = ""
                    for i in range(0, len(w), max_len):
                        chunks.append(w[i:i + max_len])
                elif _text_len(cur) + _text_len(w) > max_len:
                    if cur.strip():
                        chunks.append(cur.strip())
                    cur = w.lstrip()
                else:
                    cur += w
            if cur.strip():
                buf = cur
            continue
        if _text_len(buf) + _text_len(s) > max_len:
            if buf.strip():
                chunks.append(buf.strip())
            buf = s
        else:
            buf += s
    if buf.strip():
        chunks.append(buf.strip())
    return tuple(chunks)


def chunk_text(text, max_len=300):
    return list(_chunk_cached(text or "", int(max_len)))


def _prefix(voice):
    r = _PREFIX_CACHE.get(voice)
    if r is None:
        r = f"text_speaker={urllib.parse.quote(voice)}&req_text=".encode()
        _PREFIX_CACHE[voice] = r
    return r


def _body(voice, text):
    return _prefix(voice) + urllib.parse.quote(text).encode() + BODY_SUFFIX


def _retry_after(value):
    if not value:
        return None
    try:
        return max(0.0, float(value))
    except Exception:
        pass
    try:
        return max(0.0, parsedate_to_datetime(str(value)).timestamp() - time.time())
    except Exception:
        return None


def _backoff(attempt, throttled):
    base = 0.25 if throttled else 0.02
    return random.uniform(0, min(4.0, base * (2 ** max(0, attempt - 1))))


def _drain(task):
    try:
        if not task.cancelled():
            task.exception()
    except BaseException:
        pass


def _tune_socket(sock):
    for opt in (
        (socket.IPPROTO_TCP, socket.TCP_NODELAY, 1),
        (socket.IPPROTO_TCP, 12, 1),
        (socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1),
    ):
        try:
            sock.setsockopt(*opt)
        except Exception:
            pass


class _Dns:
    def __init__(self, ttl=300.0):
        self.ttl = float(ttl)
        self._cache = {}

    async def resolve(self, host):
        now = time.monotonic()
        hit = self._cache.get(host)
        if hit and hit[1] > now:
            return hit[0]
        loop = asyncio.get_running_loop()
        ip = await loop.run_in_executor(None, socket.gethostbyname, host)
        self._cache[host] = (ip, now + self.ttl)
        return ip


_dns = _Dns()


def _close(rw):
    try:
        rw[1].close()
    except Exception:
        pass


class _Pool:
    __slots__ = ("host", "ssl", "connect_timeout", "max_idle", "idle")

    def __init__(self, host, ssl_ctx, connect_timeout=8.0, max_idle=32):
        self.host = host
        self.ssl = ssl_ctx
        self.connect_timeout = float(connect_timeout)
        self.max_idle = int(max_idle)
        self.idle = collections.deque()

    async def _open(self):
        ip = await _dns.resolve(self.host)
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(
                ip, 443, ssl=self.ssl, server_hostname=self.host),
            timeout=self.connect_timeout)
        try:
            sock = writer.get_extra_info("socket")
            if sock is not None:
                _tune_socket(sock)
        except Exception:
            pass
        return [reader, writer]

    async def acquire(self):
        while self.idle:
            rw = self.idle.popleft()
            try:
                if not rw[1].is_closing() and not rw[0].at_eof():
                    return rw
            except Exception:
                pass
            _close(rw)
        return await self._open()

    def release(self, rw, keep):
        if keep and len(self.idle) < self.max_idle:
            try:
                if not rw[1].is_closing():
                    self.idle.append(rw)
                    return
            except Exception:
                pass
        _close(rw)

    async def _read_status(self, reader, timeout):
        raw = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), timeout=timeout)
        lines = raw.decode("latin-1").split("\r\n")
        status = int(lines[0].split(" ")[1])
        hdrs = {}
        for h in lines[1:]:
            if ":" in h:
                k, v = h.split(":", 1)
                hdrs[k.strip().lower()] = v.strip()
        return status, hdrs

    async def _read_body(self, reader, hdrs, timeout):
        if hdrs.get("transfer-encoding", "").lower() == "chunked":
            out = bytearray()
            while True:
                size_line = await asyncio.wait_for(reader.readuntil(b"\r\n"), timeout=timeout)
                n = int(size_line.strip() or b"0", 16)
                if n == 0:
                    await asyncio.wait_for(reader.readuntil(b"\r\n"), timeout=timeout)
                    break
                out += await asyncio.wait_for(reader.readexactly(n), timeout=timeout)
                await asyncio.wait_for(reader.readexactly(2), timeout=timeout)
            return bytes(out)
        cl = hdrs.get("content-length")
        if cl is not None:
            return await asyncio.wait_for(reader.readexactly(int(cl)), timeout=timeout)
        return await asyncio.wait_for(reader.read(), timeout=timeout)

    async def request(self, path, headers, body, timeout):
        rw = await self.acquire()
        reader, writer = rw
        try:
            lines = [f"POST {path} HTTP/1.1", f"Host: {self.host}"]
            for k, v in headers.items():
                lines.append(f"{k}: {v}")
            lines.append(f"Content-Length: {len(body)}")
            lines.append("Connection: keep-alive")
            head = ("\r\n".join(lines) + "\r\n\r\n").encode("latin-1")
            writer.write(head + body)
            await asyncio.wait_for(writer.drain(), timeout=timeout)
            status, hdrs = await self._read_status(reader, timeout)
            data = await self._read_body(reader, hdrs, timeout)
            keep = hdrs.get("connection", "keep-alive").lower() != "close"
            self.release(rw, keep)
            return status, data, hdrs
        except BaseException:
            self.release(rw, False)
            raise


class _Limiter:
    __slots__ = ("min", "max", "limit", "inflight", "short", "long", "q", "cond", "samples")

    def __init__(self, max_limit, start):
        self.min = 1.0
        self.max = float(max(1, max_limit))
        self.limit = float(min(max(1, start), self.max))
        self.inflight = 0
        self.short = None
        self.long = None
        self.q = float(os.environ.get("INTRO_PRO_TTS_QUEUE", "24"))
        self.cond = asyncio.Condition()
        self.samples = 0

    async def acquire(self):
        async with self.cond:
            while self.inflight >= int(self.limit):
                await self.cond.wait()
            self.inflight += 1

    async def release(self, rtt_ms=None, throttled=False, ok=True):
        async with self.cond:
            self.inflight = max(0, self.inflight - 1)
            if throttled:
                self.limit = max(self.min, self.limit * 0.5)
            elif ok and rtt_ms and rtt_ms > 0:
                self.samples += 1
                if self.short is None:
                    self.short = self.long = rtt_ms
                else:
                    self.short = self.short * 0.5 + rtt_ms * 0.5
                    self.long = self.long * 0.9 + rtt_ms * 0.1
                g = self.long / self.short if self.short > 0 else 1.0
                g = 0.5 if g < 0.5 else (1.0 if g > 1.0 else g)
                new_limit = g * self.limit + self.q
                self.limit = max(self.min, min(self.max, self.limit * 0.5 + new_limit * 0.5))
            self.cond.notify_all()

    def spare(self):
        return self.inflight < int(self.limit)

    def load(self):
        cap = int(self.limit)
        return 1.0 if cap <= 0 else self.inflight / float(cap)


class _Governor:
    def __init__(self, per_max, per_start):
        self.per_max = int(max(1, per_max))
        self.per_start = int(max(1, min(per_start, self.per_max)))
        self._lim = {}

    def get(self, sid):
        key = sid or "__nosid__"
        lim = self._lim.get(key)
        if lim is None:
            lim = _Limiter(self.per_max, self.per_start)
            self._lim[key] = lim
        return lim

    def spare(self, sid):
        lim = self._lim.get(sid or "__nosid__")
        return True if lim is None else lim.spare()

    def load(self, sid):
        lim = self._lim.get(sid or "__nosid__")
        return 0.0 if lim is None else lim.load()

    def total_limit(self):
        return sum(int(l.limit) for l in self._lim.values()) or self.per_start

    def report(self):
        rows = [(k, round(l.limit, 2), int(l.short or 0), l.samples)
                for k, l in self._lim.items()]
        rows.sort(key=lambda x: -x[1])
        return rows


class _Ranker:
    def __init__(self, hosts, max_fails=3, recovery=20.0, optimistic=80.0):
        seen = set()
        ordered = []
        for h in hosts:
            if h and h not in seen:
                seen.add(h)
                ordered.append(h)
        self.hosts = ordered or [TIKTOK_HOST]
        self.ewma = {h: None for h in self.hosts}
        self.inflight = {h: 0 for h in self.hosts}
        self.fails = {h: 0 for h in self.hosts}
        self.dead = {h: 0.0 for h in self.hosts}
        self.calls = {h: 0 for h in self.hosts}
        self.max_fails = int(max_fails)
        self.recovery = float(recovery)
        self.optimistic = float(optimistic)

    def pick(self, exclude=()):
        now = time.monotonic()
        live = [h for h in self.hosts if h not in exclude and self.dead[h] <= now]
        if not live:
            live = [h for h in self.hosts if h not in exclude] or list(self.hosts)
        weights = []
        for h in live:
            lat = self.ewma[h]
            if lat is None:
                lat = self.optimistic
            weights.append(1.0 / max(50.0, lat + self.inflight[h] * 3.0))
        total = sum(weights)
        if total <= 0:
            h = live[0]
        else:
            r = random.random() * total
            cum = 0.0
            h = live[0]
            for i, w in enumerate(weights):
                cum += w
                if r <= cum:
                    h = live[i]
                    break
        self.inflight[h] += 1
        self.calls[h] = self.calls.get(h, 0) + 1
        return h

    def done(self, host, latency=None, ok=True, penalize=False):
        if host in self.inflight:
            self.inflight[host] = max(0, self.inflight[host] - 1)
        if ok:
            if latency is not None:
                prev = self.ewma.get(host)
                self.ewma[host] = latency if prev is None else prev * 0.7 + latency * 0.3
            if not penalize:
                self.fails[host] = 0
                self.dead[host] = 0.0
        else:
            self.fails[host] = self.fails.get(host, 0) + 1
            if self.fails[host] >= self.max_fails:
                self.dead[host] = time.monotonic() + self.recovery

    def report(self, top=8):
        rows = []
        for h in self.hosts:
            if self.calls.get(h, 0) <= 0:
                continue
            lat = self.ewma.get(h)
            rows.append((h, lat if lat is not None else 9e9,
                         self.calls.get(h, 0), self.fails.get(h, 0)))
        rows.sort(key=lambda x: x[1])
        return rows[:top]


class _RttWindow:
    def __init__(self, maxlen=64, floor=0.25):
        self.buf = collections.deque(maxlen=maxlen)
        self.floor = floor
        self.hedge_cap = float(os.environ.get("INTRO_PRO_TTS_HEDGE_CAP_MS", "99999")) / 1000.0
        self.dead_cap = float(os.environ.get("INTRO_PRO_TTS_DEADLINE_CAP_MS", "30000")) / 1000.0

    def add(self, rtt_ms):
        if rtt_ms and rtt_ms > 0:
            self.buf.append(float(rtt_ms))

    def _pct(self, p):
        vals = sorted(self.buf)
        k = min(len(vals) - 1, int(round((len(vals) - 1) * p)))
        return vals[k]

    def delay(self, fallback):
        if len(self.buf) < 6:
            return max(self.floor, min(self.hedge_cap, fallback))
        p50 = self._pct(0.5) / 1000.0
        return max(self.floor, min(self.hedge_cap, p50 * 1.5 + random.uniform(0, p50 * 0.3)))

    def deadline(self, fallback):
        if len(self.buf) < 6:
            return max(2.0, min(self.dead_cap, fallback * 2.0))
        p95 = self._pct(0.95) / 1000.0
        return max(2.0, min(self.dead_cap, p95 * 2.0 + 0.5))


class _Metrics:
    def __init__(self):
        self.lat = []
        self.eff = []
        self.ok = 0
        self.cached = 0
        self.failed = 0
        self.throttled = 0
        self.retries = 0
        self.killed = 0
        self.dead = 0
        self.bytes = 0
        self.hf = 0
        self.hw = 0
        self.hx = 0
        self.t0 = time.perf_counter()

    def rec(self, *, latency=None, effective=None, ok=False, cached=False,
            failed=False, throttled=False, retry=False, killed=False, dead=False,
            nbytes=0, hf=False, hw=False, hx=False):
        if latency is not None and latency > 0:
            self.lat.append(float(latency))
        if effective is not None:
            self.eff.append(float(effective))
        if ok:
            self.ok += 1
        if cached:
            self.cached += 1
        if failed:
            self.failed += 1
        if throttled:
            self.throttled += 1
        if retry:
            self.retries += 1
        if killed:
            self.killed += 1
        if dead:
            self.dead += 1
        if nbytes:
            self.bytes += int(nbytes)
        if hf:
            self.hf += 1
        if hw:
            self.hw += 1
        if hx:
            self.hx += 1

    @staticmethod
    def _pct(vals, p):
        if not vals:
            return 0.0
        k = min(len(vals) - 1, max(0, int(round((len(vals) - 1) * p))))
        return vals[k]

    def snapshot(self):
        vals = sorted(self.lat)
        effs = sorted(self.eff)
        el = max(1e-6, time.perf_counter() - self.t0)
        return {
            "ok": self.ok,
            "cached": self.cached,
            "failed": self.failed,
            "throttled": self.throttled,
            "retries": self.retries,
            "killed_slow": self.killed,
            "dead_sessions": self.dead,
            "bytes_audio": self.bytes,
            "hedges_fired": self.hf,
            "hedges_won": self.hw,
            "hedge_wasted": self.hx,
            "elapsed": el,
            "rps_ok": self.ok / el,
            "p50_ms": self._pct(vals, 0.50),
            "p90_ms": self._pct(vals, 0.90),
            "p95_ms": self._pct(vals, 0.95),
            "p99_ms": self._pct(vals, 0.99),
            "max_ms": vals[-1] if vals else 0.0,
            "eff_p50_ms": self._pct(effs, 0.50),
            "eff_p95_ms": self._pct(effs, 0.95),
            "queue_p50_ms": max(0.0, self._pct(effs, 0.50) - self._pct(vals, 0.50)),
        }


class _TokenBucket:
    def __init__(self, rate, burst=None):
        self.rate = float(rate)
        self.cap = float(burst if burst else max(1.0, rate))
        self.tokens = self.cap
        self.last = time.monotonic()
        self.lock = asyncio.Lock()

    async def take(self):
        if self.rate <= 0:
            return
        while True:
            async with self.lock:
                now = time.monotonic()
                self.tokens = min(self.cap, self.tokens + (now - self.last) * self.rate)
                self.last = now
                if self.tokens >= 1:
                    self.tokens -= 1
                    return
                wait = (1 - self.tokens) / self.rate
            await asyncio.sleep(wait)


class _Net:
    __slots__ = ("ssl", "pools", "ranker", "governor", "metrics", "rttwin")

    def __init__(self, hosts, per_max, per_start, ssl_ctx):
        self.ssl = ssl_ctx
        self.pools = {}
        self.ranker = _Ranker(hosts)
        self.governor = _Governor(per_max, per_start)
        self.metrics = _Metrics()
        self.rttwin = _RttWindow()

    def pool(self, host):
        p = self.pools.get(host)
        if p is None:
            p = _Pool(host, self.ssl)
            self.pools[host] = p
        return p


async def _park(pool):
    try:
        rw = await pool._open()
        pool.release(rw, True)
    except Exception:
        pass


async def _prewarm(net, n):
    hs = net.ranker.hosts
    await asyncio.gather(*[_dns.resolve(h) for h in hs], return_exceptions=True)
    jobs = []
    for h in hs[:6]:
        pool = net.pool(h)
        for _ in range(max(1, int(n))):
            jobs.append(_park(pool))
    if jobs:
        await asyncio.gather(*jobs, return_exceptions=True)


def _route(pick_session, governor, probe=4):
    if pick_session is None:
        return None
    best = None
    best_load = None
    seen = set()
    for _ in range(probe):
        cand = pick_session()
        if cand is None:
            break
        if cand in seen:
            continue
        seen.add(cand)
        load = governor.load(cand)
        if best is None or load < best_load:
            best, best_load = cand, load
        if best_load is not None and best_load <= 0.0:
            break
    return best


def _route_spare(pick_session, governor, exclude, probe=6):
    if pick_session is None:
        return None
    best = None
    best_load = None
    seen = set()
    for _ in range(probe):
        cand = pick_session()
        if cand is None:
            break
        if cand in seen:
            continue
        seen.add(cand)
        load = governor.load(cand)
        fresh = cand not in exclude
        score = (0 if fresh else 1, load)
        if best is None or score < best_load:
            best, best_load = cand, score
        if fresh and governor.spare(cand):
            return cand
    if best is not None and governor.spare(best):
        return best
    return None


async def _fetch(net, host, sid, body, is_hedge, timeout_s):
    limiter = net.governor.get(sid)
    await limiter.acquire()
    kind = "error"
    audio = None
    status = -1
    lat = 0.0
    throttled = False
    retry_after = None
    t0 = time.perf_counter()
    try:
        headers = {"User-Agent": UA, "Content-Type": "application/x-www-form-urlencoded"}
        if sid:
            headers["Cookie"] = f"sessionid={sid}"
        status, data, rh = await net.pool(host).request(TIKTOK_PATH, headers, body, timeout_s)
        lat = (time.perf_counter() - t0) * 1000.0
        if status == 429 or status >= 500:
            throttled = (status == 429)
            retry_after = _retry_after(rh.get("retry-after")) if throttled else None
            kind = "throttle" if throttled else "error"
        else:
            j = _loads(data)
            sc = j.get("status_code", -1)
            if sc == 2:
                throttled = True
                kind = "throttle"
            elif sc in (4, 5, 10000):
                kind = "dead"
            elif sc == 1:
                kind = "empty"
                audio = b""
            else:
                b64 = (j.get("data") or {}).get("v_str")
                raw = base64.b64decode(re.sub(r"\s+", "", b64)) if b64 else b""
                if len(raw) < 32:
                    kind = "error"
                else:
                    kind = "ok"
                    audio = raw
    except asyncio.TimeoutError:
        lat = timeout_s * 1000.0
        kind = "killed"
    except BaseException:
        if lat == 0.0:
            lat = (time.perf_counter() - t0) * 1000.0
        kind = "error"
    finally:
        if kind == "killed":
            try:
                await limiter.release(rtt_ms=None, throttled=False, ok=True)
            except Exception:
                pass
            net.ranker.done(host, net.rttwin.dead_cap * 1000.0, ok=True, penalize=True)
        else:
            ok_host = kind in ("ok", "empty", "dead")
            try:
                await limiter.release(rtt_ms=lat if ok_host else None,
                                      throttled=throttled, ok=ok_host)
            except Exception:
                pass
            if ok_host:
                net.rttwin.add(lat)
            net.ranker.done(host, lat if ok_host else None, ok=ok_host)
    if kind == "throttle":
        net.metrics.rec(throttled=True, failed=True)
    elif kind == "killed":
        net.metrics.rec(killed=True)
    elif kind == "dead":
        net.metrics.rec(dead=True, failed=True)
    elif kind == "error":
        net.metrics.rec(failed=True)
    return {"kind": kind, "audio": audio, "latency": lat, "status": status,
            "host": host, "sid": sid, "is_hedge": is_hedge, "retry_after": retry_after}


async def _synth_one(net, pick_session, report_session, text, voice, retries,
                     fallback_s, hedge_enabled, cancel_event, max_len):
    if cancel_event is not None and cancel_event.is_set():
        return None
    ck = _cache_key(text, voice, max_len) if _cache_key else ""
    if ck:
        cached = _cache_get(ck)
        if cached is not None:
            net.metrics.rec(ok=True, cached=True, nbytes=len(cached))
            return cached
    body = _body(voice, text)
    attempt = 0
    last_retry_after = None
    last_throttled = False
    while True:
        if cancel_event is not None and cancel_event.is_set():
            return None
        host1 = net.ranker.pick()
        sid1 = _route(pick_session, net.governor)
        hedge_s = net.rttwin.delay(fallback_s) if hedge_enabled else None
        deadline_s = net.rttwin.deadline(fallback_s)
        t_cue = time.perf_counter()
        tasks = {asyncio.create_task(_fetch(net, host1, sid1, body, False, deadline_s))}
        used = {sid1}
        hedged = False
        done, _pending = await asyncio.wait(tasks, timeout=hedge_s)
        if not done and hedge_enabled:
            sid2 = _route_spare(pick_session, net.governor, used)
            if sid2 is not None:
                host2 = net.ranker.pick(exclude={host1})
                tasks.add(asyncio.create_task(_fetch(net, host2, sid2, body, True, deadline_s)))
                used.add(sid2)
                hedged = True
                net.metrics.rec(hf=True)
        winner = None
        while tasks:
            done, _pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            for tk in list(done):
                tasks.discard(tk)
                r = tk.result()
                if r["kind"] in ("ok", "empty"):
                    winner = r
                    break
                if r["kind"] == "throttle":
                    last_throttled = True
                    last_retry_after = r.get("retry_after")
                if report_session is not None and r["sid"]:
                    report_session(r["sid"], False)
            if winner is not None:
                break
        for tk in tasks:
            tk.add_done_callback(_drain)
        if winner is not None:
            eff = (time.perf_counter() - t_cue) * 1000.0
            net.metrics.rec(ok=True, latency=winner["latency"], effective=eff,
                            nbytes=len(winner["audio"] or b""),
                            hw=(hedged and winner["is_hedge"]),
                            hx=(hedged and not winner["is_hedge"]))
            if report_session is not None and winner["sid"]:
                report_session(winner["sid"], True)
            if ck and winner["audio"]:
                _cache_put(ck, winner["audio"])
            return winner["audio"]
        if cancel_event is not None and cancel_event.is_set():
            return None
        attempt += 1
        if attempt > retries:
            return None
        net.metrics.rec(retry=True)
        if last_retry_after is not None:
            await asyncio.sleep(last_retry_after)
            last_retry_after = None
        elif last_throttled:
            await asyncio.sleep(_backoff(attempt, True))
            last_throttled = False


def _estimate_sessions(pick_session, probe=24):
    if pick_session is None:
        return 1
    seen = set()
    for _ in range(probe):
        s = pick_session()
        if s is None:
            break
        seen.add(s)
    return max(1, len(seen))


async def _run(segments, *, pick_session, report_session, voice, max_len,
               concurrency, rate_per_sec, burst, retries, on_segment,
               progress_cb, hosts, hedge_ms, debug, debug_log, cancel_event,
               hedge_default, prewarm_n):
    global _LAST_METRICS
    seg_keys = []
    seg_parts = []
    seg_remaining = []
    meta = []
    for key, text in segments:
        subs = chunk_text(text or "", max_len)
        i = len(seg_keys)
        seg_keys.append(key)
        seg_parts.append([None] * len(subs))
        seg_remaining.append(len(subs))
        for si, sub in enumerate(subs):
            meta.append((i, si, sub))

    total_segments = len(seg_keys)
    done_segments = 0

    def _finish(i):
        nonlocal done_segments
        seg_audio = b"".join(p for p in seg_parts[i] if p)
        if on_segment is not None:
            try:
                on_segment(seg_keys[i], seg_audio)
            except Exception:
                pass
        done_segments += 1
        if progress_cb is not None:
            try:
                progress_cb(done_segments, max(1, total_segments))
            except Exception:
                pass

    for i in range(total_segments):
        if seg_remaining[i] == 0:
            _finish(i)

    if meta:
        per_max = int(os.environ.get("INTRO_PRO_TTS_PER_SESSION", "16"))
        per_start = int(os.environ.get("INTRO_PRO_TTS_PER_SESSION_START", "8"))
        net = _Net(_hosts(hosts), max(1, per_max), max(1, per_start), _SSL)
        nsessions = _estimate_sessions(pick_session)
        capacity = max(per_max, nsessions * per_max)
        forced = os.environ.get("INTRO_PRO_SRT_TTS_WORKERS", "").strip()
        if forced:
            worker_cap = int(forced)
        else:
            worker_cap = min(int(concurrency), capacity + nsessions * 4)
        worker_count = max(1, min(len(meta), max(4, worker_cap)))
        try:
            await _prewarm(net, prewarm_n)
        except Exception:
            pass
        if hedge_ms is not None:
            hedge_enabled = float(hedge_ms) > 0
            fallback_s = max(0.05, float(hedge_ms) / 1000.0)
        else:
            env = os.environ.get("INTRO_PRO_TTS_HEDGE_MS", "").strip().lower()
            if env in ("", "0", "off", "false", "no"):
                hedge_enabled = hedge_default
                fallback_s = 1.5
            else:
                hedge_enabled = True
                fallback_s = max(0.05, int(env) / 1000.0)
        dbg = debug_log if (debug and debug_log) else None
        bucket = _TokenBucket(rate_per_sec, burst or concurrency)
        idx = {"n": 0}
        idx_lock = asyncio.Lock()
        state_lock = asyncio.Lock()

        async def _next():
            async with idx_lock:
                if idx["n"] >= len(meta):
                    return None
                m = meta[idx["n"]]
                idx["n"] += 1
                return m

        async def _worker():
            while True:
                if cancel_event is not None and cancel_event.is_set():
                    return
                m = await _next()
                if m is None:
                    return
                sidx, subidx, text = m
                await bucket.take()
                audio = await _synth_one(
                    net, pick_session, report_session, text, voice, retries,
                    fallback_s, hedge_enabled, cancel_event, max_len)
                async with state_lock:
                    seg_parts[sidx][subidx] = audio if audio is not None else b""
                    seg_remaining[sidx] -= 1
                    if seg_remaining[sidx] == 0:
                        _finish(sidx)

        if dbg:
            dbg(f"[DBG] TURBO-NET: {len(meta)} request, sessions={nsessions}, "
                f"workers={worker_count}, cap={capacity} (per_session={per_max}), "
                f"nodelay={rate_per_sec <= 0}, "
                f"hedge={'on ' + str(int(fallback_s * 1000)) + 'ms' if hedge_enabled else 'off'}, "
                f"hosts={len(net.ranker.hosts)}")
        await asyncio.gather(*(asyncio.create_task(_worker()) for _ in range(worker_count)))
        snap = net.metrics.snapshot()
        snap.update({
            "final_concurrency": net.governor.total_limit(),
            "configured_concurrency": int(concurrency),
            "sessions": nsessions,
            "worker_count": worker_count,
            "scheduled_subchunks": len(meta),
            "hosts_used": sum(1 for h in net.ranker.hosts if net.ranker.calls.get(h, 0) > 0),
            "host_report": net.ranker.report(),
            "session_report": net.governor.report(),
        })
        _LAST_METRICS = snap
        if dbg:
            dbg(f"[DBG] DONE ok={snap.get('ok')} cached={snap.get('cached')} "
                f"killed_slow={snap.get('killed_slow')} "
                f"fired/won/wasted={snap.get('hedges_fired')}/{snap.get('hedges_won')}/"
                f"{snap.get('hedge_wasted')} hosts_used={snap.get('hosts_used')}")
    else:
        _LAST_METRICS.clear()

    results = []
    for i in range(total_segments):
        sp = seg_parts[i]
        if not sp:
            results.append((seg_keys[i], b""))
            continue
        good = [p for p in sp if p]
        results.append((seg_keys[i], b"".join(good) if good else None))
    return results


async def synthesize_segments(segments, *, pick_session, report_session=None,
                             voice="BV074_streaming", max_len=300,
                             concurrency=64, rate_per_sec=0, burst=None,
                             retries=4, on_segment=None, progress_cb=None,
                             hosts=None, hedge_ms=None, debug=False,
                             debug_log=None, cancel_event=None):
    return await _run(
        segments, pick_session=pick_session, report_session=report_session,
        voice=voice, max_len=max_len, concurrency=concurrency,
        rate_per_sec=rate_per_sec, burst=burst, retries=retries,
        on_segment=on_segment, progress_cb=progress_cb, hosts=hosts,
        hedge_ms=hedge_ms, debug=debug, debug_log=debug_log,
        cancel_event=cancel_event, hedge_default=True, prewarm_n=4)


async def synthesize_segments_tts(segments, *, pick_session, report_session=None,
                                  voice="BV074_streaming", max_len=300,
                                  concurrency=64, rate_per_sec=0, burst=None,
                                  retries=4, on_segment=None, progress_cb=None,
                                  hosts=None, hedge_ms=None, debug=False,
                                  debug_log=None, cancel_event=None):
    return await _run(
        segments, pick_session=pick_session, report_session=report_session,
        voice=voice, max_len=max_len, concurrency=concurrency,
        rate_per_sec=rate_per_sec, burst=burst, retries=retries,
        on_segment=on_segment, progress_cb=progress_cb, hosts=hosts,
        hedge_ms=hedge_ms, debug=debug, debug_log=debug_log,
        cancel_event=cancel_event, hedge_default=True, prewarm_n=6)


async def _warmup_async(hosts=None, n=8):
    hs = _hosts(hosts)
    await asyncio.gather(*[_dns.resolve(h) for h in hs], return_exceptions=True)

    async def _touch(host):
        try:
            ip = await _dns.resolve(host)
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(ip, 443, ssl=_SSL, server_hostname=host),
                timeout=8.0)
            try:
                sock = writer.get_extra_info("socket")
                if sock is not None:
                    _tune_socket(sock)
            except Exception:
                pass
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass
        except Exception:
            pass

    await asyncio.gather(*[_touch(h) for h in hs[:max(1, int(n))][:6]],
                         return_exceptions=True)


def warmup(hosts=None, limit=8):
    try:
        asyncio.run(_warmup_async(hosts, limit))
    except RuntimeError:
        loop = asyncio.new_event_loop()
        try:
            loop.run_until_complete(_warmup_async(hosts, limit))
        finally:
            loop.close()
