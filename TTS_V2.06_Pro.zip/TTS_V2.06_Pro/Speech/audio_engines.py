from __future__ import annotations

import asyncio
import importlib.util
import os
import platform
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

if platform.system() == "Windows":
    try:
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    except AttributeError:
        pass

from Speech import soundtouch as _st
from Speech.mp3turbo import decode_mp3 as _decode_mp3
from Speech.wav_utils import wav_header as _shared_wav_header, wav_meta as _shared_wav_meta

LogFn = Optional[Callable[[str], None]]

_TURBO_MODULE = None

ROOT_DIR = Path(__file__).resolve().parent
TURBO_PY = ROOT_DIR / 'turbo_tts' / 'python' / 'turbo_tts.py'
DEFAULT_PITCH_SEMITONES = 4.0

_LOOP_LOCK = threading.Lock()
_LOOP = None
_LOOP_THREAD = None


def _get_or_create_loop():
    global _LOOP, _LOOP_THREAD
    if _LOOP is not None and not _LOOP.is_closed():
        return _LOOP
    with _LOOP_LOCK:
        if _LOOP is not None and not _LOOP.is_closed():
            return _LOOP
        loop = asyncio.new_event_loop()

        def _runner():
            asyncio.set_event_loop(loop)
            loop.run_forever()

        _LOOP = loop
        _LOOP_THREAD = threading.Thread(target=_runner, name="tts-async-loop", daemon=True)
        _LOOP_THREAD.start()
        return loop


def _run_async(coro):
    try:
        running = asyncio.get_running_loop()
    except RuntimeError:
        running = None
    if running is not None:
        return asyncio.run(coro)
    loop = _get_or_create_loop()
    return asyncio.run_coroutine_threadsafe(coro, loop).result()


def _log(log: LogFn, msg: str) -> None:
    if log:
        log(msg)


def _tts_debug_on() -> bool:
    return str(os.environ.get('INTRO_PRO_TTS_DEBUG', '0')).strip().lower() not in (
        '', '0', 'false', 'no', 'off')


def _load_turbo_module():
    global _TURBO_MODULE
    if _TURBO_MODULE is not None:
        return _TURBO_MODULE
    if not TURBO_PY.exists():
        raise RuntimeError(f'Không tìm thấy turbo-tts: {TURBO_PY}')
    spec = importlib.util.spec_from_file_location('intro_pro_turbo_tts', TURBO_PY)
    if spec is None or spec.loader is None:
        raise RuntimeError('Không tải được turbo-tts module')
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    _TURBO_MODULE = mod
    return mod


def prewarm_network() -> None:
    try:
        mod = _load_turbo_module()
        fn = getattr(mod, 'warmup', None)
        if fn is not None:
            fn(limit=8)
    except Exception:
        pass


def _stage(stage_progress: Optional[Callable[[str, int], None]], name: str, value: int) -> None:
    if stage_progress:
        try:
            stage_progress(name, max(0, min(100, int(value))))
        except Exception:
            pass


def _auto_audio_workers(jobs: List[Dict[str, object]]) -> int:
    forced = os.environ.get('INTRO_PRO_MERGE_WORKERS', '').strip()
    if forced:
        return max(1, min(int(forced), len(jobs)))
    cpu = os.cpu_count() or 4
    return max(1, min(cpu, len(jobs)))


def _process_job(job: Dict[str, object]) -> Tuple[int, int, bytes]:
    jid = int(job.get('id') or 0)
    start_ms = int(job.get('startMs') or 0)

    wav_raw = job.get('wavBytes')
    mp3_raw = job.get('mp3Bytes')
    if wav_raw is not None:
        wav = bytes(wav_raw)
    else:
        if mp3_raw is None:
            raise RuntimeError('missing audio payload')
        mp3 = bytes(mp3_raw)
        target_channels = int(job.get('channels') or 1)
        pcm, hz, ch = _decode_mp3(mp3, force_mono=(target_channels == 1))
        if not pcm:
            wav = _st.pcm16_to_wav(b'', ch or target_channels,
                                   int(job.get('sampleRate') or hz or 44100))
        else:
            wav = _st.pcm16_to_wav(pcm, ch, hz)

    speed = float(job.get('speed') if job.get('speed') is not None else 1.0)
    semitones = float(job.get('semitones') if job.get('semitones') is not None else 0.0)
    if abs(speed - 1) >= 0.0001 or abs(semitones) >= 0.0001:
        wav = _st.process_wav_buffer(wav, {
            'speed': speed,
            'semitones': semitones,
            'interpolation': 'cubic',
            'quickSeek': False,
        })

    return (jid, start_ms, wav)


def _wav_meta(wav_bytes: bytes) -> Dict[str, int]:
    return _shared_wav_meta(wav_bytes)


def _wav_header(fmt: Dict[str, int], data_size: int) -> bytes:
    return _shared_wav_header(fmt, data_size)


class _TimelineWriter:
    def __init__(self, out_path: Path):
        self.path = Path(out_path)
        self.f = None
        self.fmt: Optional[Dict[str, int]] = None
        self.bpf = 1
        self.max_end = 44
        self.lock = threading.Lock()

    def _ensure(self, meta: Dict[str, int]) -> None:
        if self.f is None:
            if int(meta['audio_format']) != 1:
                raise RuntimeError('Audio core chỉ xuất PCM WAV')
            self.fmt = meta
            self.bpf = max(1, int(meta['channels']) * int(meta['bits_per_sample']) // 8)
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.f = open(self.path, 'wb+')
            self.f.write(_wav_header(meta, 0))
            self.max_end = 44

    def write(self, start_ms: int, wav: bytes) -> None:
        meta = _wav_meta(wav)
        with self.lock:
            self._ensure(meta)
            signature = ('sample_rate', 'channels', 'bits_per_sample', 'audio_format')
            if tuple(meta[k] for k in signature) != tuple(self.fmt[k] for k in signature):
                raise RuntimeError('WAV format không đồng nhất')
            sr = int(self.fmt['sample_rate'])
            offset_frame = int(round(int(start_ms) * sr / 1000.0))
            byte_off = 44 + offset_frame * self.bpf
            data = memoryview(wav)[int(meta['data_offset']): int(meta['data_offset'] + meta['data_size'])]
            self.f.seek(byte_off)
            self.f.write(data)
            end = byte_off + int(meta['data_size'])
            if end > self.max_end:
                self.max_end = end

    def finalize(self) -> int:
        with self.lock:
            if self.f is None or self.fmt is None:
                raise RuntimeError('Không có audio để ghép.')
            data_size = self.max_end - 44
            self.f.seek(0)
            self.f.write(_wav_header(self.fmt, data_size))
            self.f.truncate(self.max_end)
            self.f.flush()
            self.f.close()
            self.f = None
            sr = int(self.fmt['sample_rate'])
            frames = data_size // self.bpf
            return int(round(frames * 1000.0 / max(1, sr)))


def _new_st_stream(channels: int, sample_rate: int, speed: float, semitones: float):
    from Speech.soundtouch_native import NativeSoundTouchStream
    pitch = 2.0 ** (float(semitones) / 12.0)
    return NativeSoundTouchStream(int(channels), int(sample_rate), float(speed), pitch)


class _StreamingSTWriter:
    def __init__(self, out_path: Path, speed: float, semitones: float, first_id: int = 1):
        self.path = Path(out_path)
        self.next_id = int(first_id)
        self.pending: Dict[int, bytes] = {}
        self.f = None
        self.fmt: Optional[Dict[str, int]] = None
        self.bpf = 1
        self.total_data = 0
        self.lock = threading.Lock()
        self.speed = float(speed or 1.0)
        self.semitones = float(semitones or 0.0)
        self.noop = (abs(self.speed - 1.0) < 1e-4 and abs(self.semitones) < 1e-4)
        self.stream = None

    def _ensure(self, meta: Dict[str, int]) -> None:
        if self.f is None:
            if int(meta['audio_format']) != 1:
                raise RuntimeError('Audio core chỉ xuất PCM WAV')
            self.fmt = meta
            self.bpf = max(1, int(meta['channels']) * int(meta['bits_per_sample']) // 8)
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.f = open(self.path, 'wb+')
            self.f.write(_wav_header(meta, 0))
            if not self.noop:
                self.stream = _new_st_stream(
                    int(meta['channels']), int(meta['sample_rate']),
                    self.speed, self.semitones)

    def _write_ready_locked(self) -> None:
        while self.next_id in self.pending:
            wav = self.pending.pop(self.next_id)
            self.next_id += 1
            if not wav:
                continue
            meta = _wav_meta(wav)
            self._ensure(meta)
            signature = ('sample_rate', 'channels', 'bits_per_sample', 'audio_format')
            if tuple(meta[k] for k in signature) != tuple(self.fmt[k] for k in signature):
                raise RuntimeError('WAV format không đồng nhất')
            data = bytes(memoryview(wav)[int(meta['data_offset']): int(meta['data_offset'] + meta['data_size'])])
            if self.stream is not None:
                data = self.stream.feed_pcm16(data)
            if data:
                self.f.write(data)
                self.total_data += len(data)

    def add(self, seg_id: int, wav: bytes) -> None:
        with self.lock:
            self.pending[int(seg_id)] = wav
            self._write_ready_locked()

    def skip(self, seg_id: int) -> None:
        self.add(seg_id, b'')

    def finalize(self) -> int:
        with self.lock:
            self._write_ready_locked()
            if self.f is None or self.fmt is None:
                raise RuntimeError('Không có WAV RAM để nối')
            if self.stream is not None:
                tail = self.stream.flush_pcm16()
                if tail:
                    self.f.write(tail)
                    self.total_data += len(tail)
                self.stream = None
            self.f.seek(0)
            self.f.write(_wav_header(self.fmt, self.total_data))
            self.f.truncate(44 + self.total_data)
            self.f.flush()
            self.f.close()
            self.f = None
            frames = self.total_data // self.bpf
            return int(round(frames * 1000.0 / max(1, int(self.fmt['sample_rate']))))


def turbo_text_to_wav(
    text: str,
    session_ids: List[str],
    voice_id: str,
    out_path: Path,
    concurrency: int = 64,
    rate_per_sec: float = 0,
    speed: float = 1.0,
    semitones: float = 0.0,
    log: LogFn = None,
    progress_cb: Optional[Callable[[int, int], None]] = None,
    stage_progress: Optional[Callable[[str, int], None]] = None,
    cancel_event: Optional[threading.Event] = None,
) -> bool:
    if not session_ids:
        return False
    mod = _load_turbo_module()
    chunks = mod.chunk_text(text, 300)
    if not chunks:
        return False

    total = len(chunks)
    decode_workers = _auto_audio_workers([{'id': i + 1, 'mp3Bytes': b'x'} for i in range(total)])
    writer = _StreamingSTWriter(Path(out_path), speed=1.0, semitones=0.0, first_id=1)
    items_lock = threading.Lock()
    state = {'decoded': 0, 'last_ns': 0, 'last_pct': -1}
    ex = ThreadPoolExecutor(max_workers=decode_workers)
    futures: List[object] = []
    rr = {'i': 0}

    def _pick() -> Optional[str]:
        if not session_ids:
            return None
        sid = session_ids[rr['i'] % len(session_ids)]
        rr['i'] += 1
        return sid

    def _emit_mp3wav(force: bool = False) -> None:
        if not stage_progress:
            return
        now = time.perf_counter_ns()
        pct = int(max(0, min(100, round(state['decoded'] * 100 / max(1, total)))))
        if (not force and pct == state['last_pct']
                and now - state['last_ns'] < 80_000_000):
            return
        state['last_ns'] = now
        state['last_pct'] = pct
        _stage(stage_progress, 'mp3wav', pct)

    def _mark_text_done() -> None:
        with items_lock:
            state['decoded'] += 1
        _emit_mp3wav(False)

    def _decode_one(seg_id: int, audio: bytes) -> None:
        try:
            res = _process_job({
                'id': int(seg_id),
                'startMs': 0,
                'mp3Bytes': audio,
                'sampleRate': 44100,
                'channels': 1,
                'speed': 1.0,
                'semitones': 0.0,
            })
            writer.add(int(seg_id), res[2])
        except Exception as exc:
            writer.skip(int(seg_id))
            _log(log, f'[!] Decode text chunk lỗi (bỏ qua): {exc}')
        _mark_text_done()
        return None

    def _on_segment(seg_id, audio) -> None:
        if audio:
            futures.append(ex.submit(_decode_one, int(seg_id), audio))
        else:
            writer.skip(int(seg_id))
            _mark_text_done()

    _stage(stage_progress, 'mp3wav', 0)
    _log(log, f'[i] Turbo-TTS SERVER EXTREME: {total} chunk, concurrency<={concurrency}, '
              f'decode_workers={decode_workers}, rate={rate_per_sec}/s, temp I/O=0…')
    _t0_wall = time.perf_counter()
    try:
        _tts_net = getattr(mod, 'synthesize_segments_tts', mod.synthesize_segments)
        _run_async(_tts_net(
            [(i + 1, c) for i, c in enumerate(chunks)],
            pick_session=_pick,
            report_session=None,
            voice=voice_id,
            max_len=290,
            concurrency=max(1, int(concurrency)),
            rate_per_sec=max(0.0, float(rate_per_sec)),
            on_segment=_on_segment,
            progress_cb=progress_cb,
            debug=_tts_debug_on(),
            debug_log=((lambda m: _log(log, m)) if log else None),
            cancel_event=cancel_event,
        ))
        metrics = getattr(mod, 'get_last_metrics', lambda: {})()
        if metrics:
            _log(log, '[i] Server metrics: '
                      f"ok={metrics.get('ok', 0)}, retry={metrics.get('retries', 0)}, "
                      f"429={metrics.get('throttled', 0)}, "
                      f"p50={metrics.get('p50_ms', 0):.0f}ms, "
                      f"p95={metrics.get('p95_ms', 0):.0f}ms, "
                      f"p99={metrics.get('p99_ms', 0):.0f}ms, "
                      f"rps={metrics.get('rps_ok', 0):.1f}, "
                      f"limit={metrics.get('final_concurrency', 0)}/{metrics.get('configured_concurrency', 0)}, "
                      f"tasks={metrics.get('scheduled_subchunks', 0)}.")
            if metrics.get('hedges_fired'):
                _log(log, f"[i] Hedge cắt đuôi: fired={metrics.get('hedges_fired', 0)}, "
                          f"won={metrics.get('hedges_won', 0)}, "
                          f"wasted={metrics.get('hedge_wasted', 0)}, "
                          f"hosts_used={metrics.get('hosts_used', 0)}, "
                          f"max={metrics.get('max_ms', 0):.0f}ms.")
            for _h, _lat, _calls, _fails in (metrics.get('host_report') or [])[:6]:
                _lats = f"{_lat:.0f}ms" if _lat < 8e8 else "n/a"
                _log(log, f"[i]   · {_h}: ewma={_lats}, calls={_calls}, fails={_fails}.")
    finally:
        for f in futures:
            try:
                f.result()
            except Exception as exc:
                _log(log, f'[!] Decode text chunk lỗi (bỏ qua): {exc}')
        ex.shutdown(wait=True)

    _emit_mp3wav(True)
    if state['decoded'] <= 0:
        _log(log, '[!] Turbo-TTS không trả về audio.')
        return False

    try:
        dur_ms = writer.finalize()
    except Exception as exc:
        _log(log, f'[!] Turbo-TTS không có audio hợp lệ để ghi: {exc}')
        return False

    _spd = float(speed or 1.0)
    _semi = float(semitones or 0.0)
    if abs(_spd - 1.0) >= 1e-4 or abs(_semi) >= 1e-4:
        try:
            _raw = Path(out_path).read_bytes()
            _proc = _st.process_wav_buffer(_raw, {
                'speed': _spd,
                'semitones': _semi,
                'interpolation': 'cubic',
                'quickSeek': False,
            })
            Path(out_path).write_bytes(_proc)
            _m = _wav_meta(_proc)
            dur_ms = int(round(_m['frames'] * 1000.0 / max(1, _m['sample_rate'])))
        except Exception as exc:
            _log(log, f'[-] Pitch/Speed one-shot lỗi: {exc}')
            return False

    _wall_ms = int((time.perf_counter() - _t0_wall) * 1000.0)
    _log(log, f"[+] Turbo-TTS server extreme xong: {state['decoded']}/{total} chunk, "
              f"pitch/speed one-shot, thời gian thực≈{_wall_ms}ms (độ dài âm thanh≈{dur_ms}ms).")
    return True


def srt_cues_to_wav(
    cues,
    out_path,
    *,
    pick_session,
    report_session=None,
    voice,
    speed=1.0,
    semitones=0.0,
    concurrency=256,
    rate_per_sec=0.0,
    sample_rate=44100,
    log=None,
    stage_progress=None,
    progress_cb=None,
    cancel_event=None,
):
    cues = list(cues)
    if not cues:
        raise ValueError('Không có cue để dựng.')
    mod = _load_turbo_module()
    ms_by_id = {int(c['id']): int(c['ms']) for c in cues}
    segments = [(int(c['id']), str(c['text'])) for c in cues]
    total = len(segments)

    decode_workers = _auto_audio_workers(cues)
    writer = _TimelineWriter(Path(out_path))
    items_lock = threading.Lock()
    state = {'decoded': 0, 'last_ns': 0, 'last_pct': -1}
    ex = ThreadPoolExecutor(max_workers=decode_workers)
    futures = []

    base_speed = float(speed or 1.0)

    def _emit_mp3wav(force=False):
        if not stage_progress:
            return
        now = time.perf_counter_ns()
        pct = int(max(0, min(100, round(state['decoded'] * 100 / max(1, total)))))
        if (not force and pct == state['last_pct']
                and now - state['last_ns'] < 80_000_000):
            return
        state['last_ns'] = now
        state['last_pct'] = pct
        _stage(stage_progress, 'mp3wav', pct)

    def _decode_one_stream(cue_id, audio):
        job = {
            'id': cue_id,
            'startMs': ms_by_id.get(cue_id, 0),
            'mp3Bytes': audio,
            'sampleRate': int(sample_rate),
            'channels': 1,
            'speed': float(speed or 1.0),
            'semitones': float(semitones or 0.0),
        }
        res = _process_job(job)
        writer.write(res[1], res[2])
        with items_lock:
            state['decoded'] += 1
        _emit_mp3wav(False)
        return None

    def _on_segment(cue_id, audio):
        if not audio:
            return
        futures.append(ex.submit(_decode_one_stream, int(cue_id), audio))

    _stage(stage_progress, 'mp3wav', 0)
    _log(log, f'[i] SRT pipeline (đặt ĐÚNG Start_Time gốc, chỉ pitch+speed): {total} cue, '
              f'decode_workers={decode_workers}, concurrency<={max(1, int(concurrency))}, '
              f'speed={base_speed:.2f}x, temp I/O=0…')
    try:
        _run_async(mod.synthesize_segments(
            segments,
            pick_session=pick_session,
            report_session=report_session,
            voice=voice,
            max_len=290,
            concurrency=max(1, int(concurrency)),
            rate_per_sec=max(0.0, float(rate_per_sec)),
            on_segment=_on_segment,
            progress_cb=progress_cb,
            debug=_tts_debug_on(),
            debug_log=((lambda m: _log(log, m)) if log else None),
            cancel_event=cancel_event,
        ))
        metrics = getattr(mod, 'get_last_metrics', lambda: {})()
        if metrics:
            _log(log, '[i] Server metrics: '
                      f"ok={metrics.get('ok', 0)}, retry={metrics.get('retries', 0)}, "
                      f"429={metrics.get('throttled', 0)}, "
                      f"p50={metrics.get('p50_ms', 0):.0f}ms, "
                      f"p95={metrics.get('p95_ms', 0):.0f}ms, "
                      f"p99={metrics.get('p99_ms', 0):.0f}ms, "
                      f"rps={metrics.get('rps_ok', 0):.1f}, "
                      f"limit={metrics.get('final_concurrency', 0)}/{metrics.get('configured_concurrency', 0)}, "
                      f"tasks={metrics.get('scheduled_subchunks', 0)}.")
            if metrics.get('hedges_fired'):
                _log(log, f"[i] Hedge cắt đuôi: fired={metrics.get('hedges_fired', 0)}, "
                          f"won={metrics.get('hedges_won', 0)}, "
                          f"wasted={metrics.get('hedge_wasted', 0)}, "
                          f"hosts_used={metrics.get('hosts_used', 0)}, "
                          f"max={metrics.get('max_ms', 0):.0f}ms.")
            for _h, _lat, _calls, _fails in (metrics.get('host_report') or [])[:6]:
                _lats = f"{_lat:.0f}ms" if _lat < 8e8 else "n/a"
                _log(log, f"[i]   · {_h}: ewma={_lats}, calls={_calls}, fails={_fails}.")
    finally:
        for f in futures:
            try:
                f.result()
            except Exception as exc:
                _log(log, f'[!] Decode cue lỗi (bỏ qua): {exc}')
        ex.shutdown(wait=True)

    _emit_mp3wav(True)
    if state['decoded'] <= 0:
        raise RuntimeError('Không có audio để ghép.')
    dur_ms = writer.finalize()
    _log(log, f'[+] SRT pipeline xong: {state["decoded"]}/{total} cue ghi STREAMING theo '
              f'timeline (đặt ĐÚNG Start_Time phụ đề gốc, chỉ pitch+speed).')
    return dur_ms
