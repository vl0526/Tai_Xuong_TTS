# -*- coding: utf-8 -*-
# =============================================================================
#  Update_Server/sign_release.py
#  Công cụ MÁY PHÁT HÀNH (chạy trên máy của BẠN, không gửi cho người dùng):
#    * Tạo cặp khóa Ed25519 (1 lần duy nhất).
#    * Tính SHA-256 + ký gói cài đặt -> sinh 'latest.json' hoàn chỉnh.
#
#  LƯU Ý BẢO MẬT: giữ 'private_key.pem' TUYỆT ĐỐI BÍ MẬT. Chỉ công khai
#  'public_key_b64.txt' (dán vào App/updater.py -> PUBLIC_KEY_B64) và 'latest.json'.
#
#  CÀI: pip install cryptography
#
#  DÙNG:
#    1) Tạo khóa:   python sign_release.py keygen
#    2) Ký gói:     python sign_release.py sign \
#                       --file dist/TTS_Pro_Setup_2.0.6.exe \
#                       --version 2.0.6 \
#                       --url https://.../TTS_Pro_Setup_2.0.6.exe \
#                       --notes "Nội dung cập nhật"
# =============================================================================
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import sys


def _sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().lower()


def cmd_keygen(_args) -> int:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    priv = Ed25519PrivateKey.generate()
    pem = priv.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    with open("private_key.pem", "wb") as f:
        f.write(pem)

    raw_pub = priv.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    pub_b64 = base64.b64encode(raw_pub).decode()
    with open("public_key_b64.txt", "w", encoding="utf-8") as f:
        f.write(pub_b64)

    print("Đã tạo private_key.pem (GIỮ BÍ MẬT) và public_key_b64.txt")
    print("Dán chuỗi sau vào App/updater.py -> PUBLIC_KEY_B64:")
    print("  " + pub_b64)
    return 0


def cmd_sign(args) -> int:
    from cryptography.hazmat.primitives import serialization

    if not os.path.exists(args.file):
        print("Không tìm thấy file:", args.file)
        return 2

    sha = _sha256(args.file)
    size = os.path.getsize(args.file)
    signature = ""

    if os.path.exists("private_key.pem"):
        with open("private_key.pem", "rb") as f:
            priv = serialization.load_pem_private_key(f.read(), password=None)
        message = ("%s|%s" % (args.version, sha)).encode("utf-8")
        signature = base64.b64encode(priv.sign(message)).decode()
    else:
        print("[Cảnh báo] Không có private_key.pem -> latest.json sẽ KHÔNG có chữ ký.")

    manifest = {
        "version": args.version,
        "channel": args.channel,
        "kind": args.kind,
        "mandatory": args.mandatory,
        "notes": args.notes,
        "url": args.url,
        "sha256": sha,
        "size": size,
        "signature": signature,
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
    print("Đã ghi", args.out)
    print(json.dumps(manifest, indent=2, ensure_ascii=False))
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Ký & sinh manifest cập nhật TTS_Pro")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("keygen", help="Tạo cặp khóa Ed25519")

    sp = sub.add_parser("sign", help="Tính SHA-256, ký và sinh latest.json")
    sp.add_argument("--file", required=True, help="Đường dẫn gói cài đặt/.exe")
    sp.add_argument("--version", required=True)
    sp.add_argument("--url", required=True, help="URL tải gói (HTTPS)")
    sp.add_argument("--notes", default="")
    sp.add_argument("--channel", default="Pro")
    sp.add_argument("--kind", default="installer", choices=["installer", "exe"])
    sp.add_argument("--mandatory", action="store_true")
    sp.add_argument("--out", default="latest.json")

    args = ap.parse_args()
    if args.cmd == "keygen":
        return cmd_keygen(args)
    if args.cmd == "sign":
        return cmd_sign(args)
    return 1


if __name__ == "__main__":
    sys.exit(main())
