"""SoundTouch native availability helper.

This module intentionally does not download binaries at runtime. It validates a
user-provided/system SoundTouch library and reports the exact install action.
"""
from __future__ import annotations

import sys


def ensure_soundtouch() -> bool:
    try:
        from Speech.soundtouch_native import _lib
        _lib()
        return True
    except Exception:
        return False


def install_hint() -> str:
    if sys.platform.startswith("win"):
        return "Đặt SoundTouchDLL.dll (64-bit) vào Speech/native/ hoặc set SOUNDTOUCH_LIB."
    if sys.platform == "darwin":
        return "Cài `brew install sound-touch` hoặc set SOUNDTOUCH_LIB=/path/libSoundTouch.dylib."
    return "Cài libsoundtouch hệ thống hoặc set SOUNDTOUCH_LIB=/path/libSoundTouch.so."
