"""
mp3turbo.py — giải mã MP3 -> PCM bằng libmpg123 (DLL dựng sẵn, KHÔNG FFmpeg).

Vì sao dùng libmpg123:
  - Là bộ giải mã MP3 chuyên dụng, cực nhanh, tài nguyên thấp.
  - Có sẵn bản DLL Windows chính thức (libmpg123-0.dll) -> app chỉ cần
    TỰ ĐỘNG TẢI về, KHÔNG cần trình biên dịch, KHÔNG dùng FFmpeg.
  - Giải mã toàn bộ trong RAM, không file tạm, không resample.

Giữ nguyên API cũ: decode_mp3(mp3_bytes, force_mono) -> (pcm_bytes, hz, channels)
pcm_bytes là PCM 16-bit little-endian interleaved (mono nếu force_mono=True).

Tìm thư viện theo thứ tự (Speech/native/ trước, rồi cạnh file, rồi hệ thống):
  Windows: libmpg123-0.dll, libmpg123.dll
  Linux  : libmpg123.so.0, libmpg123.so
  macOS  : libmpg123.0.dylib, libmpg123.dylib
Biến môi trường ghi đè: LIBMPG123=/abs/path/lib (hoặc MP3TURBO_LIB).
"""
from __future__ import annotations

import ctypes
import ctypes.util
import os
import sys
import threading
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_LIB = None
_LIB_LOCK = threading.Lock()

# --- Hằng số ABI libmpg123 (lấy từ mpg123.h, ổn định tuyệt đối theo cam kết) ---
MPG123_OK = 0
MPG123_DONE = -12
MPG123_NEW_FORMAT = -11
MPG123_NEED_MORE = -10
MPG123_ADD_FLAGS = 2      # enum mpg123_parms
MPG123_FORCE_MONO = 0x7   # MONO_LEFT|MONO_RIGHT|MONO_MIX -> downmix mono

_READ_CHUNK = 1 << 16  # 64KB mỗi lần mpg123_read


def _dll_names() -> list[str]:
    if sys.platform.startswith("win"):
        return ["libmpg123-0.dll", "libmpg123.dll"]
    if sys.platform == "darwin":
        return ["libmpg123.0.dylib", "libmpg123.dylib"]
    return ["libmpg123.so.0", "libmpg123.so"]


def _candidate_paths() -> list[Path]:
    dirs = [_HERE / "native", _HERE]
    return [d / n for d in dirs for n in _dll_names()]


def _open_cdll() -> ctypes.CDLL:
    override = (os.environ.get("LIBMPG123", "").strip()
                or os.environ.get("MP3TURBO_LIB", "").strip())
    paths = [Path(override)] if override else _candidate_paths()
    # Cho phép Windows nạp DLL phụ (nếu có) cạnh libmpg123.
    if sys.platform.startswith("win"):
        for d in {p.parent for p in paths}:
            try:
                if d.exists():
                    os.add_dll_directory(str(d))
            except Exception:
                pass
    for p in paths:
        if p.exists():
            return ctypes.CDLL(str(p))
    # Thử thư viện hệ thống (Linux/mac đã cài mpg123).
    found = ctypes.util.find_library("mpg123")
    if found:
        return ctypes.CDLL(found)
    raise RuntimeError(
        "Không tìm thấy libmpg123. Đã tìm: "
        + ", ".join(str(p) for p in paths)
        + ". Trên Windows app sẽ tự động tải libmpg123-0.dll vào Speech/native/ "
        + "(xem App/autosetup.py)."
    )


def _bind(lib: ctypes.CDLL) -> ctypes.CDLL:
    c_void_p, c_int, c_long = ctypes.c_void_p, ctypes.c_int, ctypes.c_long
    c_size_t, c_double, c_char_p = ctypes.c_size_t, ctypes.c_double, ctypes.c_char_p
    P = ctypes.POINTER
    # mpg123_init() có ở bản cũ; bản mới là no-op an toàn.
    if hasattr(lib, "mpg123_init"):
        lib.mpg123_init.restype = c_int
        lib.mpg123_init.argtypes = []
    lib.mpg123_new.restype = c_void_p
    lib.mpg123_new.argtypes = [c_char_p, P(c_int)]
    lib.mpg123_param.restype = c_int
    lib.mpg123_param.argtypes = [c_void_p, c_int, c_long, c_double]
    lib.mpg123_format_none.restype = c_int
    lib.mpg123_format_none.argtypes = [c_void_p]
    lib.mpg123_format.restype = c_int
    lib.mpg123_format.argtypes = [c_void_p, c_long, c_int, c_int]
    lib.mpg123_open_feed.restype = c_int
    lib.mpg123_open_feed.argtypes = [c_void_p]
    lib.mpg123_feed.restype = c_int
    lib.mpg123_feed.argtypes = [c_void_p, c_char_p, c_size_t]
    lib.mpg123_read.restype = c_int
    lib.mpg123_read.argtypes = [c_void_p, c_char_p, c_size_t, P(c_size_t)]
    lib.mpg123_getformat.restype = c_int
    lib.mpg123_getformat.argtypes = [c_void_p, P(c_long), P(c_int), P(c_int)]
    lib.mpg123_close.restype = c_int
    lib.mpg123_close.argtypes = [c_void_p]
    lib.mpg123_delete.restype = None
    lib.mpg123_delete.argtypes = [c_void_p]
    return lib


def _load_library() -> ctypes.CDLL:
    lib = _bind(_open_cdll())
    if hasattr(lib, "mpg123_init"):
        try:
            lib.mpg123_init()
        except Exception:
            pass
    return lib


def _lib() -> ctypes.CDLL:
    global _LIB
    if _LIB is None:
        with _LIB_LOCK:
            if _LIB is None:
                _LIB = _load_library()
    return _LIB


def decode_mp3(mp3_bytes: bytes, force_mono: bool = True):
    """Decode MP3 -> (pcm_bytes, hz, channels). pcm_bytes = 16-bit LE interleaved."""
    lib = _lib()
    err = ctypes.c_int(0)
    h = lib.mpg123_new(None, ctypes.byref(err))
    if not h:
        raise RuntimeError(f"mpg123_new lỗi (err={err.value})")
    try:
        if force_mono:
            lib.mpg123_param(h, MPG123_ADD_FLAGS, MPG123_FORCE_MONO, 0.0)
        if lib.mpg123_open_feed(h) != MPG123_OK:
            raise RuntimeError("mpg123_open_feed lỗi")
        if lib.mpg123_feed(h, mp3_bytes, len(mp3_bytes)) != MPG123_OK:
            raise RuntimeError("mpg123_feed lỗi")

        rate = ctypes.c_long(0)
        channels = ctypes.c_int(0)
        encoding = ctypes.c_int(0)
        got_fmt = False
        out = bytearray(1 << 20)
        out_len = 0
        buf = ctypes.create_string_buffer(_READ_CHUNK)
        done = ctypes.c_size_t(0)
        while True:
            rc = lib.mpg123_read(h, buf, _READ_CHUNK, ctypes.byref(done))
            if done.value:
                needed = out_len + int(done.value)
                if needed > len(out):
                    out.extend(b"\x00" * (max(len(out) * 2, needed) - len(out)))
                ctypes.memmove((ctypes.c_char * int(done.value)).from_buffer(out, out_len), buf, int(done.value))
                out_len = needed
            if not got_fmt and rc in (MPG123_OK, MPG123_NEW_FORMAT):
                lib.mpg123_getformat(h, ctypes.byref(rate),
                                     ctypes.byref(channels), ctypes.byref(encoding))
                got_fmt = True
            if rc in (MPG123_OK, MPG123_NEW_FORMAT):
                continue
            if rc in (MPG123_NEED_MORE, MPG123_DONE):
                break
            raise RuntimeError(f"mpg123_read lỗi rc={rc}")

        if not got_fmt:
            lib.mpg123_getformat(h, ctypes.byref(rate),
                                 ctypes.byref(channels), ctypes.byref(encoding))
        del out[out_len:]
        hz = int(rate.value) or 44100
        ch = int(channels.value) or (1 if force_mono else 2)
        return bytes(out), hz, ch
    finally:
        try:
            lib.mpg123_close(h)
        finally:
            lib.mpg123_delete(h)
