"""Shared WAV helpers for TTS_Pro V2.0.6_Pro."""
from __future__ import annotations

import struct
from typing import Dict, Optional


def wav_meta(wav_bytes: bytes) -> Dict[str, int]:
    if len(wav_bytes) < 44 or wav_bytes[:4] != b"RIFF" or wav_bytes[8:12] != b"WAVE":
        raise RuntimeError("WAV RAM không hợp lệ")
    pos = 12
    fmt: Optional[Dict[str, int]] = None
    data_offset = -1
    data_size = 0
    n = len(wav_bytes)
    while pos + 8 <= n:
        cid = wav_bytes[pos:pos + 4]
        size = struct.unpack_from("<I", wav_bytes, pos + 4)[0]
        body = pos + 8
        if cid == b"fmt ":
            fmt = {
                "audio_format": struct.unpack_from("<H", wav_bytes, body)[0],
                "channels": struct.unpack_from("<H", wav_bytes, body + 2)[0],
                "sample_rate": struct.unpack_from("<I", wav_bytes, body + 4)[0],
                "bits_per_sample": struct.unpack_from("<H", wav_bytes, body + 14)[0],
            }
        elif cid == b"data":
            data_offset = body
            data_size = min(size, max(0, n - body))
        pos = body + size + (size & 1)
    if fmt is None or data_offset < 0:
        raise RuntimeError("WAV thiếu fmt/data chunk")
    fmt["data_offset"] = data_offset
    fmt["data_size"] = data_size
    bpf = max(1, fmt["channels"] * fmt["bits_per_sample"] // 8)
    fmt["frames"] = data_size // bpf
    return fmt


def wav_header(fmt: Dict[str, int], data_size: int) -> bytes:
    channels = int(fmt.get("channels", fmt.get("Channels", 1)))
    sample_rate = int(fmt.get("sample_rate", fmt.get("sampleRate", 44100)))
    bits = int(fmt.get("bits_per_sample", fmt.get("bitsPerSample", 16)))
    byte_rate = sample_rate * channels * bits // 8
    block_align = channels * bits // 8
    return struct.pack(
        "<4sI4s4sIHHIIHH4sI",
        b"RIFF", 36 + int(data_size), b"WAVE", b"fmt ", 16,
        1, channels, sample_rate, byte_rate, block_align, bits,
        b"data", int(data_size),
    )
