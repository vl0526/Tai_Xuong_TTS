"""Streaming SRT/WebVTT parser — avoids loading the full file into memory."""
from __future__ import annotations

import mmap
import re
from pathlib import Path
from typing import Any, Dict, Iterator, List

_SUB_TIME_RX = re.compile(
    rb"(?P<start>\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})\s*-->\s*"
    rb"(?P<end>\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})"
)
_TAG_RX = re.compile(rb"</?[^>]+>")
_ASS_RX = re.compile(rb"\{\\.*?\}")
_META_PREFIXES = (b"NOTE", b"STYLE", b"REGION", b"WEBVTT")


def srt_time_to_ms_raw(t: bytes) -> int:
    t = t.strip().replace(b",", b".")
    parts = t.split(b":")
    if len(parts) != 3:
        return 0
    h, m, s = parts
    try:
        sec, ms = s.split(b".", 1)
        return (int(h) * 3600 + int(m) * 60 + int(sec)) * 1000 + int(ms[:3].ljust(3, b"0"))
    except Exception:
        return 0


def _clean_lines(lines: List[bytes]) -> str:
    out: List[str] = []
    for raw in lines:
        t = raw.strip()
        if not t:
            continue
        up = t.upper()
        if any(up.startswith(p) for p in _META_PREFIXES):
            continue
        t = _TAG_RX.sub(b"", t)
        t = _ASS_RX.sub(b"", t)
        t = re.sub(rb"\s+", b" ", t).strip()
        if t:
            out.append(t.decode("utf-8", errors="ignore").strip())
    return " ".join(x for x in out if x).strip()


def iter_srt_cues(path: str | Path) -> Iterator[Dict[str, Any]]:
    p = Path(path)
    if not p.exists() or p.stat().st_size <= 0:
        return
    cue_id = 1
    with p.open("rb") as f:
        with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
            lines = mm.read().replace(b"\r\n", b"\n").replace(b"\r", b"\n").split(b"\n")
            i = 0
            n = len(lines)
            while i < n:
                m = _SUB_TIME_RX.search(lines[i].strip())
                if not m:
                    i += 1
                    continue
                start_ms = srt_time_to_ms_raw(m.group("start"))
                i += 1
                buf: List[bytes] = []
                while i < n and lines[i].strip():
                    if _SUB_TIME_RX.search(lines[i]):
                        break
                    buf.append(lines[i])
                    i += 1
                text = _clean_lines(buf)
                if text:
                    yield {"id": cue_id, "ms": start_ms, "text": text}
                    cue_id += 1


def parse_srt(path: str | Path) -> List[Dict[str, Any]]:
    return list(iter_srt_cues(path))


def is_srt_nonempty(path: str | Path) -> bool:
    try:
        return next(iter_srt_cues(path), None) is not None
    except Exception:
        return False
