"""Disk-backed LRU-ish cache for text→audio MP3 payloads."""
from __future__ import annotations

import hashlib
import os
import threading
import time
from pathlib import Path
from typing import Optional

_CACHE_DIR = Path(os.environ.get("INTRO_PRO_TTS_CACHE_DIR", Path.home() / ".tts_pro_code_assets" / "audio_cache"))
_MAX_BYTES = int(os.environ.get("INTRO_PRO_TTS_CACHE_MAX_BYTES", str(2 * 1024 * 1024 * 1024)))
_LOCK = threading.Lock()
_TOTAL_BYTES = None  # bo dem dung luong trong RAM (lazy init) -> khong rglob moi lan ghi


def cache_key(text: str, voice: str, max_len: int = 290) -> str:
    h = hashlib.sha256()
    h.update(str(voice or "").encode("utf-8")); h.update(b"\0")
    h.update(str(max_len).encode("ascii")); h.update(b"\0")
    h.update(str(text or "").encode("utf-8"))
    return h.hexdigest()


def _path(key: str) -> Path:
    return _CACHE_DIR / key[:2] / (key + ".mp3")


def get_audio(key: str) -> Optional[bytes]:
    if os.environ.get("INTRO_PRO_TTS_CACHE", "1").strip().lower() in ("0", "false", "no", "off"):
        return None
    p = _path(key)
    try:
        data = p.read_bytes()
        if data:
            # Chi 'touch' khi mtime da cu (>1h) -> giam write amplification: doc
            # cache khong con sinh 1 he thong-write moi lan (quan trong o batch lon).
            try:
                st = p.stat()
                now = time.time()
                if now - st.st_mtime > 3600:
                    os.utime(p, (now, now))
            except Exception:
                pass
        return data if data else None
    except Exception:
        return None


def put_audio(key: str, audio: bytes) -> None:
    if not audio or os.environ.get("INTRO_PRO_TTS_CACHE", "1").strip().lower() in ("0", "false", "no", "off"):
        return
    p = _path(key)
    with _LOCK:
        try:
            global _TOTAL_BYTES
            p.parent.mkdir(parents=True, exist_ok=True)
            new = bytes(audio)
            old = 0
            if p.exists():
                try:
                    old = p.stat().st_size
                except Exception:
                    old = 0
            p.write_bytes(new)
            _ensure_total_locked()
            _TOTAL_BYTES += len(new) - old
            # Chi quet+trim khi THUC SU vuot tran (hiem) -> khong rglob O(N) moi ghi.
            if _TOTAL_BYTES > _MAX_BYTES:
                _trim_cache_locked()
        except Exception:
            pass


def _ensure_total_locked() -> int:
    """Khoi tao bo dem dung luong 1 lan (quet dia duy nhat), sau do duy tri
    incremental trong put_audio -> tranh rglob toan bo cache moi lan ghi."""
    global _TOTAL_BYTES
    if _TOTAL_BYTES is None:
        total = 0
        try:
            for p in _CACHE_DIR.rglob("*.mp3"):
                try:
                    total += p.stat().st_size
                except Exception:
                    pass
        except Exception:
            pass
        _TOTAL_BYTES = total
    return _TOTAL_BYTES


def _trim_cache_locked() -> None:
    global _TOTAL_BYTES
    try:
        files = [(p, p.stat().st_size, p.stat().st_mtime) for p in _CACHE_DIR.rglob("*.mp3") if p.is_file()]
        total = sum(sz for _, sz, _ in files)
        _TOTAL_BYTES = total
        if total <= _MAX_BYTES:
            return
        files.sort(key=lambda t: t[2])
        for p, sz, _mt in files:
            if total <= _MAX_BYTES:
                break
            try:
                p.unlink()
                total -= sz
            except Exception:
                pass
        _TOTAL_BYTES = total
    except Exception:
        pass
