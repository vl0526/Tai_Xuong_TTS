"""
soundtouch.py — Pitch/Speed layer.

CHI DUNG DUONG TOT NHAT: pitch/speed chay 100%% tren SoundTouch NATIVE (DLL).
Da GO BO VINH VIEN toan bo:
  - Engine WSOLA/RateTransposer/TDStretch port thuan Python (nhanh du phong).
  - WAV codec decode_wav/encode_wav khong dung den.
  - Moi nhanh non-NumPy va auto-install NumPy (NumPy do App/autosetup.py lo).
Neu DLL thieu/hong: raise loi ro rang (KHONG bao gio am tham roi sang ban cham).

Module nay chi con: mo ta option pitch/speed + goi SoundTouch native + helper
WAV header PCM16 toi thieu.
"""
from __future__ import annotations

import struct
import math
from typing import Optional

_EPS = 1e-9


def _almost_equal(a: float, b: float) -> bool:
    return abs(a - b) < _EPS


# ===========================================================================
# Option helpers (engine.js port — phan con dung)
# ===========================================================================
def pitch_ratio(semitones=0.0, cents=0.0):
    s = semitones + cents / 100.0
    return math.pow(2, s / 12.0)


def normalize_options(opts: Optional[dict] = None) -> dict:
    opts = opts or {}
    speed = opts.get("speed")
    if speed is None:
        tp = opts.get("tempoPercent")
        speed = (1 + tp / 100.0) if tp is not None else 1
    return {
        "semitones": opts.get("semitones", 0),
        "cents": opts.get("cents", 0),
        "speed": speed,
        "rate": opts.get("rate", 1),
    }


def is_no_op(opts: Optional[dict] = None) -> bool:
    o = normalize_options(opts)
    return (
        _almost_equal(pitch_ratio(o["semitones"], o["cents"]), 1)
        and _almost_equal(o["speed"], 1)
        and _almost_equal(o["rate"], 1)
    )


# ===========================================================================
# WAV header (PCM16) + meta — minimal helpers
# ===========================================================================
def pcm16_header(sampleRate: int, channels: int, dataSize: int) -> bytes:
    bitsPerSample = 16
    blockAlign = channels * bitsPerSample // 8
    byteRate = sampleRate * blockAlign
    return struct.pack(
        "<4sI4s4sIHHIIHH4sI",
        b"RIFF", 36 + dataSize, b"WAVE", b"fmt ", 16,
        1, channels, sampleRate, byteRate, blockAlign, bitsPerSample,
        b"data", dataSize,
    )


def pcm16_to_wav(pcm: bytes, channels: int, sampleRate: int) -> bytes:
    return pcm16_header(sampleRate, channels, len(pcm)) + pcm


def _wav_meta_local(wav: bytes) -> dict:
    if len(wav) < 44 or wav[0:4] != b"RIFF" or wav[8:12] != b"WAVE":
        raise ValueError("invalid WAV")
    pos = 12
    fmt = None
    dataOffset = -1
    dataSize = 0
    n = len(wav)
    while pos + 8 <= n:
        cid = wav[pos:pos + 4]
        size = struct.unpack_from("<I", wav, pos + 4)[0]
        body = pos + 8
        if cid == b"fmt ":
            fmt = {
                "audioFormat": struct.unpack_from("<H", wav, body)[0],
                "channels": struct.unpack_from("<H", wav, body + 2)[0],
                "sampleRate": struct.unpack_from("<I", wav, body + 4)[0],
                "bitsPerSample": struct.unpack_from("<H", wav, body + 14)[0],
            }
        elif cid == b"data":
            dataOffset = body
            dataSize = min(size, max(0, n - body))
        pos = body + size + (size & 1)
    if fmt is None or dataOffset < 0:
        raise ValueError("WAV missing fmt/data")
    fmt["dataOffset"] = dataOffset
    fmt["dataSize"] = dataSize
    return fmt


# ===========================================================================
# Pitch/Speed — SoundTouch NATIVE only (KHONG fallback)
# ===========================================================================
def process_wav_buffer(wav_bytes: bytes, options: Optional[dict] = None) -> bytes:
    """Pitch/Speed CHI chay tren SoundTouch native (DLL). Neu DLL thieu/hong
    thi raise loi ro rang de nguoi dung biet ngay, thay vi am tham rot sang
    ban thuong (nguon goc tieng re)."""
    options = options or {}
    if is_no_op(options):
        return bytes(wav_bytes)
    from Speech.soundtouch_native import process_pcm_native
    meta = _wav_meta_local(wav_bytes)
    if not (meta["audioFormat"] == 1 and meta["bitsPerSample"] == 16 and meta["dataSize"] > 0):
        raise RuntimeError(
            "Pitch/Speed native chi nhan PCM WAV 16-bit; nhan duoc "
            f"format={meta.get('audioFormat')} bits={meta.get('bitsPerSample')} "
            f"dataSize={meta.get('dataSize')}."
        )
    pcm = wav_bytes[meta["dataOffset"]: meta["dataOffset"] + meta["dataSize"]]
    tempo = float(options.get("speed", 1.0) or 1.0)
    semitones = float(options.get("semitones", 0.0) or 0.0)
    out_pcm = process_pcm_native(
        pcm, int(meta["channels"]), int(meta["sampleRate"]),
        tempo, 2 ** (semitones / 12.0),
    )
    if not out_pcm:
        raise RuntimeError("SoundTouch native tra ve 0 mau (pitch/speed that bai).")
    return pcm16_header(int(meta["sampleRate"]), int(meta["channels"]), len(out_pcm)) + out_pcm
