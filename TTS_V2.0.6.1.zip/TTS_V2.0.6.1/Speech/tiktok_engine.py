from __future__ import annotations

import os
import re
import time
import traceback
import threading
import random
from pathlib import Path
from urllib.request import Request, urlopen
from typing import Any, Callable, Dict, List, Optional, Tuple
from Speech.audio_engines import DEFAULT_PITCH_SEMITONES, turbo_text_to_wav
from Speech.srt_parser import parse_srt as _parse_srt_stream

DEFAULT_VOICE = "BV074_streaming"
SESSION_SOURCE_URL = "https://raw.githubusercontent.com/vl0526/0101/refs/heads/main/SessionID.Txt"
_SESSION_CACHE: Dict[str, Any] = {"at": 0.0, "ids": []}
_SESSION_CACHE_TTL = 600.0

TIKTOK_VOICE_MAP: Dict[str, str] = {
    "Cô Gái Hoạt Ngôn": "BV074_streaming",
    "Thanh Niên Tự Tin": "BV075_streaming",
    "Giọng Nữ Phổ Thông": "vi_female_huong",
    "Nguồn Nhỏ Ngọt Ngào": "BV421_vivn_streaming",
    "Anh Dũng": "BV560_streaming",
    "Chí Mai": "BV562_streaming",
    "Việt Rung": "BV075_streaming_vibrato_dsp",
    "Quỷ Việt": "BV075_streaming_demon_dsp",
    "giọng bé": "BV074_streaming_dsp",
    "Robot VN": "BV075_streaming_robot_dsp",
}

LogFn = Optional[Callable[[str], None]]
ProgressFn = Optional[Callable[[int], None]]

_VALID_SID_RE = re.compile(r"^[A-Za-z0-9]{12,256}$")


def _log(fn: LogFn, msg: str) -> None:
    if fn:
        fn(msg)


def _progress(fn: ProgressFn, v: int) -> None:
    if fn:
        fn(max(0, min(100, int(v))))


def parse_srt(path: Path) -> List[Dict[str, Any]]:
    return _parse_srt_stream(path)


def _clean_session_id(raw: Any) -> str:
    try:
        s = str(raw or "").strip().strip('"').strip("'").strip()
    except Exception:
        return ""
    if not s:
        return ""
    if ";" in s:
        for part in s.split(";"):
            if "sessionid" in part.lower():
                s = part
                break
        else:
            s = s.split(";", 1)[0]
        s = s.strip()
    if "=" in s:
        s = s.split("=", 1)[1].strip()
    if _VALID_SID_RE.match(s):
        return s
    m = re.search(r"[0-9a-f]{32}", s)
    if m:
        return m.group(0)
    runs = re.findall(r"[A-Za-z0-9]{16,}", s)
    if runs:
        return max(runs, key=len)
    return s


def _is_valid_sid(sid: str) -> bool:
    return bool(sid) and bool(_VALID_SID_RE.match(sid))


def _load_remote_session_ids(log: LogFn = None) -> List[str]:
    now = time.time()
    cached = list(_SESSION_CACHE.get("ids") or [])
    if cached and now - float(_SESSION_CACHE.get("at") or 0.0) < _SESSION_CACHE_TTL:
        _log(log, f"[+] Tái sử dụng {len(cached)} Session ID đã cache.")
        return cached
    try:
        req = Request(SESSION_SOURCE_URL, headers={"User-Agent": "TTS_Pro/2.0"})
        _jitter = random.uniform(0, 3.0)
        if _jitter > 0:
            time.sleep(_jitter)
        with urlopen(req, timeout=8) as resp:
            raw = resp.read(1024 * 128).decode("utf-8", errors="ignore")
    except Exception as exc:
        if cached:
            _log(log, f"[!] Không tải mới được SessionID.Txt, dùng cache: {exc}")
            return cached
        _log(log, f"[-] Không tải được SessionID.Txt: {exc}")
        return []
    out: List[str] = []
    seen = set()
    for line in raw.replace("\r", "\n").split("\n"):
        sid = _clean_session_id(line)
        if _is_valid_sid(sid) and sid not in seen:
            out.append(sid)
            seen.add(sid)
    if out:
        _SESSION_CACHE["ids"] = out
        _SESSION_CACHE["at"] = now
        _log(log, f"[+] Đã tải {len(out)} Session ID từ GitHub.")
    else:
        _log(log, "[-] SessionID.Txt không có Session ID hợp lệ.")
    return out


class KeyPool:
    def __init__(
        self,
        session_ids: Optional[List[str]] = None,
        max_fails: int = 4,
        recovery: float = 90.0,
    ) -> None:
        raw_list = [r for r in (session_ids or []) if str(r or "").strip()]
        cleaned: List[str] = []
        seen = set()
        for r in raw_list:
            c = _clean_session_id(r)
            if _is_valid_sid(c) and c not in seen:
                cleaned.append(c)
                seen.add(c)
        self._sessions: List[str] = cleaned
        self.input_count: int = len(raw_list)
        self.valid_count: int = len(cleaned)
        self.invalid_count: int = self.input_count - self.valid_count
        self._idx: int = 0
        self._fails: Dict[str, int] = {}
        self._dead_until: Dict[str, float] = {}
        self._lock = threading.Lock()
        self._max_fails = int(max_fails)
        self._recovery = float(recovery)
        self._success_rate: Dict[str, float] = {s: 0.5 for s in cleaned}
        self._total_calls: Dict[str, int] = {}
        self._total_ok: Dict[str, int] = {}

    @property
    def size(self) -> int:
        return len(self._sessions)

    def pick(self) -> Optional[str]:
        if not self._sessions:
            return None
        with self._lock:
            now = time.time()
            live = [sid for sid in self._sessions if self._dead_until.get(sid, 0.0) < now]
            if not live:
                live = list(self._sessions)
            weights = []
            for sid in live:
                sr = self._success_rate.get(sid, 0.5)
                fails = self._fails.get(sid, 0)
                weights.append(max(0.05, sr) / (1.0 + fails))
            sid = random.choices(live, weights=weights, k=1)[0]
            self._total_calls[sid] = self._total_calls.get(sid, 0) + 1
            return sid

    def report_ok(self, sid: Optional[str]) -> None:
        if not sid:
            return
        with self._lock:
            self._fails.pop(sid, None)
            self._dead_until.pop(sid, None)
            self._total_ok[sid] = self._total_ok.get(sid, 0) + 1
            old = self._success_rate.get(sid, 0.5)
            self._success_rate[sid] = old * 0.85 + 0.15

    def report_fail(self, sid: Optional[str]) -> None:
        if not sid:
            return
        with self._lock:
            self._fails[sid] = self._fails.get(sid, 0) + 1
            old = self._success_rate.get(sid, 0.5)
            self._success_rate[sid] = old * 0.85
            if self._fails[sid] >= self._max_fails:
                self._dead_until[sid] = time.time() + self._recovery


def run_full(
    mode: str,
    text: str = "",
    subtitle_path: str = "",
    output_dir: str = "",
    output_name: str = "tts_output.wav",
    voice: str = "",
    speed: float = 1.0,
    pitch: bool = False,
    log: LogFn = None,
    progress: ProgressFn = None,
    session_ids: Optional[List[str]] = None,
    stage_progress: Optional[Callable[[str, int], None]] = None,
    cancel_event: Optional[threading.Event] = None,
    pause_event: Optional[threading.Event] = None,
) -> Tuple[bool, str]:
    def _cancelled() -> bool:
        return bool(cancel_event is not None and cancel_event.is_set())

    def _stage(name: str, v: int) -> None:
        if stage_progress:
            try:
                stage_progress(name, max(0, min(100, int(v))))
            except Exception:
                pass

    try:
        out_dir = Path(output_dir) if output_dir else Path(os.getcwd())
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / output_name
    except Exception:
        _log(log, "[-] Lỗi tạo thư mục xuất (raw):\n" + traceback.format_exc().strip())
        return (False, "")

    if _cancelled():
        _log(log, "[-] Đã hủy trước khi bắt đầu.")
        return (False, "")

    remote_sessions = list(session_ids or [])
    if not remote_sessions:
        remote_sessions = _load_remote_session_ids(log)
    key_pool = KeyPool(remote_sessions)
    if key_pool.input_count > 0 and key_pool.valid_count == 0:
        _log(
            log,
            "[-] Session ID không hợp lệ (chứa ký tự lạ hoặc sai định dạng). "
            "Hãy kiểm tra SessionID.Txt trên GitHub — mỗi dòng chỉ gồm chữ và số "
            "(ví dụ: a1b2c3d4e5f6...), không kèm 'sessionid=' hay dấu chấm phẩy.",
        )
        return (False, "")

    voice_id = TIKTOK_VOICE_MAP.get(voice, DEFAULT_VOICE) if voice else DEFAULT_VOICE

    if key_pool.size <= 0:
        _log(log, "[-] Không có Session ID hợp lệ; dừng để tránh fallback chậm.")
        return (False, "")

    if mode != "Phụ Đề":
        clean_text = text.strip()
        if not clean_text:
            _log(log, "[-] Văn bản trống.")
            return (False, "")
        _stage("tts", 0)
        _stage("mp3wav", 0)

        def _tts_cb(done: int, total: int) -> None:
            _stage("tts", int(done * 100 / max(1, total)))
            _progress(progress, int(done * 90 / max(1, total)))

        if _cancelled():
            _log(log, "[-] Đã hủy.")
            return (False, "")
        ok_turbo = turbo_text_to_wav(
            clean_text,
            list(key_pool._sessions),
            voice_id,
            out_path,
            concurrency=int(os.environ.get("INTRO_PRO_TTS_CONCURRENCY", "128")),
            rate_per_sec=float(os.environ.get("INTRO_PRO_TTS_RATE", "0")),
            speed=float(speed or 1.0),
            semitones=(float(DEFAULT_PITCH_SEMITONES) if pitch else 0.0),
            log=log,
            progress_cb=_tts_cb,
            stage_progress=stage_progress,
            cancel_event=cancel_event,
            pause_event=pause_event,
        )
        if not ok_turbo:
            _log(log, "[-] Turbo-TTS không tạo được audio; không chạy fallback tuần tự.")
            return (False, "")
        _stage("tts", 100)
        _stage("mp3wav", 100)
        _progress(progress, 100)
        return (True, str(out_path))

    try:
        items = parse_srt(Path(subtitle_path))
    except Exception:
        _log(log, "[-] Lỗi đọc file phụ đề (raw):\n" + traceback.format_exc().strip())
        return (False, "")
    if not items:
        _log(log, "[-] File phụ đề rỗng hoặc sai định dạng thời gian.")
        return (False, "")

    cues = [{"id": int(it["id"]), "ms": int(it["ms"]), "text": str(it["text"])}
            for it in items]

    def _report(sid: Optional[str], ok: bool) -> None:
        if ok:
            key_pool.report_ok(sid)
        else:
            key_pool.report_fail(sid)

    def _tts_cb(done_n: int, total_n: int) -> None:
        _stage("tts", int(done_n * 100 / max(1, total_n)))
        _progress(progress, int(done_n * 90 / max(1, total_n)))

    try:
        from Speech.audio_engines import srt_cues_to_wav
        semis = float(DEFAULT_PITCH_SEMITONES) if pitch else 0.0
        _stage("tts", 0)
        _stage("mp3wav", 0)
        srt_cues_to_wav(
            cues, out_path,
            pick_session=key_pool.pick, report_session=_report,
            voice=voice_id, speed=float(speed or 1.0), semitones=semis,
            concurrency=int(os.environ.get(
                "INTRO_PRO_SRT_TTS_WORKERS",
                os.environ.get("INTRO_PRO_TTS_CONCURRENCY", "128"))),
            rate_per_sec=float(os.environ.get("INTRO_PRO_TTS_RATE", "0")),
            log=log, stage_progress=stage_progress, progress_cb=_tts_cb,
            cancel_event=cancel_event, pause_event=pause_event,
        )
    except Exception:
        _log(log, "[-] Lỗi SRT pipeline (raw):\n" + traceback.format_exc().strip())
        return (False, "")
    _stage("tts", 100)
    _stage("mp3wav", 100)
    _progress(progress, 100)
    return (True, str(out_path))
