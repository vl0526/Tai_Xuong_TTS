from __future__ import annotations

"""Inworld TTS engine — MẠNG SIÊU ĐƠN GIẢN (chỉ phần TTS).

Thiết kế tối giản để đạt tốc độ cực hạn:
  build payload -> POST -> đọc NDJSON theo dòng -> gom base64 audio -> WAV.

KHÔNG đụng tới pipeline SRT-to-Speech của TikTok (tiktok_engine/audio_engines
giữ nguyên 100%). Chế độ Phụ Đề của Inworld chỉ TÁI SỬ DỤNG hạ tầng dùng chung
(parse_srt + _TimelineWriter) và gọi đúng cái network TTS đơn giản này cho từng
cue — nên không xung đột với đường TikTok.
"""

import base64
import json
import os
import threading
import time
import traceback
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, Dict, List, Optional, Tuple

from Speech import soundtouch as _st
from Speech.srt_parser import parse_srt
from Speech.audio_engines import _TimelineWriter, DEFAULT_PITCH_SEMITONES

LogFn = Optional[Callable[[str], None]]
ProgressFn = Optional[Callable[[int], None]]
StageFn = Optional[Callable[[str, int], None]]

# --------------------------------------------------------------------------- #
#  Cấu hình endpoint (đồng bộ với client Inworld gốc)
# --------------------------------------------------------------------------- #
ENDPOINT = "https://inworld.ai/api/create-speech"
UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36"
)
# Cookie tích hợp sẵn (từ request đã bắt được). Có thể override qua ENV
# INWORLD_COOKIE nếu phiên hết hạn — không cần sửa code.
_DEFAULT_COOKIE = (
    "inworld_uid=7d6f513c-01c7-43b4-9dc9-4ca14ed9de38; "
    "_twpid=tw.1780240910124.117949863277702110; "
    "cookieyes-consent=consentid:VVU5d1EyM3lxTExSZW5DZzJRZlBWRDdoSU94RDlaWU4,"
    "consent:yes,action:no,necessary:yes,functional:yes,analytics:yes,"
    "performance:yes,advertisement:yes,other:yes; "
    "_gcl_au=1.1.865860299.1780240910; "
    "hubspotutk=6b14cd0b2c054a2dcde4bf7c357881b6; "
    "_fbp=fb.1.1780240910637.765968840414347349; "
    "intercom-id-r85st5r0=78971d00-f719-4a55-8dc9-d33263b1fcd4; "
    "intercom-device-id-r85st5r0=cf5bd92a-f968-4b99-b775-fde7a35aefa4; "
    "__hstc=153436007.6b14cd0b2c054a2dcde4bf7c357881b6.1780240910594."
    "1782289134549.1782890889249.11; __hssrc=1; "
    "_rdt_uuid=1780240910041.859c2a96-22f5-453d-8c25-093d2bfbcb3e; "
    "__hssc=153436007.2.1782890889249; "
    "_uetsid=67b66580751e11f1bc3a210a281cbe1e; "
    "_uetvid=775dce905d0411f1a3741b27c4d61558"
)

MODEL_ID = "inworld-tts-2"
DELIVERY_MODE = "CREATIVE"
AUDIO_ENCODING = "LINEAR16"     # PCM 16-bit -> wrap thẳng thành WAV, không cần decode
SAMPLE_RATE = 48000
AUDIO_KEYS = ("audioContent", "audio", "audioData", "chunk", "audioChunk")

# --------------------------------------------------------------------------- #
#  Danh sách giọng chính thức của Inworld TTS
# --------------------------------------------------------------------------- #
VOICES: List[Dict[str, str]] = [
    {"voiceId": "Abby", "displayName": "Abby", "language": "English", "langCode": "EN"},
    {"voiceId": "Alain", "displayName": "Alain", "language": "French", "langCode": "FR"},
    {"voiceId": "Alex", "displayName": "Alex", "language": "English", "langCode": "EN"},
    {"voiceId": "Amina", "displayName": "Amina", "language": "English", "langCode": "EN"},
    {"voiceId": "Anjali", "displayName": "Anjali", "language": "English", "langCode": "EN"},
    {"voiceId": "Arjun", "displayName": "Arjun", "language": "English", "langCode": "EN"},
    {"voiceId": "Ashley", "displayName": "Ashley", "language": "English", "langCode": "EN"},
    {"voiceId": "Asuka", "displayName": "Asuka", "language": "Japanese", "langCode": "JA"},
    {"voiceId": "Blake", "displayName": "Blake", "language": "English", "langCode": "EN"},
    {"voiceId": "Brian", "displayName": "Brian", "language": "English", "langCode": "EN"},
    {"voiceId": "Callum", "displayName": "Callum", "language": "English", "langCode": "EN"},
    {"voiceId": "Carter", "displayName": "Carter", "language": "English", "langCode": "EN"},
    {"voiceId": "Celeste", "displayName": "Celeste", "language": "English", "langCode": "EN"},
    {"voiceId": "Chloe", "displayName": "Chloe", "language": "English", "langCode": "EN"},
    {"voiceId": "Claire", "displayName": "Claire", "language": "English", "langCode": "EN"},
    {"voiceId": "Clive", "displayName": "Clive", "language": "English", "langCode": "EN"},
    {"voiceId": "Craig", "displayName": "Craig", "language": "English", "langCode": "EN"},
    {"voiceId": "Darlene", "displayName": "Darlene", "language": "English", "langCode": "EN"},
    {"voiceId": "Deborah", "displayName": "Deborah", "language": "English", "langCode": "EN"},
    {"voiceId": "Dennis", "displayName": "Dennis", "language": "English", "langCode": "EN"},
    {"voiceId": "Derek", "displayName": "Derek", "language": "English", "langCode": "EN"},
    {"voiceId": "Diego", "displayName": "Diego", "language": "Spanish", "langCode": "ES"},
    {"voiceId": "Dmitry", "displayName": "Dmitry", "language": "Russian", "langCode": "RU"},
    {"voiceId": "Dominus", "displayName": "Dominus", "language": "English", "langCode": "EN"},
    {"voiceId": "Edward", "displayName": "Edward", "language": "English", "langCode": "EN"},
    {"voiceId": "Elena", "displayName": "Elena", "language": "Russian", "langCode": "RU"},
    {"voiceId": "Elizabeth", "displayName": "Elizabeth", "language": "English", "langCode": "EN"},
    {"voiceId": "Elliot", "displayName": "Elliot", "language": "English", "langCode": "EN"},
    {"voiceId": "Erik", "displayName": "Erik", "language": "Dutch", "langCode": "NL"},
    {"voiceId": "Ethan", "displayName": "Ethan", "language": "English", "langCode": "EN"},
    {"voiceId": "Evan", "displayName": "Evan", "language": "English", "langCode": "EN"},
    {"voiceId": "Evelyn", "displayName": "Evelyn", "language": "English", "langCode": "EN"},
    {"voiceId": "Gareth", "displayName": "Gareth", "language": "English", "langCode": "EN"},
    {"voiceId": "Gianni", "displayName": "Gianni", "language": "Italian", "langCode": "IT"},
    {"voiceId": "Graham", "displayName": "Graham", "language": "English", "langCode": "EN"},
    {"voiceId": "Grant", "displayName": "Grant", "language": "English", "langCode": "EN"},
    {"voiceId": "Hades", "displayName": "Hades", "language": "English", "langCode": "EN"},
    {"voiceId": "Hamish", "displayName": "Hamish", "language": "English", "langCode": "EN"},
    {"voiceId": "Hana", "displayName": "Hana", "language": "English", "langCode": "EN"},
    {"voiceId": "Hank", "displayName": "Hank", "language": "English", "langCode": "EN"},
    {"voiceId": "Heitor", "displayName": "Heitor", "language": "Portuguese", "langCode": "PT"},
    {"voiceId": "Hyunwoo", "displayName": "Hyunwoo", "language": "Korean", "langCode": "KO"},
    {"voiceId": "H\u00e9l\u00e8ne", "displayName": "H\u00e9l\u00e8ne", "language": "French", "langCode": "FR"},
    {"voiceId": "Jake", "displayName": "Jake", "language": "English", "langCode": "EN"},
    {"voiceId": "James", "displayName": "James", "language": "English", "langCode": "EN"},
    {"voiceId": "Jason", "displayName": "Jason", "language": "English", "langCode": "EN"},
    {"voiceId": "Jessica", "displayName": "Jessica", "language": "English", "langCode": "EN"},
    {"voiceId": "Jing", "displayName": "Jing", "language": "Chinese", "langCode": "ZH"},
    {"voiceId": "Johanna", "displayName": "Johanna", "language": "German", "langCode": "DE"},
    {"voiceId": "Josef", "displayName": "Josef", "language": "German", "langCode": "DE"},
    {"voiceId": "Julia", "displayName": "Julia", "language": "English", "langCode": "EN"},
    {"voiceId": "Katrien", "displayName": "Katrien", "language": "Dutch", "langCode": "NL"},
    {"voiceId": "Kayla", "displayName": "Kayla", "language": "English", "langCode": "EN"},
    {"voiceId": "Kelsey", "displayName": "Kelsey", "language": "English", "langCode": "EN"},
    {"voiceId": "Lauren", "displayName": "Lauren", "language": "English", "langCode": "EN"},
    {"voiceId": "Lennart", "displayName": "Lennart", "language": "Dutch", "langCode": "NL"},
    {"voiceId": "Liam", "displayName": "Liam", "language": "English", "langCode": "EN"},
    {"voiceId": "Lore", "displayName": "Lore", "language": "Dutch", "langCode": "NL"},
    {"voiceId": "Loretta", "displayName": "Loretta", "language": "English", "langCode": "EN"},
    {"voiceId": "Luna", "displayName": "Luna", "language": "English", "langCode": "EN"},
    {"voiceId": "Lupita", "displayName": "Lupita", "language": "Spanish", "langCode": "ES"},
    {"voiceId": "Mait\u00ea", "displayName": "Mait\u00ea", "language": "Portuguese", "langCode": "PT"},
    {"voiceId": "Malcolm", "displayName": "Malcolm", "language": "English", "langCode": "EN"},
    {"voiceId": "Manoj", "displayName": "Manoj", "language": "Hindi", "langCode": "HI"},
    {"voiceId": "Mark", "displayName": "Mark", "language": "English", "langCode": "EN"},
    {"voiceId": "Marlene", "displayName": "Marlene", "language": "English", "langCode": "EN"},
    {"voiceId": "Mathieu", "displayName": "Mathieu", "language": "French", "langCode": "FR"},
    {"voiceId": "Miguel", "displayName": "Miguel", "language": "Spanish", "langCode": "ES"},
    {"voiceId": "Minji", "displayName": "Minji", "language": "Korean", "langCode": "KO"},
    {"voiceId": "Miranda", "displayName": "Miranda", "language": "English", "langCode": "EN"},
    {"voiceId": "Mortimer", "displayName": "Mortimer", "language": "English", "langCode": "EN"},
    {"voiceId": "Nate", "displayName": "Nate", "language": "English", "langCode": "EN"},
    {"voiceId": "Nikolai", "displayName": "Nikolai", "language": "Russian", "langCode": "RU"},
    {"voiceId": "Nour", "displayName": "Nour", "language": "Arabic", "langCode": "AR"},
    {"voiceId": "Oliver", "displayName": "Oliver", "language": "English", "langCode": "EN"},
    {"voiceId": "Olivia", "displayName": "Olivia", "language": "English", "langCode": "EN"},
    {"voiceId": "Omar", "displayName": "Omar", "language": "Arabic", "langCode": "AR"},
    {"voiceId": "Oren", "displayName": "Oren", "language": "Hebrew", "langCode": "HE"},
    {"voiceId": "Orietta", "displayName": "Orietta", "language": "Italian", "langCode": "IT"},
    {"voiceId": "Pippa", "displayName": "Pippa", "language": "English", "langCode": "EN"},
    {"voiceId": "Pixie", "displayName": "Pixie", "language": "English", "langCode": "EN"},
    {"voiceId": "Priya", "displayName": "Priya", "language": "English", "langCode": "EN"},
    {"voiceId": "Rafael", "displayName": "Rafael", "language": "Spanish", "langCode": "ES"},
    {"voiceId": "Riya", "displayName": "Riya", "language": "Hindi", "langCode": "HI"},
    {"voiceId": "Ronald", "displayName": "Ronald", "language": "English", "langCode": "EN"},
    {"voiceId": "Rupert", "displayName": "Rupert", "language": "English", "langCode": "EN"},
    {"voiceId": "Saanvi", "displayName": "Saanvi", "language": "English", "langCode": "EN"},
    {"voiceId": "Sarah", "displayName": "Sarah", "language": "English", "langCode": "EN"},
    {"voiceId": "Satoshi", "displayName": "Satoshi", "language": "Japanese", "langCode": "JA"},
    {"voiceId": "Sebastian", "displayName": "Sebastian", "language": "English", "langCode": "EN"},
    {"voiceId": "Seojun", "displayName": "Seojun", "language": "Korean", "langCode": "KO"},
    {"voiceId": "Serena", "displayName": "Serena", "language": "English", "langCode": "EN"},
    {"voiceId": "Shaun", "displayName": "Shaun", "language": "English", "langCode": "EN"},
    {"voiceId": "Simon", "displayName": "Simon", "language": "English", "langCode": "EN"},
    {"voiceId": "Snik", "displayName": "Snik", "language": "English", "langCode": "EN"},
    {"voiceId": "Svetlana", "displayName": "Svetlana", "language": "Russian", "langCode": "RU"},
    {"voiceId": "Szymon", "displayName": "Szymon", "language": "Polish", "langCode": "PL"},
    {"voiceId": "Tessa", "displayName": "Tessa", "language": "English", "langCode": "EN"},
    {"voiceId": "Theodore", "displayName": "Theodore", "language": "English", "langCode": "EN"},
    {"voiceId": "Timothy", "displayName": "Timothy", "language": "English", "langCode": "EN"},
    {"voiceId": "Tyler", "displayName": "Tyler", "language": "English", "langCode": "EN"},
    {"voiceId": "Veronica", "displayName": "Veronica", "language": "English", "langCode": "EN"},
    {"voiceId": "Victor", "displayName": "Victor", "language": "English", "langCode": "EN"},
    {"voiceId": "Victoria", "displayName": "Victoria", "language": "English", "langCode": "EN"},
    {"voiceId": "Vinny", "displayName": "Vinny", "language": "English", "langCode": "EN"},
    {"voiceId": "Wendy", "displayName": "Wendy", "language": "English", "langCode": "EN"},
    {"voiceId": "Wojciech", "displayName": "Wojciech", "language": "Polish", "langCode": "PL"},
    {"voiceId": "Xiaoyin", "displayName": "Xiaoyin", "language": "Chinese", "langCode": "ZH"},
    {"voiceId": "Xinyi", "displayName": "Xinyi", "language": "Chinese", "langCode": "ZH"},
    {"voiceId": "Yael", "displayName": "Yael", "language": "Hebrew", "langCode": "HE"},
    {"voiceId": "Yichen", "displayName": "Yichen", "language": "Chinese", "langCode": "ZH"},
    {"voiceId": "Yoona", "displayName": "Yoona", "language": "Korean", "langCode": "KO"},
    {"voiceId": "\u00c9tienne", "displayName": "\u00c9tienne", "language": "French", "langCode": "FR"},
]

# Nhãn hiển thị trong combo: "Ten \u00b7 Ngon ngu". Map ngược nhãn -> voiceId.
INWORLD_VOICE_LABELS: List[str] = [f"{v['displayName']} \u00b7 {v['language']}" for v in VOICES]
INWORLD_LABEL_TO_ID: Dict[str, str] = {
    lbl: v["voiceId"] for lbl, v in zip(INWORLD_VOICE_LABELS, VOICES)
}
_NAME_TO_ID: Dict[str, str] = {v["displayName"]: v["voiceId"] for v in VOICES}

DEFAULT_INWORLD_VOICE = "Sarah"
DEFAULT_INWORLD_LABEL = next(
    (lbl for lbl, v in zip(INWORLD_VOICE_LABELS, VOICES) if v["voiceId"] == DEFAULT_INWORLD_VOICE),
    INWORLD_VOICE_LABELS[0],
)


def resolve_voice(voice: str) -> str:
    """Nhận nhãn combo ('Sarah \u00b7 English') HOẶC voiceId thô -> trả voiceId."""
    if not voice:
        return DEFAULT_INWORLD_VOICE
    if voice in INWORLD_LABEL_TO_ID:
        return INWORLD_LABEL_TO_ID[voice]
    if voice in _NAME_TO_ID:
        return _NAME_TO_ID[voice]
    return DEFAULT_INWORLD_VOICE


def _log(fn: LogFn, msg: str) -> None:
    if fn:
        fn(msg)


def _stage(fn: StageFn, name: str, v: int) -> None:
    if fn:
        try:
            fn(name, max(0, min(100, int(v))))
        except Exception:
            pass


# --------------------------------------------------------------------------- #
#  Network TTS — ĐƠN GIẢN TỐI ĐA
# --------------------------------------------------------------------------- #
def _cookie() -> str:
    return str(os.environ.get("INWORLD_COOKIE", "") or "").strip() or _DEFAULT_COOKIE


def _headers() -> Dict[str, str]:
    return {
        "Content-Type": "application/json",
        "Origin": "https://inworld.ai",
        "Referer": "https://inworld.ai/tts",
        "User-Agent": UA,
        "Cookie": _cookie(),
    }


def _extract_audio(obj: Any) -> bytes:
    """Gom mọi base64 audio trong một object NDJSON đã giải mã (không raise)."""
    out = bytearray()

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            for key, val in node.items():
                if key in AUDIO_KEYS and isinstance(val, str) and len(val) > 16:
                    try:
                        out.extend(base64.b64decode(val))
                    except Exception:
                        pass
                else:
                    walk(val)
        elif isinstance(node, list):
            for item in node:
                walk(item)

    walk(obj)
    return bytes(out)


def _parse_line(line: bytes) -> bytes:
    try:
        return _extract_audio(json.loads(line))
    except Exception:
        return b""


def _synthesize_once(text: str, voice_id: str,
                     cancel_event: Optional[threading.Event]) -> bytes:
    """1 request -> PCM 16-bit thô. Đọc NDJSON theo dòng, tự tách '\\n' nên không
    dính lỗi 'chunk quá lớn' khi 1 dòng base64 audio rất dài."""
    payload = {
        "text": text,
        "voiceId": voice_id,
        "modelId": MODEL_ID,
        "deliveryMode": DELIVERY_MODE,
        "audioConfig": {"audioEncoding": AUDIO_ENCODING, "sampleRateHertz": SAMPLE_RATE},
    }
    data = json.dumps(payload).encode("utf-8")
    req = Request(ENDPOINT, data=data, headers=_headers(), method="POST")
    audio = bytearray()
    buf = bytearray()
    with urlopen(req, timeout=300) as resp:
        while True:
            if cancel_event is not None and cancel_event.is_set():
                break
            chunk = resp.read(1 << 16)
            if not chunk:
                break
            buf.extend(chunk)
            nl = buf.find(b"\n")
            while nl >= 0:
                line = bytes(buf[:nl]).strip()
                del buf[: nl + 1]
                if line:
                    audio.extend(_parse_line(line))
                nl = buf.find(b"\n")
        tail = bytes(buf).strip()
        if tail:
            audio.extend(_parse_line(tail))
    return bytes(audio)


def _synthesize(text: str, voice_id: str,
                cancel_event: Optional[threading.Event],
                log: LogFn = None, tries: int = 3) -> bytes:
    """Gọi _synthesize_once với retry nhẹ (Inworld giới hạn ~20 req/phiên)."""
    last = ""
    for attempt in range(1, max(1, tries) + 1):
        if cancel_event is not None and cancel_event.is_set():
            return b""
        try:
            pcm = _synthesize_once(text, voice_id, cancel_event)
            if pcm:
                return pcm
            last = "empty audio"
        except HTTPError as exc:
            body = ""
            try:
                body = exc.read(400).decode("utf-8", errors="ignore")
            except Exception:
                pass
            last = f"HTTP {exc.code}: {body}".strip()
            if exc.code == 429 and attempt < tries:
                time.sleep(1.5 * attempt)
                continue
        except URLError as exc:
            last = f"network: {exc.reason}"
        except Exception as exc:
            last = str(exc)
        if attempt < tries:
            time.sleep(0.4 * attempt)
    if last:
        _log(log, f"[-] Inworld TTS lỗi: {last}")
    return b""


def _pcm_to_wav(audio: bytes) -> bytes:
    if len(audio) >= 4 and audio[:4] == b"RIFF":
        return audio
    return _st.pcm16_to_wav(audio, 1, SAMPLE_RATE)


def _apply_fx(wav: bytes, speed: float, pitch: bool) -> bytes:
    semis = float(DEFAULT_PITCH_SEMITONES) if pitch else 0.0
    spd = float(speed or 1.0)
    if abs(spd - 1.0) >= 1e-4 or abs(semis) >= 1e-4:
        wav = _st.process_wav_buffer(wav, {"speed": spd, "semitones": semis})
    return wav


# --------------------------------------------------------------------------- #
#  run_full — cùng chữ ký với tiktok_engine.run_full để wiring đối xứng
# --------------------------------------------------------------------------- #
def run_full(
    mode: str,
    text: str = "",
    subtitle_path: str = "",
    output_dir: str = "",
    output_name: str = "tts_output.wav",
    voice: str = "",
    speed: float = 1.0,
    pitch: bool = False,
    log: LogFn = None,
    progress: ProgressFn = None,
    session_ids: Optional[List[str]] = None,  # không dùng (Inworld dùng cookie)
    stage_progress: StageFn = None,
    cancel_event: Optional[threading.Event] = None,
    pause_event: Optional[threading.Event] = None,
) -> Tuple[bool, str]:
    def _cancelled() -> bool:
        return bool(cancel_event is not None and cancel_event.is_set())

    try:
        out_dir = Path(output_dir) if output_dir else Path(os.getcwd())
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / output_name
    except Exception:
        _log(log, "[-] Lỗi tạo thư mục xuất (raw):\n" + traceback.format_exc().strip())
        return (False, "")

    if _cancelled():
        _log(log, "[-] Đã hủy trước khi bắt đầu.")
        return (False, "")

    voice_id = resolve_voice(voice)

    # ---- Văn bản: 1 request, wrap WAV, pitch/speed 1 lần ---- #
    if mode != "Phụ Đề":
        clean = (text or "").strip()
        if not clean:
            _log(log, "[-] Văn bản trống.")
            return (False, "")
        _stage(stage_progress, "tts", 5)
        _log(log, f"[+] Inworld TTS · giọng {voice_id}...")
        pcm = _synthesize(clean, voice_id, cancel_event, log=log)
        if _cancelled():
            _log(log, "[-] Đã hủy.")
            return (False, "")
        if not pcm:
            return (False, "")
        _stage(stage_progress, "tts", 100)
        _stage(stage_progress, "mp3wav", 10)
        try:
            wav = _apply_fx(_pcm_to_wav(pcm), speed, pitch)
            out_path.write_bytes(wav)
        except Exception:
            _log(log, "[-] Lỗi ghi/xử lý audio (raw):\n" + traceback.format_exc().strip())
            return (False, "")
        _stage(stage_progress, "mp3wav", 100)
        return (True, str(out_path))

    # ---- Phụ Đề: tái sử dụng parse_srt + _TimelineWriter (KHÔNG đụng TikTok) ---- #
    try:
        cues = parse_srt(Path(subtitle_path))
    except Exception:
        _log(log, "[-] Lỗi đọc file phụ đề (raw):\n" + traceback.format_exc().strip())
        return (False, "")
    if not cues:
        _log(log, "[-] File phụ đề rỗng hoặc sai định dạng thời gian.")
        return (False, "")

    total = len(cues)
    writer = _TimelineWriter(out_path)
    _stage(stage_progress, "tts", 0)
    _stage(stage_progress, "mp3wav", 0)

    state = {"done": 0, "ok": True}
    lock = threading.Lock()
    workers = max(1, int(os.environ.get("INWORLD_TTS_WORKERS", "6")))

    def _one(cue: Dict[str, Any]) -> None:
        if _cancelled() or not state["ok"]:
            return
        pcm = _synthesize(str(cue["text"]), voice_id, cancel_event, log=log)
        if _cancelled():
            return
        if not pcm:
            with lock:
                state["ok"] = False
            return
        try:
            wav = _apply_fx(_pcm_to_wav(pcm), speed, pitch)
            writer.write(int(cue["ms"]), wav)
        except Exception:
            _log(log, "[-] Lỗi ghi cue (raw):\n" + traceback.format_exc().strip())
            with lock:
                state["ok"] = False
            return
        with lock:
            state["done"] += 1
            d = state["done"]
        _stage(stage_progress, "tts", int(d * 100 / max(1, total)))
        if progress:
            progress(int(d * 90 / max(1, total)))

    try:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            list(ex.map(_one, cues))
    except Exception:
        _log(log, "[-] Lỗi Inworld SRT pipeline (raw):\n" + traceback.format_exc().strip())
        return (False, "")

    if _cancelled():
        _log(log, "[-] Đã hủy.")
        return (False, "")
    if not state["ok"]:
        return (False, "")

    try:
        writer.finalize()
    except Exception:
        _log(log, "[-] Lỗi ghép timeline (raw):\n" + traceback.format_exc().strip())
        return (False, "")

    _stage(stage_progress, "tts", 100)
    _stage(stage_progress, "mp3wav", 100)
    if progress:
        progress(100)
    return (True, str(out_path))
