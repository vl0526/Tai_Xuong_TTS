"""Native SoundTouch binding (BAT BUOC cho pitch/speed).

Khong con fallback pure-Python: neu DLL thieu/hong se raise loi ro rang."""
from __future__ import annotations

import ctypes
import ctypes.util
import os
import sys
import threading
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_LIB = None
_LIB_LOCK = threading.Lock()


def _is_64bit() -> bool:
    return ctypes.sizeof(ctypes.c_void_p) == 8


def _dll_names() -> list[str]:
    if sys.platform.startswith("win"):
        # Official Windows build ships per-bitness DLLs. The canonical name is
        # SoundTouchDLL.dll; the SDK also keeps an explicit _x64 copy. List the
        # name matching the running interpreter's bitness FIRST so a 64-bit
        # process never tries to load the 32-bit DLL (which raises WinError 193).
        if _is_64bit():
            return ["SoundTouchDLL.dll", "SoundTouchDLL_x64.dll",
                    "SoundTouch.dll", "libSoundTouch.dll"]
        return ["SoundTouchDLL.dll", "SoundTouchDLL_x86.dll",
                "SoundTouch.dll", "libSoundTouch.dll"]
    if sys.platform == "darwin":
        return ["libSoundTouchDll.dylib", "libSoundTouch.dylib", "SoundTouch.dylib"]
    # Linux: the C-API wrapper is libSoundTouchDll.so (note the "Dll" part).
    # The C++ class library libSoundTouch.so does NOT export the C entrypoints
    # we need, so list the Dll variant first.
    return ["libSoundTouchDll.so", "libSoundTouchDll.so.1",
            "libSoundTouch.so.1", "libSoundTouch.so"]


def _candidate_paths() -> list[Path]:
    dirs = [_HERE / "native", _HERE]
    return [d / n for d in dirs for n in _dll_names()]


def _open_cdll() -> ctypes.CDLL:
    override = os.environ.get("SOUNDTOUCH_LIB", "").strip()
    paths = [Path(override)] if override else _candidate_paths()
    if sys.platform.startswith("win"):
        for d in {p.parent for p in paths}:
            try:
                if d.exists():
                    os.add_dll_directory(str(d))
            except Exception:
                pass
    errors: list[str] = []
    for p in paths:
        if p.exists():
            try:
                return ctypes.CDLL(str(p))
            except OSError as exc:
                # Wrong bitness / missing dependency: skip and keep probing the
                # remaining candidates instead of aborting on the first hit.
                errors.append(f"{p.name}: {exc}")
                continue
    found = ctypes.util.find_library("SoundTouch") or ctypes.util.find_library("soundtouch")
    if found:
        return ctypes.CDLL(found)
    detail = (" Đã thử: " + "; ".join(errors)) if errors else ""
    raise RuntimeError("Không tìm thấy SoundTouch native library." + detail)


def _bind(lib: ctypes.CDLL) -> ctypes.CDLL:
    """Bind SoundTouch C-API.

    The official SoundTouch DLL exports C-entrypoints with a ``soundtouch_``
    prefix on every platform (Windows ``SoundTouchDLL.dll`` and Linux
    ``libSoundTouchDll.so``). Some older/custom Windows builds were reported
    to export the same names without the prefix, so we probe both shapes and
    pick whichever exists. If neither is found we raise a clear error.
    """
    c_void_p = ctypes.c_void_p
    c_uint = ctypes.c_uint
    c_float = ctypes.c_float
    P = ctypes.POINTER

    base_names = ("createInstance", "destroyInstance", "setSampleRate",
                  "setChannels", "setTempo", "setPitch", "putSamples",
                  "receiveSamples", "flush", "isEmpty")

    has_prefixed = all(hasattr(lib, "soundtouch_" + n) for n in base_names)
    has_bare = all(hasattr(lib, n) for n in base_names)
    if not (has_prefixed or has_bare):
        missing = [n for n in base_names
                   if not (hasattr(lib, "soundtouch_" + n) or hasattr(lib, n))]
        raise RuntimeError(
            "SoundTouch ABI thiếu symbol(s): " + ", ".join(missing) +
            f" (đã tìm trong {lib!r})"
        )
    prefix = "soundtouch_" if has_prefixed else ""

    def f(name: str):
        return getattr(lib, prefix + name)

    f("createInstance").restype = c_void_p
    f("destroyInstance").argtypes = [c_void_p]
    f("setSampleRate").argtypes = [c_void_p, c_uint]
    f("setChannels").argtypes = [c_void_p, c_uint]
    f("setTempo").argtypes = [c_void_p, c_float]
    f("setPitch").argtypes = [c_void_p, c_float]
    f("putSamples").argtypes = [c_void_p, P(c_float), c_uint]
    f("receiveSamples").argtypes = [c_void_p, P(c_float), c_uint]
    f("receiveSamples").restype = ctypes.c_int
    f("flush").argtypes = [c_void_p]
    f("isEmpty").argtypes = [c_void_p]
    f("isEmpty").restype = ctypes.c_bool

    # setSetting la TUY CHON: mot vai build DLL khong export. Bind neu co de ghim
    # cung tham so chat luong ve dung thuat toan goc SoundTouch (chong tieng re
    # do build la khac gia tri mac dinh).
    _set = getattr(lib, prefix + "setSetting", None) or getattr(lib, "setSetting", None)
    if _set is not None:
        try:
            _set.argtypes = [c_void_p, ctypes.c_int, ctypes.c_int]
            _set.restype = ctypes.c_int
            lib.setSetting = _set
            lib.soundtouch_setSetting = _set
        except Exception:
            pass

    # Expose both prefixed and bare aliases on the lib object so callers
    # (and process_pcm_native below) can call lib.createInstance(...) either way.
    for n in base_names:
        bound = f(n)
        setattr(lib, n, bound)
        setattr(lib, "soundtouch_" + n, bound)
    return lib


def _lib() -> ctypes.CDLL:
    global _LIB
    if _LIB is None:
        with _LIB_LOCK:
            if _LIB is None:
                _LIB = _bind(_open_cdll())
    return _LIB


class NativeSoundTouchStream:
    """STREAMING wrapper quanh MOT instance SoundTouch native song.

    Cho phep NAP (putSamples) tung mieng PCM theo THU TU roi LAY
    (receiveSamples) ket qua NGAY, thay vi xu ly nguyen khoi 1 lan o cuoi. Vi
    SoundTouch la bo xu ly STREAM (giu day du lich su noi bo), nap tang dan ==
    nap 1 lan tren toan bo tin hieu -> KET QUA GIONG HET (1:1) nhung duoc
    CHONG LEN thoi gian mang -> het 'duoi noi tiep' cham o che do Van ban.

    Dung Y HET cac ctypes call + setting nhu process_pcm_native, chi khac:
    KHONG flush giua cac mieng, chi flush 1 lan o cuoi.
    """

    def __init__(self, channels: int, sample_rate: int, tempo: float, pitch: float):
        import numpy as np
        self._np = np
        self._ch = max(1, int(channels))
        lib = _lib()
        self._lib = lib
        h = lib.createInstance()
        if not h:
            raise RuntimeError("SoundTouch createInstance failed")
        self._h = h
        lib.setSampleRate(h, int(sample_rate))
        lib.setChannels(h, int(channels))
        # Ghim dung thuat toan goc SoundTouch (giong process_pcm_native):
        # BAT anti-alias filter, FIR=64, TAT quick-seek (chat luong cao nhat).
        _set = getattr(lib, "setSetting", None)
        if _set is not None:
            try:
                _set(h, 0, 1)   # use AA filter = ON
                _set(h, 1, 64)  # AA filter length = 64
                _set(h, 2, 0)   # quick-seek = OFF
            except Exception:
                pass
        lib.setTempo(h, float(tempo))
        lib.setPitch(h, float(pitch))
        self._buf = (ctypes.c_float * (65536 * self._ch))()

    def _receive_ready(self):
        np = self._np
        chunks = []
        while True:
            n = int(self._lib.receiveSamples(self._h, self._buf, 65536))
            if n <= 0:
                break
            chunks.append(np.ctypeslib.as_array(self._buf, shape=(n * self._ch,)).copy())
        return chunks

    def _pcm16(self, chunks) -> bytes:
        np = self._np
        if not chunks:
            return b""
        out = np.concatenate(chunks)
        return np.clip(out * 32768.0, -32768, 32767).astype("<i2").tobytes()

    def feed_pcm16(self, pcm: bytes) -> bytes:
        """Nap 1 mieng PCM 16-bit LE (dung thu tu) -> tra ve PCM da xu ly san sang."""
        if not pcm or self._h is None:
            return b""
        np = self._np
        samples = np.frombuffer(pcm, dtype="<i2").astype(np.float32) / 32768.0
        if samples.size == 0:
            return b""
        self._lib.putSamples(
            self._h, samples.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
            int(samples.size // self._ch),
        )
        return self._pcm16(self._receive_ready())

    def flush_pcm16(self) -> bytes:
        """Flush duoi + tra ve PCM con lai, roi HUY instance. Goi 1 lan o cuoi."""
        if self._h is None:
            return b""
        try:
            self._lib.flush(self._h)
            return self._pcm16(self._receive_ready())
        finally:
            try:
                self._lib.destroyInstance(self._h)
            finally:
                self._h = None

    def close(self) -> None:
        if self._h is not None:
            try:
                self._lib.destroyInstance(self._h)
            finally:
                self._h = None


def process_pcm_native(pcm: bytes, channels: int, sample_rate: int, tempo: float, pitch: float) -> bytes:
    import numpy as np
    lib = _lib()
    h = lib.createInstance()
    if not h:
        raise RuntimeError("SoundTouch createInstance failed")
    try:
        lib.setSampleRate(h, int(sample_rate))
        lib.setChannels(h, int(channels))
        # Ghim dung thuat toan goc SoundTouch: BAT anti-alias filter (chong tieng
        # re khi doi cao do) va TAT quick-seek (chat luong time-stretch cao nhat).
        # SETTING_USE_AA_FILTER=0, SETTING_AA_FILTER_LENGTH=1, SETTING_USE_QUICKSEEK=2.
        _set = getattr(lib, "setSetting", None)
        if _set is not None:
            try:
                _set(h, 0, 1)   # use AA filter = ON
                _set(h, 1, 64)  # AA filter length = 64 (mac dinh chuan)
                _set(h, 2, 0)   # quick-seek = OFF
            except Exception:
                pass
        lib.setTempo(h, float(tempo))
        lib.setPitch(h, float(pitch))
        samples = np.frombuffer(pcm, dtype="<i2").astype(np.float32) / 32768.0
        if samples.size == 0:
            return b""
        lib.putSamples(h, samples.ctypes.data_as(ctypes.POINTER(ctypes.c_float)), int(samples.size // max(1, channels)))
        lib.flush(h)
        out_chunks = []
        buf = (ctypes.c_float * (65536 * max(1, channels)))()
        idle = 0
        while idle < 3:
            n = int(lib.receiveSamples(h, buf, 65536))
            if n <= 0:
                idle += 1
                if lib.isEmpty(h):
                    break
                continue
            idle = 0
            out_chunks.append(np.ctypeslib.as_array(buf, shape=(n * max(1, channels),)).copy())
        if not out_chunks:
            return b""
        out = np.concatenate(out_chunks)
        return np.clip(out * 32768.0, -32768, 32767).astype("<i2").tobytes()
    finally:
        lib.destroyInstance(h)
