"""Panel Admin Tối Cao — TINH GỌN nhưng cao cấp.

Mở: gõ ';panel' vào ô nhập Text-to-Speech rồi bấm Ctrl+Enter.

Chỉ 3 điều khiển chính:
  1. Nút cần gạt "CỰC HẠN"  -> bật/tắt cấu hình tốc độ cực hạn cho engine.
  2. "TỰ ĐỘNG TỐI ƯU MẠNG" -> flush DNS + đo & chọn host nhanh nhất (+ tuỳ chọn
     đổi DNS nhanh / tinh chỉnh TCP trên Windows, đảo ngược được).
  3. "TỰ ĐỘNG TEST & CHỌN CẤU HÌNH CAO NHẤT" -> đo số session + latency thực rồi
     chọn cấu hình cao nhất khả thi.
Kèm nút "KHÔI PHỤC MẠNG" để trả mạng về mặc định.

Giao diện dùng lại painter kim loại 3D của app (paint_metal_panel, KHÔNG blur).
"""
from __future__ import annotations

import os

from PyQt6.QtCore import (
    Qt, QThread, pyqtSignal, pyqtProperty, QPropertyAnimation,
)
from PyQt6.QtGui import QColor, QFont, QPainter
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel

from App.widgets import PushButton, IconButton, LogView
from App.liquid_glass import paint_metal_panel
from App.theme import accent_color
from App.core import _SVG_CLOSE, _SVG_BOLT, _SVG_SETTINGS, play_droplet
from App import net_optimize as NET

# Cấu hình env cho 2 trạng thái của nút cần gạt.
_EXTREME = {"INTRO_PRO_TTS_PER_SESSION": 64, "INTRO_PRO_TTS_PER_SESSION_START": 64,
            "INTRO_PRO_TTS_CONCURRENCY": 256, "INTRO_PRO_TTS_HEDGE_MS": 250}
_BALANCED = {"INTRO_PRO_TTS_PER_SESSION": 32, "INTRO_PRO_TTS_PER_SESSION_START": 32,
             "INTRO_PRO_TTS_CONCURRENCY": 64, "INTRO_PRO_TTS_HEDGE_MS": 400}


def _label(text: str, size: int = 12, dim: bool = False) -> QLabel:
    lb = QLabel(text)
    lb.setFont(QFont("Rosemary", size, QFont.Weight.Black))
    lb.setStyleSheet("color:%s; letter-spacing:1px; border:none;"
                     % ("rgba(255,255,255,0.58)" if dim else "#FFFFFF"))
    return lb


class ToggleSwitch(QWidget):
    """Nút cần gạt kim loại, có hiệu ứng trượt (No Blur)."""
    toggled = pyqtSignal(bool)

    def __init__(self, parent=None, on: bool = False):
        super().__init__(parent)
        self._on = bool(on)
        self._p = 1.0 if on else 0.0
        self.setFixedSize(66, 32)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._anim = QPropertyAnimation(self, b"p_val", self)
        self._anim.setDuration(150)

    def isChecked(self) -> bool:
        return self._on

    def setChecked(self, v: bool):
        v = bool(v)
        if v == self._on:
            return
        self._on = v
        self._anim.stop()
        self._anim.setStartValue(self._p)
        self._anim.setEndValue(1.0 if v else 0.0)
        self._anim.start()
        self.toggled.emit(v)

    def mousePressEvent(self, e):
        self.setChecked(not self._on)

    def _get_p(self) -> float:
        return self._p

    def _set_p(self, v: float):
        self._p = float(v)
        self.update()

    p_val = pyqtProperty(float, fget=_get_p, fset=_set_p)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = self.rect().adjusted(1, 1, -1, -1)
        acc = accent_color(255)
        off = QColor(64, 68, 76)
        t = self._p
        track = QColor(
            int(off.red() + (acc.red() - off.red()) * t),
            int(off.green() + (acc.green() - off.green()) * t),
            int(off.blue() + (acc.blue() - off.blue()) * t),
        )
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(track)
        p.drawRoundedRect(r, r.height() / 2.0, r.height() / 2.0)
        d = r.height() - 6
        x = r.left() + 3 + (r.width() - d - 6) * t
        p.setBrush(QColor(246, 248, 251))
        p.drawEllipse(int(x), r.top() + 3, int(d), int(d))
        p.end()


class _Task(QThread):
    """Chạy một hàm nền (nhận callback log) để không đóng băng UI."""
    log = pyqtSignal(str)
    done = pyqtSignal(object)

    def __init__(self, fn):
        super().__init__()
        self._fn = fn

    def run(self):
        res = None
        try:
            res = self._fn(self.log.emit)
        except Exception as e:
            self.log.emit("[-] Lỗi: %s" % e)
        self.done.emit(res)


class AdminPanel(QWidget):
    def __init__(self, window):
        super().__init__(window)
        self.win = window
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(468, 486)
        self.hide()
        self._task = None

        lo = QVBoxLayout(self)
        lo.setContentsMargins(26, 20, 26, 22)
        lo.setSpacing(14)

        head = QHBoxLayout()
        head.addWidget(_label("⚡ PANEL ADMIN — TỐI CAO", 15))
        head.addStretch()
        self.btn_close = IconButton(_SVG_CLOSE, kind="close", parent=self, side=34)
        self.btn_close.clicked.connect(self.hide)
        head.addWidget(self.btn_close)
        lo.addLayout(head)

        # 1) Nút cần gạt CỰC HẠN
        row = QHBoxLayout()
        row.addWidget(_label("CỰC HẠN", 13))
        row.addSpacing(8)
        self.lbl_state = _label("(cân bằng)", 11, dim=True)
        row.addWidget(self.lbl_state)
        row.addStretch()
        self.sw = ToggleSwitch(self, on=False)
        self.sw.toggled.connect(self._on_extreme)
        row.addWidget(self.sw)
        lo.addLayout(row)

        # 2) & 3) hai nút thông minh
        self.btn_net = PushButton("TỰ ĐỘNG TỐI ƯU MẠNG", svg=_SVG_BOLT, primary=True)
        self.btn_net.setMinimumHeight(52)
        self.btn_net.clicked.connect(self._do_network)
        lo.addWidget(self.btn_net)

        self.btn_auto = PushButton("TỰ ĐỘNG TEST & CHỌN CẤU HÌNH CAO NHẤT",
                                   svg=_SVG_SETTINGS, primary=True)
        self.btn_auto.setMinimumHeight(52)
        self.btn_auto.clicked.connect(self._do_autotune)
        lo.addWidget(self.btn_auto)

        self.btn_restore = PushButton("KHÔI PHỤC MẠNG", primary=False)
        self.btn_restore.setMinimumHeight(40)
        self.btn_restore.clicked.connect(self._do_restore)
        lo.addWidget(self.btn_restore)

        lo.addWidget(_label(
            "Đổi DNS/TCP cần quyền Admin & có thể khôi phục bằng nút trên.",
            9, dim=True))

        self.log_view = LogView()
        self.log_view.setFixedHeight(150)
        lo.addWidget(self.log_view)

    # ------------------------------------------------------------- painting
    def paintEvent(self, e):
        p = QPainter(self)
        paint_metal_panel(p, self.rect(), radius=16.0, opacity=1.0)
        p.end()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Escape:
            self.hide()
        else:
            super().keyPressEvent(e)

    # ------------------------------------------------------------- behaviour
    def show_centered(self):
        if self.isVisible():
            self.hide()
            return
        pw = self.win
        self.move((pw.width() - self.width()) // 2,
                  (pw.height() - self.height()) // 2)
        self.show()
        self.raise_()
        play_droplet()
        self.log("[admin] Mở Panel Admin Tối Cao (Esc / X để đóng).")

    def log(self, m: str):
        try:
            self.log_view.append(m)
        except Exception:
            pass
        fn = getattr(self.win, "log_message", None)
        if callable(fn):
            try:
                fn(m)
            except Exception:
                pass

    def _apply_env(self, env: dict, label: str):
        for k, v in env.items():
            os.environ[k] = str(v)
        self.log("[admin] Đã áp %s:" % label)
        for k, v in env.items():
            self.log("    %s=%s" % (k, v))
        play_droplet()

    def _on_extreme(self, on: bool):
        self.lbl_state.setText("(CỰC HẠN)" if on else "(cân bằng)")
        self._apply_env(_EXTREME if on else _BALANCED,
                        "cấu hình CỰC HẠN" if on else "cấu hình cân bằng")

    def _busy(self, flag: bool):
        for b in (self.btn_net, self.btn_auto, self.btn_restore):
            b.setEnabled(not flag)

    def _run_task(self, fn, on_done):
        if self._task is not None and self._task.isRunning():
            self.log("[admin] Đang chạy một tác vụ khác, vui lòng chờ...")
            return
        self._busy(True)
        self._task = _Task(fn)
        self._task.log.connect(self.log)

        def _finish(res):
            try:
                on_done(res)
            finally:
                self._busy(False)
        self._task.done.connect(_finish)
        self._task.start()

    # -------------------------------------------------------------- actions
    def _do_network(self):
        self._run_task(
            lambda log: NET.optimize_network(log, aggressive=True),
            self._after_network)

    def _after_network(self, fast_hosts):
        if fast_hosts:
            os.environ["INTRO_PRO_TTS_HOSTS"] = ",".join(fast_hosts)
            self.log("[admin] Đã đặt %d host nhanh nhất vào engine." % len(fast_hosts))

    def _do_autotune(self):
        self._run_task(NET.auto_pick_config, self._after_autotune)

    def _after_autotune(self, env):
        if isinstance(env, dict) and env:
            self._apply_env(env, "cấu hình cao nhất (auto)")
            # đồng bộ nút cần gạt theo per_session chọn được
            try:
                per = int(env.get("INTRO_PRO_TTS_PER_SESSION", 32))
                self.sw.blockSignals(True)
                self.sw.setChecked(per >= 48)
                self.sw.blockSignals(False)
                self.lbl_state.setText("(CỰC HẠN)" if per >= 48 else "(cân bằng)")
            except Exception:
                pass

    def _do_restore(self):
        self._run_task(NET.restore_network, lambda _res: None)
