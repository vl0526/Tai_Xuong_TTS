import os
import json

from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtGui import QColor

_CONFIG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.json"
)

PRESETS = [
    ("Neon Pink", (255, 0, 103)),
    ("Cyan",      (0, 255, 255)),
    ("Yellow",    (255, 255, 0)),
    ("Magenta",   (255, 0, 170)),
    ("Red",       (255, 0, 0)),
    ("Blue",      (0, 0, 255)),
    ("Green",     (0, 255, 0)),
    ("Orange",    (255, 127, 0)),
    ("Violet",    (127, 0, 255)),
    ("White",     (255, 255, 255)),
    ("Black",     (0, 0, 0)),
    ("Brown",     (139, 90, 43)),
]

_DEFAULT_HEX = "#FF0000"

METAL_TOP = (62, 66, 72)
METAL_MID = (46, 50, 56)
METAL_BOT = (30, 33, 38)
METAL_EDGE_LIGHT = (108, 115, 124)
METAL_EDGE_DARK = (10, 11, 14)


def _clamp(v, lo=0, hi=255):
    return max(lo, min(hi, int(v)))


class _ThemeManager(QObject):

    themeChanged = pyqtSignal()

    def __init__(self):
        super().__init__()
        self._accent = QColor(_DEFAULT_HEX)
        self._index = 4
        self._refraction = 1.0
        self._chromatic = True
        self._engine = "auto"
        self._gradient = False
        self._load()

    def _read_config(self):
        if os.path.exists(_CONFIG_PATH):
            try:
                with open(_CONFIG_PATH, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def _load(self):
        cfg = self._read_config()
        idx = int(cfg.get("accent_index", 4))
        hexv = cfg.get("accent_color", _DEFAULT_HEX)
        if 0 <= idx < len(PRESETS):
            self._index = idx
            self._accent = QColor(*PRESETS[idx][1])
        else:
            c = QColor(hexv)
            if c.isValid():
                self._index = -1
                self._accent = c
            else:
                self._index = 4
                self._accent = QColor(_DEFAULT_HEX)

    def _save(self):
        cfg = self._read_config()
        cfg["accent_color"] = self.accent_hex()
        cfg["accent_index"] = self._index
        try:
            with open(_CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(cfg, f, indent=4, ensure_ascii=False)
        except Exception:
            pass

    def accent(self):
        return QColor(self._accent)

    def accent_rgb(self):
        return (self._accent.red(), self._accent.green(), self._accent.blue())

    def accent_hex(self):
        return self._accent.name().upper()

    def accent_index(self):
        return self._index

    def color(self, alpha=255):
        r, g, b = self.accent_rgb()
        return QColor(r, g, b, _clamp(alpha))

    def lighten(self, factor=1.25, alpha=255):
        r, g, b = self.accent_rgb()
        return QColor(_clamp(r * factor), _clamp(g * factor), _clamp(b * factor), _clamp(alpha))

    def darken(self, factor=0.7, alpha=255):
        return self.lighten(factor, alpha)

    def mix_navy(self, t=0.5, alpha=255):
        r, g, b = self.accent_rgb()
        nr, ng, nb = METAL_BOT
        return QColor(
            _clamp(nr + (r - nr) * t),
            _clamp(ng + (g - ng) * t),
            _clamp(nb + (b - nb) * t),
            _clamp(alpha),
        )

    def accent_floats(self):
        r, g, b = self.accent_rgb()
        return (r / 255.0, g / 255.0, b / 255.0)

    def bright(self, alpha=255):
        # Tra ve DUNG mau accent (khong cong sang) -> giu chuan tuyet doi #FF0000
        # tren toan bo widget dung accent_color().
        r, g, b = self.accent_rgb()
        out = QColor(_clamp(r), _clamp(g), _clamp(b))
        out.setAlpha(_clamp(alpha))
        return out

    def bright_hex(self):
        return self.bright().name().upper()

    def bright_text(self, alpha=255):
        return QColor(255, 255, 255, _clamp(alpha))

    def bright_text_hex(self):
        return "#FFFFFF"

    def refraction(self):
        return self._refraction

    def set_refraction(self, v):
        self._refraction = max(0.0, min(1.5, float(v)))
        self._save()
        self.themeChanged.emit()

    def chromatic(self):
        return self._chromatic

    def set_chromatic(self, on):
        self._chromatic = bool(on)
        self._save()
        self.themeChanged.emit()

    def engine(self):
        return self._engine

    def set_engine(self, mode):
        if mode in ("auto", "shader", "painted"):
            self._engine = mode
            self._save()
            self.themeChanged.emit()

    def gradient(self):
        return False

    def set_gradient(self, on):
        self._gradient = False
        self.themeChanged.emit()

    def advance_gradient(self, step=0.32):
        return

    def set_preset(self, index):
        if 0 <= index < len(PRESETS):
            self._gradient = False
            self._index = index
            self._accent = QColor(*PRESETS[index][1])
            self._save()
            self.themeChanged.emit()

    def set_custom(self, color):
        if isinstance(color, QColor) and color.isValid():
            self._gradient = False
            self._accent = QColor(color.red(), color.green(), color.blue())
            self._index = -1
            self._save()
            self.themeChanged.emit()

THEME = _ThemeManager()

def accent_color(alpha=255):
    return THEME.bright(alpha)

def accent_hex():
    return THEME.accent_hex()
