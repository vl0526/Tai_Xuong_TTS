"""TTS Pro UI package."""

# Nguồn phiên bản duy nhất — bộ cập nhật & panel Thông Tin đọc từ đây.
APP_VERSION = "2.0.6"
