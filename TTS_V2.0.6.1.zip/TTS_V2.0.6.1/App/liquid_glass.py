from PyQt6.QtCore import Qt, QRectF
from PyQt6.QtGui import QColor, QPainter, QPainterPath, QPen, QLinearGradient

from App.theme import (
    THEME,
    METAL_TOP,
    METAL_MID,
    METAL_BOT,
    METAL_EDGE_LIGHT,
    METAL_EDGE_DARK,
)


def _q(rgb, a=255):
    return QColor(rgb[0], rgb[1], rgb[2], a)


def _shift(rgb, d):
    return (
        max(0, min(255, rgb[0] + d)),
        max(0, min(255, rgb[1] + d)),
        max(0, min(255, rgb[2] + d)),
    )


def metal_tone(rgb):
    r, g, b = rgb
    top = (min(255, r + 40), min(255, g + 40), min(255, b + 40))
    mid = (r, g, b)
    bot = (int(r * 0.55), int(g * 0.55), int(b * 0.55))
    return (top, mid, bot)


def paint_metal_panel(p, rect, radius=10.0, opacity=1.0, inset=1.0,
                      top=METAL_TOP, mid=METAL_MID, bot=METAL_BOT):
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    r = QRectF(rect).adjusted(inset, inset, -inset, -inset)
    bk = min(float(radius), 12.0)
    body = QPainterPath()
    body.addRoundedRect(r, bk, bk)

    g = QLinearGradient(r.topLeft(), r.bottomLeft())
    g.setColorAt(0.0, _q(top))
    g.setColorAt(0.5, _q(mid))
    g.setColorAt(1.0, _q(bot))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(g)
    p.drawPath(body)

    sheen = QLinearGradient(r.topLeft(), r.bottomLeft())
    sheen.setColorAt(0.0, QColor(255, 255, 255, 26))
    sheen.setColorAt(0.14, QColor(255, 255, 255, 8))
    sheen.setColorAt(0.5, QColor(255, 255, 255, 0))
    p.fillPath(body, sheen)

    p.setBrush(Qt.BrushStyle.NoBrush)
    hi = QPainterPath()
    ih = max(0.0, bk - 1.2)
    hi.addRoundedRect(r.adjusted(1.2, 1.2, -1.2, -1.2), ih, ih)
    p.setPen(QPen(_q(METAL_EDGE_LIGHT, 80), 1.0))
    p.drawPath(hi)

    p.setPen(QPen(_q(METAL_EDGE_DARK, 235), 1.4))
    p.drawPath(body)
    p.restore()


def paint_liquid_glass(p, rect, radius=24.0, opacity=1.0,
                       spec=1.0, accent=None, refraction=None, chromatic=None):
    paint_metal_panel(p, rect, radius=radius, opacity=opacity)


def paint_metal_button(p, rect, radius=None, hover=0.0, press=0.0,
                       accent_edge=False, tone=None):
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    full = QRectF(rect)
    shadow_h = 5.0
    sink = 3.0 * press
    body_rect = QRectF(
        full.left() + 2,
        full.top() + 2 + sink,
        full.width() - 4,
        full.height() - shadow_h - 4,
    )
    if radius is None:
        bk = min(12.0, body_rect.height() / 2.0)
    else:
        bk = min(float(radius), body_rect.height() / 2.0)

    shadow_rect = QRectF(body_rect).translated(0, shadow_h - sink)
    sp = QPainterPath()
    sp.addRoundedRect(shadow_rect, bk, bk)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor(0, 0, 0, 205))
    p.drawPath(sp)

    if tone is None:
        tone = ((88, 94, 102), (58, 63, 70), (34, 37, 42))
    top, mid, bot = tone
    hb = int(20 * hover)

    body = QPainterPath()
    body.addRoundedRect(body_rect, bk, bk)
    g = QLinearGradient(0, body_rect.top(), 0, body_rect.bottom())
    g.setColorAt(0.0, _q(_shift(top, hb)))
    g.setColorAt(0.5, _q(mid))
    g.setColorAt(1.0, _q(bot))
    p.setBrush(g)
    p.drawPath(body)

    inset_x = min(body_rect.width() * 0.06, 10.0)
    sr = QRectF(body_rect.left() + inset_x, body_rect.top() + 2.0,
               body_rect.width() - 2 * inset_x, body_rect.height() * 0.44)
    srad = max(2.0, min(bk - 1.5, sr.height() / 2.0))
    strip = QPainterPath()
    strip.addRoundedRect(sr, srad, srad)
    gs = QLinearGradient(0, sr.top(), 0, sr.bottom())
    gs.setColorAt(0.0, QColor(255, 255, 255, int(62 + 40 * hover)))
    gs.setColorAt(1.0, QColor(255, 255, 255, 0))
    p.fillPath(strip, gs)

    p.setBrush(Qt.BrushStyle.NoBrush)
    ir = QRectF(body_rect).adjusted(1, 1, -1, -1)
    ib = max(0.0, bk - 1)
    inner = QPainterPath()
    inner.addRoundedRect(ir, ib, ib)
    p.setPen(QPen(QColor(255, 255, 255, 34), 1.0))
    p.drawPath(inner)

    if accent_edge:
        ac = THEME.accent()
        p.setPen(QPen(QColor(ac.red(), ac.green(), ac.blue(), 235), 1.8))
    else:
        p.setPen(QPen(QColor(8, 9, 11, 240), 1.4))
    p.drawPath(body)
    p.restore()
    return body_rect
