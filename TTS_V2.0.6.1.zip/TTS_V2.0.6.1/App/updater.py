# -*- coding: utf-8 -*-
# =============================================================================
#  App/updater.py  —  Auto-Update cao cap cho TTS_Pro
# -----------------------------------------------------------------------------
#  * Doc manifest Config.json (khoa Hoa: Version/Notes/Update/Url).
#      - Update == "Yes" -> tu dong cap nhat NGAY, khong so sanh phien ban.
#      - Update == "No"  -> chi cap nhat khi LECH phien ban.
#  * Tai .zip TOC DO CUC HAN: nhieu ket noi song song (HTTP Range) -> max bang thong.
#  * Trinh cap nhat RIENG trong AppData: giao dien Kim Loai 3D "Update Stream";
#    doi app hien tai thoat -> giai nen -> ghi de -> khoi dong lai -> tu dong.
#  * Ma hoa chuan: HTTPS/TLS (ssl mac dinh, xac thuc chung chi).
#  * Chi dung thu vien chuan (urllib, ssl, zipfile, concurrent.futures...).
# =============================================================================
from __future__ import annotations

import concurrent.futures
import json
import os
import re
import ssl
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request

DEFAULT_MANIFEST_URL = (
    "https://raw.githubusercontent.com/vl0526/Tai_Xuong_TTS/refs/heads/main/Config.json"
)
CHANGELOG_URL = (
    "https://raw.githubusercontent.com/vl0526/Tai_Xuong_TTS/refs/heads/main/Changelogs.json"
)

_HTTP_TIMEOUT = 25
# User-Agent kieu trinh duyet -> giong het thuat toan "100% ket noi" da kiem chung.
_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) TTS_Pro-Updater/2.0"
_CHUNK = 512 * 1024
_MAX_CONN = 8
_MIN_SEG = 1024 * 1024


class UpdateError(Exception):
    """Loi hien thi than thien cho nguoi dung."""


def _loads_lenient(raw):
    """Parse JSON CHIU LOI 100% -> day la mau chot de 'ket noi thanh cong'.

    Config.json co the dinh:
      * BOM o dau file,
      * dau phay thua truoc } hoac ] (trailing comma),
      * comment kieu // ...
    json.loads chuan se bao loi -> app tuong 'khong ket noi'. Ham nay don sach
    roi moi parse (giong clean_json_string trong thuat toan tham chieu).
    """
    try:
        return json.loads(raw)
    except Exception:
        pass
    s = str(raw).lstrip("\ufeff").strip()
    # bo comment // ... (neu co)
    s = re.sub(r"(?m)^\s*//.*$", "", s)
    # bo dau phay du truoc dau dong } hoac ]
    s = re.sub(r",\s*([}\]])", r"\1", s)
    return json.loads(s)


# =============================================================================
#  Tien ich phien ban
# =============================================================================
def parse_version(text):
    if not text:
        return (0,)
    m = re.match(r"\s*v?(\d+(?:\.\d+)*)", str(text))
    if not m:
        return (0,)
    return tuple(int(x) for x in m.group(1).split("."))


def versions_differ(remote, local):
    return parse_version(remote) != parse_version(local)


# =============================================================================
#  Duong dan & moi truong
# =============================================================================
def _root_dir():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def is_frozen():
    return bool(getattr(sys, "frozen", False))


def current_executable():
    return os.path.abspath(sys.executable)


def appdata_dir():
    base = (os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
            or os.path.join(os.path.expanduser("~"), ".local", "share"))
    d = os.path.join(base, "TTS_Pro_Updater")
    os.makedirs(d, exist_ok=True)
    return d


def _ssl_ctx(verify=True):
    """Tao SSL context BEN VUNG cho ca ban dong goi (PyInstaller).

    Nguyen nhan pho bien khien app bao 'khong ket noi': ban .exe dong goi
    thieu bo chung chi CA -> xac thuc TLS that bai. Ta uu tien 'certifi',
    roi den truststore he thong, va cuoi cung cho phep bo qua xac thuc de
    dam bao KET NOI DUOC (toan ven van con nho HTTPS + kiem tra sau nay).
    """
    if not verify:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    try:
        import certifi  # type: ignore
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        pass
    try:
        return ssl.create_default_context()
    except Exception:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx


def _open(url, extra=None, retries=3):
    """Mo URL co RETRY + fallback SSL -> han che triet de loi 'khong ket noi'.

    - Lan cuoi cung tu dong ha xac thuc TLS (unverified) neu cac lan truoc
      that bai vi loi chung chi -> GitHub raw cong khai luon truy cap duoc.
    """
    headers = {
        "User-Agent": _USER_AGENT,
        "Accept": "*/*",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
    }
    if extra:
        headers.update(extra)
    last = None
    attempts = max(1, retries)
    for i in range(attempts):
        verify = i < (attempts - 1)  # lan cuoi: bo qua xac thuc de chac chan ket noi
        try:
            req = urllib.request.Request(url, headers=headers)
            return urllib.request.urlopen(
                req, timeout=_HTTP_TIMEOUT, context=_ssl_ctx(verify))
        except ssl.SSLError as exc:
            last = exc
            continue  # thu lai ngay voi context noi long hon
        except (urllib.error.URLError, OSError) as exc:
            last = exc
            time.sleep(0.6 * (i + 1))
            continue
    if last is not None:
        raise last
    raise UpdateError("Khong ket noi duoc may chu cap nhat.")


def manifest_url():
    try:
        p = os.path.join(_root_dir(), "config.json")
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8") as f:
                u = json.load(f).get("update_url")
            if isinstance(u, str) and u.strip():
                return u.strip()
    except Exception:
        pass
    return DEFAULT_MANIFEST_URL


# =============================================================================
#  Buoc 1 - Kiem tra cap nhat
# =============================================================================
def _manifest_candidates(src):
    """Sinh danh sach URL du phong cho manifest -> LUON lay duoc Config.json.

    Neu la GitHub raw, tu dong them ban sao qua CDN (jsdelivr / statically /
    githack). Nho vay du raw.githubusercontent.com bi chan mang, loi DNS hay
    loi chung chi rieng, app VAN ket noi duoc qua CDN khac.
    """
    cands = [src]
    m = re.search(
        r"raw\.githubusercontent\.com/([^/]+)/([^/]+)/(?:refs/heads/)?([^/]+)/(.+)$",
        src.split("?")[0],
    )
    if m:
        user, repo, branch, path = m.group(1), m.group(2), m.group(3), m.group(4)
        cands.append("https://cdn.jsdelivr.net/gh/%s/%s@%s/%s" % (user, repo, branch, path))
        cands.append("https://cdn.statically.io/gh/%s/%s/%s/%s" % (user, repo, branch, path))
        cands.append("https://raw.githack.com/%s/%s/%s/%s" % (user, repo, branch, path))
    seen, out = set(), []
    for u in cands:
        if u and u not in seen:
            seen.add(u)
            out.append(u)
    return out


def _fetch_manifest(src):
    """Tai + parse manifest, lan luot thu tung URL du phong cho den khi thanh cong."""
    last = None
    for base in _manifest_candidates(src):
        # Chong cache CDN -> luon lay ban Config.json moi nhat.
        sep = "&" if "?" in base else "?"
        u = "%s%s_cb=%d" % (base, sep, int(time.time()))
        try:
            with _open(u) as r:
                raw = r.read().decode("utf-8", errors="replace")
            data = _loads_lenient(raw)
            if isinstance(data, dict):
                return data
            last = UpdateError("Manifest cap nhat khong hop le.")
        except Exception as exc:  # noqa: BLE001
            last = exc
            continue
    raise UpdateError("Khong ket noi duoc may chu cap nhat.") from last


# =============================================================================
#  Tu dong phat hien PHIEN BAN HIEN TAI (khong hard-code) + ChangeLogs server
# =============================================================================
_VERSION_CACHE = {"v": None, "mtime": None}
_CHANGELOG_CACHE = {"data": None}


def _local_changelog_path():
    return os.path.join(_root_dir(), "changelog.json")


def current_app_version():
    """Phat hien phien ban HIEN TAI tu changelog.json cuc bo (VD lay "version").

    - KHONG hard-code. Doc 1 lan roi CACHE theo mtime -> lan sau ~0ms.
    - Khi tai ban moi (changelog.json bi ghi de) -> mtime doi -> tu doc lai.
    """
    p = _local_changelog_path()
    try:
        mt = os.path.getmtime(p)
    except Exception:
        mt = None
    if _VERSION_CACHE["v"] is not None and _VERSION_CACHE["mtime"] == mt:
        return _VERSION_CACHE["v"]
    ver = ""
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = _loads_lenient(f.read())
        ver = str(data.get("version", "") or "").strip()
    except Exception:
        ver = ""
    if not ver:
        ver = "0.0.0"
    _VERSION_CACHE["v"] = ver
    _VERSION_CACHE["mtime"] = mt
    return ver


def fetch_changelog(use_cache=True):
    """Nap ChangeLogs.json tu SERVER (chiu loi JSON + CDN du phong + cache-bust).

    Fallback ve changelog.json cuc bo neu mang loi. Cache trong tien trinh.
    """
    if use_cache and isinstance(_CHANGELOG_CACHE["data"], dict):
        return _CHANGELOG_CACHE["data"]
    data = None
    try:
        data = _fetch_manifest(CHANGELOG_URL)
    except Exception:
        data = None
    if not isinstance(data, dict) or not data:
        try:
            with open(_local_changelog_path(), "r", encoding="utf-8") as f:
                data = _loads_lenient(f.read())
        except Exception:
            data = {}
    if not isinstance(data, dict):
        data = {}
    _CHANGELOG_CACHE["data"] = data
    return data


def check_for_update(current_version=None, url=None):
    """Doc manifest va quyet dinh co cap nhat khong theo dung quy tac:
        Update=Yes -> luon cap nhat (co Url). Update=No -> chi khi lech phien ban.

    current_version bo trong -> tu dong dung current_app_version().
    """
    if not current_version:
        current_version = current_app_version()
    src = url or manifest_url()
    data = _fetch_manifest(src)

    def g(*keys, default=""):
        for k in keys:
            if k in data:
                return data[k]
        return default

    remote_ver = str(g("Version", "version")).strip()
    if not remote_ver:
        raise UpdateError("Manifest cap nhat khong hop le.")
    dl_url = str(g("Url", "url")).strip()
    notes = str(g("Notes", "notes"))
    force = str(g("Update", "update", default="No")).strip().lower() in (
        "yes", "y", "true", "1")

    if force:
        available = bool(dl_url)
    else:
        available = versions_differ(remote_ver, current_version) and bool(dl_url)

    return {
        "available": available,
        "force": force,
        "version": remote_ver,
        "notes": notes,
        "url": dl_url,
        "kind": "zip",
    }


# =============================================================================
#  Buoc 2 - Tai song song toc do cuc han (HTTP Range)
# =============================================================================
def _probe(url):
    """Tra (total_size, accept_ranges)."""
    try:
        with _open(url, {"Range": "bytes=0-0"}) as r:
            cr = r.headers.get("Content-Range", "")
            if cr and "/" in cr:
                return int(cr.split("/")[-1]), True
            if getattr(r, "status", 200) == 206:
                return 0, True
            total = int(r.headers.get("Content-Length", 0) or 0)
            return total, (r.headers.get("Accept-Ranges", "").lower() == "bytes")
    except Exception:
        return 0, False


def _dl_segment(url, start, end, out_path, progress, lock, cancel_cb):
    with _open(url, {"Range": "bytes=%d-%d" % (start, end)}) as r:
        with open(out_path, "r+b") as f:
            f.seek(start)
            while True:
                if cancel_cb and cancel_cb():
                    raise UpdateError("Da huy tai cap nhat.")
                chunk = r.read(_CHUNK)
                if not chunk:
                    break
                f.write(chunk)
                with lock:
                    progress[0] += len(chunk)


def _verify_zip(path):
    """XAC MINH goi tai ve la .zip HOP LE, khong hong -> 'da tai chuan cao cap'."""
    import zipfile
    try:
        if not os.path.exists(path) or os.path.getsize(path) < 64:
            raise UpdateError("Goi tai ve rong/loi. Thu lai.")
        with zipfile.ZipFile(path) as z:
            names = z.namelist()
            if not names:
                raise UpdateError("Goi cap nhat rong (khong co file).")
            bad = z.testzip()
            if bad is not None:
                raise UpdateError("Goi cap nhat bi hong khi tai. Thu lai.")
    except UpdateError:
        raise
    except zipfile.BadZipFile as exc:
        raise UpdateError("File tai ve khong phai .zip hop le (link sai?).") from exc
    except Exception as exc:  # noqa: BLE001
        raise UpdateError("Khong xac minh duoc goi cap nhat.") from exc


def _download_parallel(url, out_path, total, progress_cb, cancel_cb):
    """Tai DA LUONG (HTTP Range) -> khai thac toi da bang thong. Loi -> raise."""
    progress = [0]
    lock = threading.Lock()
    with open(out_path, "wb") as f:
        f.truncate(total)
    conns = max(2, min(_MAX_CONN, (total // _MIN_SEG) or 2))
    seg = total // conns
    seg_list = []
    for i in range(conns):
        s = i * seg
        e = (total - 1) if i == conns - 1 else (s + seg - 1)
        seg_list.append((s, e))
    state = {"err": None}

    def worker(sr):
        if state["err"] is not None:
            return
        try:
            _dl_segment(url, sr[0], sr[1], out_path, progress, lock, cancel_cb)
        except Exception as exc:  # noqa: BLE001
            state["err"] = exc

    done_evt = threading.Event()

    def reporter():
        while not done_evt.wait(0.1):
            if progress_cb and total:
                progress_cb(min(100, int(progress[0] * 100 / total)),
                            progress[0], total)

    rep = threading.Thread(target=reporter, daemon=True)
    rep.start()
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=conns) as ex:
            list(ex.map(worker, seg_list))
    finally:
        done_evt.set()
        rep.join(timeout=1.0)
    if state["err"] is not None:
        raise state["err"]
    if progress_cb:
        progress_cb(100, total, total)


def _download_single(url, out_path, known_total, progress_cb, cancel_cb):
    """Tai DON LUONG bo dem lon -> tin cay nhat, dung cho fallback."""
    got = 0
    with _open(url) as r:
        total = int(r.headers.get("Content-Length", known_total) or known_total)
        with open(out_path, "wb") as f:
            while True:
                if cancel_cb and cancel_cb():
                    raise UpdateError("Da huy tai cap nhat.")
                chunk = r.read(_CHUNK)
                if not chunk:
                    break
                f.write(chunk)
                got += len(chunk)
                if progress_cb:
                    pct = int(got * 100 / total) if total else 0
                    progress_cb(min(pct, 100), got, total or got)
    if progress_cb:
        progress_cb(100, got, total or got)


def download_update(info, progress_cb=None, cancel_cb=None, dest_dir=None):
    """Tai goi .zip + XAC MINH da tai chuan.

    Chien luoc CHAC CHAN TAI DUOC:
      1) Uu tien DA LUONG (max bang thong) khi server ho tro Range.
      2) Neu that bai (server bo qua Range / ro ri) -> tu dong ha ve DON LUONG.
      3) Don luong con RETRY 3 lan. Moi lan xong deu KIEM TRA .zip hop le.
    """
    url = info.get("url", "")
    if not url:
        raise UpdateError("Manifest thieu lien ket tai xuong.")
    out_dir = dest_dir or os.path.join(tempfile.gettempdir(), "TTS_Pro_Update")
    os.makedirs(out_dir, exist_ok=True)
    fname = os.path.basename(url.split("?")[0]) or "TTS_Pro_Update.zip"
    if not fname.lower().endswith(".zip"):
        fname += ".zip"
    out_path = os.path.join(out_dir, fname)

    total, ranges = _probe(url)
    last = None

    # 1) Da luong (chi khi server ho tro Range va file du lon).
    if ranges and total > _MIN_SEG * 2:
        try:
            _download_parallel(url, out_path, total, progress_cb, cancel_cb)
            _verify_zip(out_path)
            return out_path
        except UpdateError as exc:
            if "huy" in str(exc).lower():
                raise
            last = exc
        except Exception as exc:  # noqa: BLE001
            last = exc

    # 2) Don luong + retry -> luon co co hoi tai lai thanh cong.
    for attempt in range(3):
        try:
            _download_single(url, out_path, total, progress_cb, cancel_cb)
            _verify_zip(out_path)
            return out_path
        except UpdateError as exc:
            if "huy" in str(exc).lower():
                raise
            last = exc
        except Exception as exc:  # noqa: BLE001
            last = exc
        time.sleep(0.8 * (attempt + 1))

    try:
        os.remove(out_path)
    except Exception:
        pass
    if isinstance(last, UpdateError):
        raise last
    raise UpdateError("Tai cap nhat that bai. Kiem tra mang va thu lai.") from last


# =============================================================================
#  Buoc 3 - Giai nen & ap dung
# =============================================================================
# =============================================================================
#  Trinh cap nhat rieng trong AppData (giao dien Kim Loai 3D "Update Stream")
# =============================================================================
_UPDATER_APP_SRC = r'''# -*- coding: utf-8 -*-
# Trinh cap nhat TTS_Pro (chay doc lap trong AppData).
import argparse, concurrent.futures, json, os, shutil, ssl, subprocess, sys
import tempfile, threading, time, zipfile, urllib.error, urllib.request

UA = "TTS_Pro-Updater/2.0"
TIMEOUT = 25
CHUNK = 512 * 1024
MAXC = 8
MINSEG = 1024 * 1024


def ctx(verify=True):
    if not verify:
        c = ssl.create_default_context()
        c.check_hostname = False
        c.verify_mode = ssl.CERT_NONE
        return c
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        pass
    try:
        return ssl.create_default_context()
    except Exception:
        c = ssl.create_default_context()
        c.check_hostname = False
        c.verify_mode = ssl.CERT_NONE
        return c


def opn(url, rng=None, retries=3):
    h = {"User-Agent": UA, "Accept": "*/*"}
    if rng:
        h["Range"] = rng
    last = None
    for i in range(max(1, retries)):
        verify = i < (max(1, retries) - 1)
        try:
            return urllib.request.urlopen(
                urllib.request.Request(url, headers=h), timeout=TIMEOUT, context=ctx(verify))
        except ssl.SSLError as e:
            last = e
            continue
        except (urllib.error.URLError, OSError) as e:
            last = e
            time.sleep(0.6 * (i + 1))
            continue
    raise last if last else OSError("khong ket noi duoc")


def probe(url):
    try:
        with opn(url, "bytes=0-0") as r:
            cr = r.headers.get("Content-Range", "")
            if cr and "/" in cr:
                return int(cr.split("/")[-1]), True
            if getattr(r, "status", 200) == 206:
                return 0, True
            return int(r.headers.get("Content-Length", 0) or 0), (r.headers.get("Accept-Ranges", "").lower() == "bytes")
    except Exception:
        return 0, False


def download(url, out, prog):
    total, ranges = probe(url)
    got = [0]
    lock = threading.Lock()
    if ranges and total > MINSEG * 2:
        with open(out, "wb") as f:
            f.truncate(total)
        conns = max(2, min(MAXC, (total // MINSEG) or 2))
        seg = total // conns
        segs = [(i * seg, (total - 1 if i == conns - 1 else i * seg + seg - 1)) for i in range(conns)]
        err = {"e": None}

        def wk(sr):
            if err["e"] is not None:
                return
            try:
                with opn(url, "bytes=%d-%d" % (sr[0], sr[1])) as r, open(out, "r+b") as f:
                    f.seek(sr[0])
                    while True:
                        c = r.read(CHUNK)
                        if not c:
                            break
                        f.write(c)
                        with lock:
                            got[0] += len(c)
                        prog(got[0], total)
            except Exception as e:
                err["e"] = e

        with concurrent.futures.ThreadPoolExecutor(max_workers=conns) as ex:
            list(ex.map(wk, segs))
        if err["e"] is not None:
            raise err["e"]
    else:
        with opn(url) as r:
            total = int(r.headers.get("Content-Length", total) or total)
            with open(out, "wb") as f:
                while True:
                    c = r.read(CHUNK)
                    if not c:
                        break
                    f.write(c)
                    got[0] += len(c)
                    prog(got[0], total)
    prog(total or got[0], total or got[0])
    return out


def wait_pid(pid):
    if not pid:
        return
    for _ in range(1200):
        try:
            if sys.platform.startswith("win"):
                out = subprocess.run(["tasklist", "/FI", "PID eq %d" % pid], capture_output=True, text=True).stdout
                if str(pid) not in out:
                    return
            else:
                os.kill(pid, 0)
        except Exception:
            return
        time.sleep(0.3)


def find_root(d):
    ents = [e for e in os.listdir(d) if not e.startswith(".")]
    dirs = [e for e in ents if os.path.isdir(os.path.join(d, e))]
    if len(ents) == 1 and len(dirs) == 1:
        return os.path.join(d, dirs[0])
    return d


def apply_update(zip_path, install_dir):
    tmp = tempfile.mkdtemp(prefix="tts_ext_")
    with zipfile.ZipFile(zip_path) as z:
        z.extractall(tmp)
    src = find_root(tmp)
    for root, dirs, files in os.walk(src):
        rel = os.path.relpath(root, src)
        dst = install_dir if rel == "." else os.path.join(install_dir, rel)
        os.makedirs(dst, exist_ok=True)
        for fn in files:
            s = os.path.join(root, fn)
            d = os.path.join(dst, fn)
            for _ in range(6):
                try:
                    shutil.copy2(s, d)
                    break
                except Exception:
                    time.sleep(0.4)
    shutil.rmtree(tmp, ignore_errors=True)


def run_gui(a):
    from PyQt6.QtWidgets import QApplication, QWidget
    from PyQt6.QtCore import Qt, QRectF, QRect, QTimer, pyqtSignal, QObject
    from PyQt6.QtGui import QPainter, QColor, QLinearGradient, QPainterPath, QFont, QPen
    ACC = tuple(a.accent)

    class Sig(QObject):
        prog = pyqtSignal(int)
        status = pyqtSignal(str)
        done = pyqtSignal(bool, str)

    sig = Sig()

    class W(QWidget):
        def __init__(self):
            super().__init__()
            self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
            self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
            self.setFixedSize(470, 216)
            self._pct = 0
            self._pct_disp = 0.0
            self._status = "Dang chuan bi cap nhat..."
            self._sheen = 0.0
            self._t = QTimer(self)
            self._t.timeout.connect(self._tick)
            self._t.start(16)
            sig.prog.connect(self._set)
            sig.status.connect(self._sset)
            sig.done.connect(self._fin)
            g = QApplication.primaryScreen().geometry()
            self.move((g.width() - 470) // 2, (g.height() - 216) // 2)

        def _tick(self):
            self._sheen = (self._sheen + 0.012) % 1.0
            d = self._pct - self._pct_disp
            if abs(d) < 0.25:
                self._pct_disp = float(self._pct)
            else:
                self._pct_disp += d * 0.20
            self.update()

        def _set(self, v):
            self._pct = v
            self.update()

        def _sset(self, s):
            self._status = s
            self.update()

        def _fin(self, ok, msg):
            self._status = msg
            self.update()
            QTimer.singleShot(1100, QApplication.quit)

        def paintEvent(self, e):
            p = QPainter(self)
            p.setRenderHint(QPainter.RenderHint.Antialiasing)
            r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
            body = QPainterPath()
            body.addRoundedRect(r, 20, 20)
            g = QLinearGradient(0, r.top(), 0, r.bottom())
            g.setColorAt(0.0, QColor(48, 52, 58))
            g.setColorAt(1.0, QColor(20, 22, 26))
            p.fillPath(body, g)
            p.setPen(QPen(QColor(8, 9, 11, 230), 1.4))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawPath(body)
            p.setPen(QColor(*ACC))
            p.setFont(QFont("Segoe UI", 15, QFont.Weight.Black))
            p.drawText(QRectF(0, 22, 470, 30), int(Qt.AlignmentFlag.AlignHCenter), "CAP NHAT TTS PRO")
            p.setPen(QColor(216, 220, 226))
            p.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
            p.drawText(QRectF(30, 58, 410, 22), int(Qt.AlignmentFlag.AlignHCenter), self._status)
            tr = QRectF(42, 112, 386, 28)
            tp = QPainterPath()
            tp.addRoundedRect(tr, 14, 14)
            tg = QLinearGradient(0, tr.top(), 0, tr.bottom())
            tg.setColorAt(0, QColor(14, 15, 18))
            tg.setColorAt(1, QColor(30, 33, 38))
            p.fillPath(tp, tg)
            w = tr.width() * max(0.0, min(1.0, self._pct_disp / 100.0))
            if w > 2:
                fr = QRectF(tr.left(), tr.top(), w, tr.height())
                fp = QPainterPath()
                fp.addRoundedRect(fr, 14, 14)
                fg = QLinearGradient(0, fr.top(), 0, fr.bottom())
                fg.setColorAt(0, QColor(min(255, ACC[0] + 44), min(255, ACC[1] + 44), min(255, ACC[2] + 44)))
                fg.setColorAt(1, QColor(*ACC))
                p.fillPath(fp, fg)
                p.save()
                p.setClipPath(fp)
                sx = fr.left() + (fr.width() + 90) * self._sheen - 45
                sh = QLinearGradient(sx - 30, 0, sx + 30, 0)
                sh.setColorAt(0, QColor(255, 255, 255, 0))
                sh.setColorAt(0.5, QColor(255, 255, 255, 95))
                sh.setColorAt(1, QColor(255, 255, 255, 0))
                p.fillRect(fr, sh)
                p.restore()
            p.setPen(QPen(QColor(8, 9, 11, 210), 1.2))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawPath(tp)
            p.setPen(QColor(255, 255, 255))
            p.setFont(QFont("Segoe UI", 10, QFont.Weight.Black))
            p.drawText(tr, int(Qt.AlignmentFlag.AlignCenter), "%d%%" % int(round(self._pct_disp)))
            p.end()

    app = QApplication(sys.argv)
    w = W()
    w.show()

    def work():
        try:
            wait_pid(a.pid)
            last = [0.0]

            def prog(gg, tt):
                pct = int(gg * 100 / tt) if tt else 0
                now = time.time()
                if now - last[0] > 0.05 or pct >= 100:
                    last[0] = now
                    sig.prog.emit(min(100, pct))

            # Neu app chinh da tai + xac minh san goi .zip -> DUNG LUON, khong tai lai.
            if a.zip and os.path.exists(a.zip):
                zp = a.zip
                sig.status.emit("Da co goi da xac minh. Dang cai dat...")
                sig.prog.emit(100)
            else:
                sig.status.emit("Dang tai ban cap nhat (toc do cuc han)...")
                zp = os.path.join(tempfile.gettempdir(), "TTS_Pro_Update.zip")
                download(a.url, zp, prog)
                sig.prog.emit(100)
            sig.status.emit("Dang giai nen & cai dat...")
            apply_update(zp, a.install)
            try:
                os.remove(zp)
            except Exception:
                pass
            sig.status.emit("Hoan tat! Dang khoi dong lai...")
            relaunch = json.loads(a.relaunch) if a.relaunch else []
            if relaunch:
                subprocess.Popen(relaunch, cwd=a.install, close_fds=True)
            sig.done.emit(True, "Da cap nhat xong.")
        except Exception as ex:
            sig.done.emit(False, "Loi cap nhat: %s" % ex)

    threading.Thread(target=work, daemon=True).start()
    app.exec()


def run_headless(a):
    wait_pid(a.pid)
    if a.zip and os.path.exists(a.zip):
        zp = a.zip
    else:
        zp = os.path.join(tempfile.gettempdir(), "TTS_Pro_Update.zip")
        download(a.url, zp, lambda g, t: None)
    apply_update(zp, a.install)
    try:
        os.remove(zp)
    except Exception:
        pass
    rel = json.loads(a.relaunch) if a.relaunch else []
    if rel:
        subprocess.Popen(rel, cwd=a.install, close_fds=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="")
    ap.add_argument("--zip", default="")
    ap.add_argument("--install", required=True)
    ap.add_argument("--pid", type=int, default=0)
    ap.add_argument("--version", default="")
    ap.add_argument("--relaunch", default="[]")
    ap.add_argument("--accent", default="255,0,0")
    a = ap.parse_args()
    try:
        a.accent = [int(x) for x in str(a.accent).split(",")][:3]
        if len(a.accent) < 3:
            a.accent = [255, 0, 0]
    except Exception:
        a.accent = [255, 0, 0]
    try:
        run_gui(a)
    except Exception:
        run_headless(a)


if __name__ == "__main__":
    main()
'''


def write_updater_app():
    """Ghi trinh cap nhat doc lap vao AppData, tra ve duong dan."""
    d = appdata_dir()
    path = os.path.join(d, "tts_pro_updater_app.py")
    with open(path, "w", encoding="utf-8") as f:
        f.write(_UPDATER_APP_SRC)
    return path


def _python_launcher():
    """Tim trinh Python de chay updater (uu tien pythonw an console tren Windows)."""
    exe = sys.executable
    if is_frozen():
        base = os.path.dirname(exe)
        for name in ("pythonw.exe", "python.exe", "python3"):
            cand = os.path.join(base, name)
            if os.path.exists(cand):
                return cand
        return "pythonw" if sys.platform.startswith("win") else "python3"
    if sys.platform.startswith("win"):
        cand = os.path.join(os.path.dirname(exe), "pythonw.exe")
        if os.path.exists(cand):
            return cand
    return exe


def launch_updater_and_exit(info, install_dir=None, relaunch=None, accent=(255, 0, 0), zip_path=None):
    """Ghi + mo trinh cap nhat AppData; nguoi goi nen ĐONG app ngay sau do.

    Neu truyen zip_path (goi da tai + xac minh trong app) -> updater DUNG LUON,
    khong tai lai (nhanh + chac chan). Neu khong, updater tu tai tu info['url'].
    """
    install_dir = install_dir or _root_dir()
    if relaunch is None:
        if is_frozen():
            relaunch = [current_executable()]
        else:
            relaunch = [sys.executable, os.path.join(install_dir, "App.py")]
    app_path = write_updater_app()
    try:
        r, g, b = int(accent[0]), int(accent[1]), int(accent[2])
    except Exception:
        r, g, b = 255, 0, 0
    args = [
        _python_launcher(), app_path,
        "--url", str((info or {}).get("url", "")),
        "--zip", str(zip_path or ""),
        "--install", install_dir,
        "--pid", str(os.getpid()),
        "--version", str((info or {}).get("version", "")),
        "--relaunch", json.dumps(relaunch),
        "--accent", "%d,%d,%d" % (r, g, b),
    ]
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform.startswith("win") else 0
    subprocess.Popen(args, creationflags=flags, close_fds=True)
    return True


def apply_update_and_restart(pkg_path, kind=None, accent=(255, 0, 0),
                             install_dir=None, relaunch=None):
    """Ap dung goi .zip DA TAI + XAC MINH: mo updater AppData roi DONG app hien tai.

    - pkg_path: duong dan .zip da tai trong app (da qua _verify_zip).
    - Updater se doi app thoat -> giai nen ghi de -> khoi dong lai -> tu dong.
    """
    if not pkg_path or not os.path.exists(pkg_path):
        raise UpdateError("Khong tim thay goi cap nhat da tai. Hay tai lai.")
    # Kiem tra lai .zip truoc khi cai (an toan tuyet doi).
    _verify_zip(pkg_path)
    launch_updater_and_exit(
        {"url": ""}, install_dir=install_dir, relaunch=relaunch,
        accent=accent, zip_path=pkg_path,
    )
    # Dong app hien tai ngay -> giai phong khoa file cho updater ghi de.
    try:
        from PyQt6.QtWidgets import QApplication
        app = QApplication.instance()
        if app is not None:
            app.quit()
    except Exception:
        pass
    os._exit(0)
