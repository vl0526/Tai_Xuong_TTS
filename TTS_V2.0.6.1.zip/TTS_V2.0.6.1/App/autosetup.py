# -*- coding: utf-8 -*-
from __future__ import annotations

import ctypes
import ctypes.util
import os
import sys
import time
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
_NATIVE = _ROOT / "Speech" / "native"
_LOG_DIR = _ROOT / "logs"


def _say(msg: str) -> None:
    line = f"[auto-setup] {msg}"
    try:
        print(line, flush=True)
    except Exception:
        pass
    try:
        _LOG_DIR.mkdir(parents=True, exist_ok=True)
        with open(_LOG_DIR / "app.log", "a", encoding="utf-8", errors="replace") as f:
            f.write(time.strftime("\n%Y-%m-%d %H:%M:%S | ") + line)
    except Exception:
        pass


def _library_names() -> tuple[str, ...]:
    if sys.platform.startswith("win"):
        return ("libmpg123-0.dll", "libmpg123.dll")
    if sys.platform == "darwin":
        return ("libmpg123.0.dylib", "libmpg123.dylib")
    return ("libmpg123.so.0", "libmpg123.so")


def _candidate_paths() -> list[Path]:
    out: list[Path] = []
    override = os.environ.get("LIBMPG123", "").strip() or os.environ.get("MP3TURBO_LIB", "").strip()
    if override:
        out.append(Path(override))
    for name in _library_names():
        out.append(_NATIVE / name)
    found = ctypes.util.find_library("mpg123")
    if found:
        out.append(Path(found))
    return out


def _verify(path: Path) -> bool:
    try:
        if sys.platform.startswith("win") and path.parent.exists():
            try:
                os.add_dll_directory(str(path.parent))
            except Exception:
                pass
        lib = ctypes.CDLL(str(path))
        getattr(lib, "mpg123_new")
        getattr(lib, "mpg123_read")
        getattr(lib, "mpg123_feed")
        return True
    except Exception as exc:
        _say(f"Bỏ qua decoder không hợp lệ {path}: {exc!r}")
        return False


def ensure_decoder() -> bool:
    """Fail-fast decoder check: không tải mạng, không UAC, không build lúc mở app."""
    for path in _candidate_paths():
        if path.exists() or not path.is_absolute():
            if _verify(path):
                _say(f"✔ Decoder sẵn sàng: {path}")
                return True
    _say("Thiếu libmpg123; thêm lib vào Speech/native hoặc đặt LIBMPG123. Không tải/buildup lúc khởi động.")
    return False



def ensure_numpy() -> bool:
    """Bảo đảm NumPy sẵn sàng — đường xử lý âm thanh TỐC ĐỘ CỰC HẠN, KHÔNG fallback.

    Nếu thiếu thì TỰ ĐỘNG TẢI VỀ (pip install numpy). Chỉ dùng đúng một đường
    nhanh nhất; không có nhánh pure-Python dự phòng.
    """
    try:
        import numpy  # noqa: F401
        _say(f"\u2714 NumPy s\u1eb5n s\u00e0ng: {numpy.__version__}")
        return True
    except Exception:
        _say("Thi\u1ebfu NumPy \u2014 \u0111ang T\u1ef0 \u0110\u1ed8NG T\u1ea2I V\u1ec0 (pip install numpy)...")
    try:
        import subprocess
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "--upgrade", "numpy"],
            stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT,
        )
    except Exception as exc:
        _say(f"T\u1ea3i NumPy th\u1ea5t b\u1ea1i: {exc!r}")
        return False
    try:
        import importlib
        importlib.invalidate_caches()
        import numpy  # noqa: F401,F811
        _say(f"\u2714 \u0110\u00e3 c\u00e0i NumPy: {numpy.__version__}")
        return True
    except Exception as exc:
        _say(f"V\u1eabn kh\u00f4ng import \u0111\u01b0\u1ee3c NumPy sau khi c\u00e0i: {exc!r}")
        return False



def ensure_soundtouch() -> bool:
    """Bảo đảm SoundTouch native sẵn sàng nếu thư viện có mặt; fallback vẫn an toàn."""
    try:
        from Speech.native.soundtouch_setup import ensure_soundtouch as _ensure_st, install_hint
        if not _ensure_st():
            raise RuntimeError(install_hint())
        _say("✔ SoundTouch native sẵn sàng")
        return True
    except Exception as exc:
        _say(f"⚠ SoundTouch native không khả dụng (fallback pure-Python): {exc!r}")
        return False

def run_autosetup() -> None:
    ensure_decoder()
    ensure_soundtouch()
    # NumPy chỉ cần cho âm thanh (vốn đã được defer sau khung hình đầu). Prewarm
    # ở LUỒNG NỀN để KHÔNG làm chậm khởi động UI. soundtouch vẫn tự bảo đảm
    # numpy lúc tổng hợp, nên đúng đắn không phụ thuộc luồng nền này.
    try:
        import threading
        threading.Thread(target=ensure_numpy, name="ensure-numpy", daemon=True).start()
    except Exception:
        ensure_numpy()
