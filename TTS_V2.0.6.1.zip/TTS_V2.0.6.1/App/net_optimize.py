"""Tối ưu mạng cho engine TTS — AN TOÀN & CÓ THỂ KHÔI PHỤC.

Nguyên tắc an toàn:
- Chỉ chạy lệnh hệ thống khi ở Windows (os.name == 'nt'); nền tảng khác chỉ đo latency.
- Mọi thay đổi hệ thống (DNS, TCP) đều là tuỳ chỉnh CHUẨN & ĐẢO NGƯỢC được
  qua restore_network() (trả DNS về DHCP, TCP autotuning về normal).
- Không ai bảo đảm "không bao giờ hỏng mạng"; vì vậy luôn có nút Khôi Phục Mạng.
- Đổi DNS / tinh chỉnh TCP cần quyền Administrator; nếu thiếu quyền sẽ log rõ.
"""
from __future__ import annotations

import os
import socket
import subprocess
import time
from typing import Callable, List, Optional, Tuple

IS_WIN = (os.name == "nt")
_CREATE_NO_WINDOW = 0x08000000
_FAST_DNS = ["1.1.1.1", "8.8.8.8"]

# Danh sách host dự phòng (đồng bộ với turbo_tts.DEFAULT_HOSTS).
_FALLBACK_HOSTS = [
    "api15-normal-alisg.tiktokv.com",
    "api21-normal-c-alisg.tiktokv.com",
    "api21-normal-n-alisg.tiktokv.com",
    "api33-normal-alisg.tiktokv.com",
    "api24-normal.tiktokv.com",
    "api19-normal-alisg.tiktokv.com",
    "api58-normal-c-alisg.tiktokv.com",
    "api58-normal-alisg.tiktokv.com",
]

LogFn = Optional[Callable[[str], None]]


def _log(cb: LogFn, m: str) -> None:
    if callable(cb):
        try:
            cb(m)
        except Exception:
            pass


def _run(cmd: List[str], timeout: float = 12.0) -> Tuple[int, str]:
    kw = {}
    if IS_WIN:
        kw["creationflags"] = _CREATE_NO_WINDOW
    try:
        p = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=timeout, **kw)
        return p.returncode, ((p.stdout or "") + (p.stderr or "")).strip()
    except Exception as e:
        return -1, str(e)


def _needs_admin(text: str) -> bool:
    low = text.lower()
    return ("administrator" in low or "requires elevation" in low
            or "quyền" in low or "truy cập bị từ chối" in low
            or "access is denied" in low)


def default_hosts() -> List[str]:
    try:
        from Speech.turbo_tts.python.turbo_tts import DEFAULT_HOSTS, TIKTOK_HOST
        hs = [TIKTOK_HOST] + [h for h in DEFAULT_HOSTS if h != TIKTOK_HOST]
        return list(dict.fromkeys(hs))
    except Exception:
        return list(_FALLBACK_HOSTS)


def probe_host(host: str, port: int = 443, timeout: float = 2.5) -> Optional[float]:
    """Thời gian bắt tay TCP nhanh nhất (ms) qua 2 lần thử, None nếu lỗi."""
    best = None
    for _ in range(2):
        t0 = time.perf_counter()
        try:
            with socket.create_connection((host, port), timeout=timeout):
                pass
        except Exception:
            continue
        ms = (time.perf_counter() - t0) * 1000.0
        if best is None or ms < best:
            best = ms
    return best


def probe_hosts(hosts: Optional[List[str]] = None,
                on_log: LogFn = None) -> List[Tuple[str, float]]:
    hosts = hosts or default_hosts()
    scored: List[Tuple[str, float]] = []
    for h in hosts:
        ms = probe_host(h)
        if ms is None:
            _log(on_log, "    [x] %s: không kết nối được" % h)
        else:
            _log(on_log, "    [ok] %s: %.0f ms" % (h, ms))
            scored.append((h, ms))
    scored.sort(key=lambda x: x[1])
    return scored


def flush_dns(on_log: LogFn = None) -> bool:
    if not IS_WIN:
        _log(on_log, "[i] Bỏ qua flush DNS (không phải Windows).")
        return False
    rc, out = _run(["ipconfig", "/flushdns"])
    _log(on_log, "[net] Flush DNS: %s" % ("OK" if rc == 0 else "lỗi " + out))
    return rc == 0


def _active_iface() -> Optional[str]:
    rc, out = _run(["netsh", "interface", "show", "interface"])
    if rc != 0:
        return None
    for line in out.splitlines():
        low = line.lower()
        if "connected" in low and "disconnected" not in low:
            parts = line.split()
            if len(parts) >= 4:
                return " ".join(parts[3:])
    return None


def set_fast_dns(on_log: LogFn = None) -> bool:
    if not IS_WIN:
        _log(on_log, "[i] Bỏ qua đổi DNS (không phải Windows).")
        return False
    iface = _active_iface()
    if not iface:
        _log(on_log, "[net] Không tìm thấy card mạng đang kết nối.")
        return False
    rc1, o1 = _run(["netsh", "interface", "ip", "set", "dns",
                    "name=%s" % iface, "static", _FAST_DNS[0]])
    rc2, o2 = _run(["netsh", "interface", "ip", "add", "dns",
                    "name=%s" % iface, _FAST_DNS[1], "index=2"])
    if _needs_admin(o1 + o2):
        _log(on_log, "[net] !! Cần quyền Administrator để đổi DNS. Hãy chạy app bằng 'Run as administrator'.")
        return False
    _log(on_log, "[net] DNS -> %s / %s trên '%s': %s"
         % (_FAST_DNS[0], _FAST_DNS[1], iface, "OK" if rc1 == 0 else "lỗi"))
    return rc1 == 0


def tune_tcp(on_log: LogFn = None) -> bool:
    if not IS_WIN:
        _log(on_log, "[i] Bỏ qua tinh chỉnh TCP (không phải Windows).")
        return False
    cmds = [
        ["netsh", "int", "tcp", "set", "global", "autotuninglevel=normal"],
        ["netsh", "int", "tcp", "set", "global", "rss=enabled"],
        ["netsh", "int", "tcp", "set", "global", "ecncapability=enabled"],
    ]
    okc = 0
    need_admin = False
    for c in cmds:
        rc, out = _run(c)
        if rc == 0:
            okc += 1
        elif _needs_admin(out):
            need_admin = True
    if need_admin:
        _log(on_log, "[net] !! Một số tinh chỉnh TCP cần quyền Administrator.")
    _log(on_log, "[net] Tinh chỉnh TCP: %d/%d lệnh OK." % (okc, len(cmds)))
    return okc > 0


def restore_network(on_log: LogFn = None) -> bool:
    """Khôi phục mạng về mặc định: DNS -> DHCP, TCP autotuning -> normal, flush DNS."""
    if not IS_WIN:
        _log(on_log, "[i] Bỏ qua khôi phục (không phải Windows).")
        return False
    iface = _active_iface()
    if iface:
        rc, out = _run(["netsh", "interface", "ip", "set", "dns",
                        "name=%s" % iface, "dhcp"])
        if _needs_admin(out):
            _log(on_log, "[net] !! Cần quyền Administrator để khôi phục DNS.")
        else:
            _log(on_log, "[net] DNS trên '%s' -> DHCP (mặc định)." % iface)
    _run(["netsh", "int", "tcp", "set", "global", "autotuninglevel=normal"])
    flush_dns(on_log)
    _log(on_log, "[net] Đã khôi phục mạng về mặc định.")
    return True


def optimize_network(on_log: LogFn = None, aggressive: bool = False) -> List[str]:
    """Flush DNS + đo latency host; nếu aggressive: đổi DNS nhanh + tinh chỉnh TCP.

    Trả về danh sách host nhanh-nhất-trước để đẩy vào INTRO_PRO_TTS_HOSTS.
    """
    _log(on_log, "[net] === Bắt đầu tối ưu mạng ===")
    flush_dns(on_log)
    _log(on_log, "[net] Đo latency tới các host TTS...")
    scored = probe_hosts(on_log=on_log)
    fast = [h for h, _ in scored]
    if scored:
        _log(on_log, "[net] Host nhanh nhất: %s (%.0f ms)" % (scored[0][0], scored[0][1]))
    if aggressive:
        set_fast_dns(on_log)
        tune_tcp(on_log)
    _log(on_log, "[net] === Xong tối ưu mạng ===")
    return fast


def auto_pick_config(on_log: LogFn = None) -> dict:
    """Đo SỐ SESSION thực + LATENCY thực -> chọn cấu hình cao nhất khả thi.

    Trả về dict env (per_session / start / concurrency / hedge / hosts).
    """
    _log(on_log, "[auto] === Tự động test & chọn cấu hình ===")
    n = 0
    try:
        from Speech.tiktok_engine import _load_remote_session_ids
        sids = _load_remote_session_ids(on_log) or []
        n = len(dict.fromkeys(sids))
    except Exception as e:
        _log(on_log, "[auto] Không tải được session: %s" % e)
    if n <= 0:
        n = 2
        _log(on_log, "[auto] Không rõ số session, giả định %d." % n)
    else:
        _log(on_log, "[auto] Phát hiện %d Session ID." % n)

    scored = probe_hosts(on_log=on_log)
    med = scored[len(scored) // 2][1] if scored else 200.0
    _log(on_log, "[auto] Latency trung vị ~%.0f ms." % med)

    if med < 120:
        per = 40
    elif med < 250:
        per = 32
    else:
        per = 24
    ceiling = max(per, n * per)
    conc = min(512, max(64, ceiling + n * 4))
    conc = int(round(conc / 16.0)) * 16
    hedge = 300 if med < 250 else 450

    env = {
        "INTRO_PRO_TTS_PER_SESSION": per,
        "INTRO_PRO_TTS_PER_SESSION_START": per,
        "INTRO_PRO_TTS_CONCURRENCY": conc,
        "INTRO_PRO_TTS_HEDGE_MS": hedge,
    }
    fast = [h for h, _ in scored]
    if fast:
        env["INTRO_PRO_TTS_HOSTS"] = ",".join(fast)
    _log(on_log, "[auto] Trần RPS lý thuyết ~ %d (sessions %d x per %d)." % (n * per, n, per))
    _log(on_log, "[auto] Chọn: per=%d start=%d conc=%d hedge=%d." % (per, per, conc, hedge))
    return env
