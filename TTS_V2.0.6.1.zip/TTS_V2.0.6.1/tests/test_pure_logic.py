"""Headless unit tests for TTS_Pro pure-logic modules.

No Qt, no native DLLs, no network. Runnable anywhere with stdlib only.
Run with:  python3 -m pytest tests/ -q     (or)   python3 tests/test_pure_logic.py
"""
import os
import sys
import struct
import tempfile
import importlib.util

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# Isolate the on-disk audio cache BEFORE importing any Speech module so that
# every consumer (including turbo_tts) uses a throwaway directory.
_CACHE_TMP = tempfile.mkdtemp(prefix="tts_cache_test_")
os.environ["INTRO_PRO_TTS_CACHE_DIR"] = _CACHE_TMP
os.environ["INTRO_PRO_TTS_CACHE"] = "1"

# --- lightweight test runner (works with or without pytest) ------------------
_FAILURES = []
_PASSED = 0


def check(cond, msg):
    global _PASSED
    if cond:
        _PASSED += 1
    else:
        raise AssertionError(msg)


# =====================================================================
# Speech.srt_parser
# =====================================================================
from Speech import srt_parser as SP


def test_srt_time_to_ms():
    check(SP.srt_time_to_ms_raw(b"00:00:01,500") == 1500, "1.5s")
    check(SP.srt_time_to_ms_raw(b"01:02:03.250") == 3723250, "h:m:s.ms")
    check(SP.srt_time_to_ms_raw(b"00:00:00,000") == 0, "zero")
    check(SP.srt_time_to_ms_raw(b"garbage") == 0, "invalid -> 0")
    check(SP.srt_time_to_ms_raw(b"00:00:02") == 0, "missing ms -> 0 (no dot)")


def test_clean_lines():
    check(SP._clean_lines([b"<i>Hello</i>", b"world"]) == "Hello world", "strip tags")
    check(SP._clean_lines([b"{\\an8}Top", b""]) == "Top", "strip ASS tags")
    check(SP._clean_lines([b"WEBVTT", b"Real line"]) == "Real line", "drop meta")
    check(SP._clean_lines([b"  spaced   out  "]) == "spaced out", "collapse ws")


def _write(tmp, data: bytes):
    p = os.path.join(tmp, "x.srt")
    with open(p, "wb") as f:
        f.write(data)
    return p


def test_iter_srt_cues():
    srt = (b"1\n00:00:01,000 --> 00:00:02,000\nHello world\n\n"
           b"2\n00:00:03,000 --> 00:00:04,000\n<b>Second</b> cue\n\n")
    with tempfile.TemporaryDirectory() as tmp:
        p = _write(tmp, srt)
        cues = SP.parse_srt(p)
        check(len(cues) == 2, f"2 cues, got {len(cues)}")
        check(cues[0]["text"] == "Hello world", "cue0 text")
        check(cues[0]["ms"] == 1000, "cue0 ms")
        check(cues[1]["text"] == "Second cue", "cue1 text stripped")
        check(cues[1]["id"] == 2, "cue ids increment")
        check(SP.is_srt_nonempty(p) is True, "nonempty true")


def test_iter_srt_empty_and_missing():
    with tempfile.TemporaryDirectory() as tmp:
        p = _write(tmp, b"")
        check(SP.parse_srt(p) == [], "empty file -> []")
        check(SP.is_srt_nonempty(p) is False, "empty -> false")
        check(SP.is_srt_nonempty(os.path.join(tmp, "nope.srt")) is False, "missing -> false")


def test_iter_srt_webvtt_dot_times():
    vtt = b"WEBVTT\n\n00:00:01.000 --> 00:00:02.000\nDot timed\n"
    with tempfile.TemporaryDirectory() as tmp:
        p = _write(tmp, vtt)
        cues = SP.parse_srt(p)
        check(len(cues) == 1 and cues[0]["text"] == "Dot timed", "vtt dot times parse")


# =====================================================================
# Speech.wav_utils
# =====================================================================
from Speech import wav_utils as WU


def _make_wav(pcm: bytes, channels=1, rate=44100, bits=16):
    byte_rate = rate * channels * bits // 8
    block = channels * bits // 8
    return struct.pack("<4sI4s4sIHHIIHH4sI", b"RIFF", 36 + len(pcm), b"WAVE",
                       b"fmt ", 16, 1, channels, rate, byte_rate, block, bits,
                       b"data", len(pcm)) + pcm


def test_wav_meta_roundtrip():
    pcm = b"\x00\x01" * 100  # 200 bytes -> 100 frames mono16
    wav = _make_wav(pcm, channels=1, rate=48000, bits=16)
    meta = WU.wav_meta(wav)
    check(meta["channels"] == 1, "channels")
    check(meta["sample_rate"] == 48000, "rate")
    check(meta["bits_per_sample"] == 16, "bits")
    check(meta["data_size"] == 200, "data size")
    check(meta["frames"] == 100, "frames")


def test_wav_meta_invalid():
    try:
        WU.wav_meta(b"not a wav file at all........................")
        check(False, "should raise on invalid wav")
    except RuntimeError:
        check(True, "raised")


def test_wav_header_fields():
    hdr = WU.wav_header({"channels": 2, "sample_rate": 44100, "bits_per_sample": 16}, 4000)
    check(hdr[:4] == b"RIFF", "riff")
    check(hdr[8:12] == b"WAVE", "wave")
    check(struct.unpack_from("<I", hdr, 4)[0] == 36 + 4000, "riff size")
    check(struct.unpack_from("<H", hdr, 22)[0] == 2, "channels field")
    # header parseable by wav_meta when combined with data
    meta = WU.wav_meta(hdr + b"\x00" * 4000)
    check(meta["channels"] == 2 and meta["data_size"] == 4000, "header->meta")


# =====================================================================
# Speech.soundtouch (option helpers, pure math + WAV header)
# =====================================================================
from Speech import soundtouch as ST


def test_pitch_ratio():
    check(abs(ST.pitch_ratio(0, 0) - 1.0) < 1e-9, "0 semitones -> 1.0")
    check(abs(ST.pitch_ratio(12, 0) - 2.0) < 1e-9, "+12 semitones -> 2.0")
    check(abs(ST.pitch_ratio(-12, 0) - 0.5) < 1e-9, "-12 semitones -> 0.5")
    check(abs(ST.pitch_ratio(0, 1200) - 2.0) < 1e-9, "1200 cents -> octave")


def test_normalize_options():
    o = ST.normalize_options(None)
    check(o == {"semitones": 0, "cents": 0, "speed": 1, "rate": 1}, "defaults")
    o2 = ST.normalize_options({"tempoPercent": 50})
    check(abs(o2["speed"] - 1.5) < 1e-9, "tempoPercent -> speed")
    o3 = ST.normalize_options({"speed": 2})
    check(o3["speed"] == 2, "explicit speed wins")


def test_is_no_op():
    check(ST.is_no_op(None) is True, "none -> no-op")
    check(ST.is_no_op({"semitones": 0, "speed": 1, "rate": 1}) is True, "identity no-op")
    check(ST.is_no_op({"semitones": 4}) is False, "pitch shift not no-op")
    check(ST.is_no_op({"speed": 1.5}) is False, "speed change not no-op")


def test_pcm16_wav_helpers():
    pcm = b"\x10\x00" * 50
    wav = ST.pcm16_to_wav(pcm, channels=1, sampleRate=24000)
    meta = ST._wav_meta_local(wav)
    check(meta["channels"] == 1, "st channels")
    check(meta["sampleRate"] == 24000, "st rate")
    check(meta["bitsPerSample"] == 16, "st bits")
    check(meta["dataSize"] == len(pcm), "st data size")


def test_process_wav_buffer_noop_passthrough():
    # no-op options must NOT require the native DLL; returns identical bytes
    pcm = b"\x00\x01" * 20
    wav = ST.pcm16_to_wav(pcm, 1, 44100)
    out = ST.process_wav_buffer(wav, {"semitones": 0, "speed": 1})
    check(bytes(out) == bytes(wav), "no-op returns identical wav without DLL")


# =====================================================================
# Speech.audio_cache (disk cache; isolated temp dir)
# =====================================================================
def test_audio_cache_roundtrip():
    import random as _r
    from Speech import audio_cache as AC
    uniq = "unit-test-%d-%d" % (os.getpid(), _r.getrandbits(48))
    k1 = AC.cache_key(uniq, "BV074_streaming")
    k2 = AC.cache_key(uniq, "BV074_streaming")
    k3 = AC.cache_key(uniq, "other_voice")
    check(k1 == k2, "key deterministic")
    check(k1 != k3, "key varies by voice")
    check(len(k1) == 64, "sha256 hex len")
    check(AC.get_audio(k1) is None, "miss before put (unique key)")
    AC.put_audio(k1, b"AUDIODATA" * 10)
    check(AC.get_audio(k1) == b"AUDIODATA" * 10, "hit after put")


# =====================================================================
# Speech.tiktok_engine (session-id cleaning + voice map, no network)
# =====================================================================
from Speech import tiktok_engine as TT


def test_clean_session_id():
    valid = "a" * 32  # 32 hex-ish; _VALID_SID_RE should accept alnum runs
    check(TT._clean_session_id('"' + valid + '"') == valid, "strip quotes")
    check(TT._clean_session_id("sessionid=" + valid) == valid, "strip key=")
    check(TT._clean_session_id("sessionid=" + valid + "; path=/") == valid, "cookie form")
    hexid = "0123456789abcdef0123456789abcdef"
    check(TT._clean_session_id("noise " + hexid + " noise") == hexid, "extract 32-hex")
    check(TT._clean_session_id("") == "", "empty -> empty")
    check(TT._clean_session_id(None) == "", "none -> empty")


def test_is_valid_sid():
    check(TT._is_valid_sid("0123456789abcdef0123456789abcdef") is True, "valid hex sid")
    check(TT._is_valid_sid("") is False, "empty invalid")
    check(TT._is_valid_sid("short") is False, "too short invalid")


def test_voice_map_present():
    check(isinstance(TT.TIKTOK_VOICE_MAP, dict), "voice map is dict")
    check(len(TT.TIKTOK_VOICE_MAP) >= 1, "voice map non-empty")
    check(all(isinstance(v, str) and v for v in TT.TIKTOK_VOICE_MAP.values()), "voice ids are strings")


def test_keypool_rotation():
    ids = ["0123456789abcdef0123456789abcde" + c for c in "01"]
    pool = TT.KeyPool(ids)
    check(pool.size == 2, "pool size")
    picks = {pool.pick() for _ in range(10)}
    check(picks.issubset(set(ids)), "picks come from pool")
    first = pool.pick()
    pool.report_fail(first)  # should not crash
    pool.report_ok(first)
    check(True, "report ok/fail callable")


# =====================================================================
# Speech.turbo_tts (pure chunking / body / hosts / limiter / ranker)
# =====================================================================
def _load_turbo():
    path = os.path.join(ROOT, "Speech", "turbo_tts", "python", "turbo_tts.py")
    spec = importlib.util.spec_from_file_location("turbo_tts_under_test", path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["turbo_tts_under_test"] = mod
    spec.loader.exec_module(mod)
    return mod


TB = _load_turbo()


def test_chunk_text_basic():
    check(TB.chunk_text("") == [], "empty -> []")
    check(TB.chunk_text("   ") == [], "whitespace -> []")
    one = TB.chunk_text("Hello world.")
    check(one == ["Hello world."], f"single sentence kept, got {one}")


def test_chunk_text_splits_long():
    sentence = "word " * 200  # ~1000 bytes, must split at max_len=300
    chunks = TB.chunk_text(sentence, max_len=300)
    check(len(chunks) >= 2, "long text splits into multiple chunks")
    check(all(TB._text_len(c) <= 300 for c in chunks), "every chunk within max_len bytes")
    # no content lost (ignoring whitespace)
    joined = "".join(chunks).replace(" ", "")
    check(joined == sentence.replace(" ", ""), "no words dropped when splitting")


def test_chunk_text_unicode_bytes():
    # Vietnamese multibyte: length must be measured in UTF-8 bytes
    vi = "Xin ch\u00e0o c\u00e1c b\u1EA1n. " * 40
    chunks = TB.chunk_text(vi, max_len=120)
    check(all(TB._text_len(c) <= 120 for c in chunks), "unicode chunks within byte budget")
    check(len(chunks) >= 2, "unicode long text splits")


def test_body_and_prefix():
    body = TB._body("BV074_streaming", "hi there")
    check(b"text_speaker=BV074_streaming" in body, "voice in body")
    check(b"req_text=hi%20there" in body, "url-encoded text")
    check(body.endswith(TB.BODY_SUFFIX), "body suffix appended")


def test_hosts_dedup_and_primary_first():
    hs = TB._hosts(["custom.example.com", TB.TIKTOK_HOST, "custom.example.com"])
    check(hs[0] == TB.TIKTOK_HOST, "primary host first")
    check(len(hs) == len(set(hs)), "hosts deduped")
    check("custom.example.com" in hs, "custom host retained")


def test_ranker_pick_and_done():
    r = TB._Ranker(["h1", "h2", "h3"])
    picked = r.pick()
    check(picked in ("h1", "h2", "h3"), "pick returns a host")
    r.done(picked, latency=50.0, ok=True)
    check(r.ewma[picked] is not None, "ewma recorded")
    # failing a host max_fails times marks it dead
    for _ in range(5):
        r.done("h2", ok=False)
    check(r.dead["h2"] > 0, "repeated failures mark host dead")


def test_metrics_snapshot_rps():
    m = TB._Metrics()
    for _ in range(10):
        m.rec(ok=True, latency=20.0, nbytes=100)
    snap = m.snapshot()
    check(snap["ok"] == 10, "ok counted")
    check(snap["rps_ok"] > 0, "rps computed")
    check(snap["p50_ms"] == 20.0, "p50 latency")
    check(snap["bytes_audio"] == 1000, "bytes summed")


# =====================================================================
# main runner
# =====================================================================
def _all_tests():
    g = globals()
    return [(n, g[n]) for n in sorted(g) if n.startswith("test_") and callable(g[n])]


def main():
    failures = []
    for name, fn in _all_tests():
        try:
            fn()
            print(f"  PASS  {name}")
        except Exception as e:  # noqa
            failures.append((name, e))
            print(f"  FAIL  {name}: {e}")
    total = len(_all_tests())
    print(f"\n{total - len(failures)}/{total} test functions passed; {_PASSED} assertions OK")
    if failures:
        print("FAILURES:")
        for n, e in failures:
            print(f"  - {n}: {e}")
        sys.exit(1)
    print("ALL TESTS PASSED")


if __name__ == "__main__":
    main()
