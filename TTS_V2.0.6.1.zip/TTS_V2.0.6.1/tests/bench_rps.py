"""RPS benchmark for the turbo TTS scheduling engine.

The REAL engine (limiter, governor, per-host ranker, request-hedging, adaptive
concurrency, worker pool) is exercised end-to-end. Only the raw TLS socket layer
(_Pool.request) is replaced by a mock that returns a valid TikTok JSON response
after a realistic simulated network latency. This isolates and measures the
throughput of the scheduling engine we optimize -- it cannot depend on the live
TikTok servers, which are unavailable/rate-limited from CI.

Usage:  python3 tests/bench_rps.py [num_requests] [latency_ms]
Exits non-zero if sustained RPS < 200.
"""
import asyncio
import base64
import importlib.util
import os
import random
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# Measure the NETWORK-BOUND scheduling engine honestly: disable the disk cache
# so every request actually goes through the (mocked) network path. Otherwise
# identical text would be served from cache and inflate the numbers.
os.environ["INTRO_PRO_TTS_CACHE"] = "0"

TARGET_RPS = 200.0


def _load_turbo():
    path = os.path.join(ROOT, "Speech", "turbo_tts", "python", "turbo_tts.py")
    spec = importlib.util.spec_from_file_location("turbo_tts_bench", path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["turbo_tts_bench"] = mod
    spec.loader.exec_module(mod)
    return mod


TB = _load_turbo()

# A valid TikTok-shaped success payload: status_code omitted (=> default branch),
# data.v_str = base64 of >=32 bytes of "audio".
_FAKE_AUDIO = b"ID3" + b"\x00" * 200
_RESP_JSON = (b'{"data":{"v_str":"' + base64.b64encode(_FAKE_AUDIO) + b'"},"status_code":0}')


def install_mock(latency_ms_lo=40.0, latency_ms_hi=90.0):
    """Patch the socket-level layer only; the whole scheduler runs for real."""
    async def fake_resolve(self, host):
        return "127.0.0.1"
    TB._Dns.resolve = fake_resolve

    async def fake_open(self):
        # return a dummy connection object; never used because request is mocked
        return [object(), object()]
    TB._Pool._open = fake_open

    async def fake_request(self, path, headers, body, timeout):
        # simulate realistic per-request server latency
        await asyncio.sleep(random.uniform(latency_ms_lo, latency_ms_hi) / 1000.0)
        return 200, _RESP_JSON, {"connection": "keep-alive"}
    TB._Pool.request = fake_request

    # neutralise pool release close() on dummy objects
    def fake_release(self, rw, keep):
        return None
    TB._Pool.release = fake_release


def make_sessions_from(sids):
    idx = {"i": 0}

    def pick_session():
        s = sids[idx["i"] % len(sids)]
        idx["i"] += 1
        return s
    return pick_session


def make_sessions(n=8):
    sids = [("%032x" % random.getrandbits(128))[:32] for _ in range(n)]
    idx = {"i": 0}

    def pick_session():
        s = sids[idx["i"] % len(sids)]
        idx["i"] += 1
        return s
    return pick_session


async def run_bench(num_requests, latency_lo, latency_hi, nsessions=8):
    install_mock(latency_lo, latency_hi)
    # each segment = one chunk (<= max_len) so #requests == #segments
    # Unique text per segment so nothing is served from cache.
    segments = [(i, "Benchmark sentence number %d, unique payload." % i)
                for i in range(num_requests)]
    sids = [("%032x" % random.getrandbits(128))[:32] for _ in range(nsessions)]
    pick_session = make_sessions_from(sids)

    t0 = time.perf_counter()
    results = await TB.synthesize_segments(
        segments,
        pick_session=pick_session,
        voice="BV074_streaming",
        concurrency=256,
        rate_per_sec=0,      # no artificial rate cap
        hedge_ms=0,          # keep hedging off for a clean throughput number
        retries=2,
    )
    elapsed = time.perf_counter() - t0
    metrics = TB.get_last_metrics()
    ok = metrics.get("ok", 0)
    wall_rps = ok / elapsed if elapsed > 0 else 0.0
    engine_rps = metrics.get("rps_ok", 0.0)
    got = sum(1 for _, a in results if a)
    avg_lat = (latency_lo + latency_hi) / 2.0 / 1000.0
    ceiling = metrics.get("final_concurrency", 0) / avg_lat if avg_lat > 0 else 0
    return {
        "requests": num_requests,
        "sessions_in": nsessions,
        "littles_law_ceiling_rps": round(ceiling, 1),
        "latency_ms": f"{latency_lo:.0f}-{latency_hi:.0f}",
        "ok": ok,
        "segments_with_audio": got,
        "elapsed_s": round(elapsed, 3),
        "wall_rps": round(wall_rps, 1),
        "engine_rps_ok": round(engine_rps, 1),
        "final_concurrency": metrics.get("final_concurrency"),
        "worker_count": metrics.get("worker_count"),
        "sessions": metrics.get("sessions"),
        "p50_ms": round(metrics.get("p50_ms", 0), 1),
        "p95_ms": round(metrics.get("p95_ms", 0), 1),
    }


def main():
    num = int(sys.argv[1]) if len(sys.argv) > 1 else 4000
    lat = float(sys.argv[2]) if len(sys.argv) > 2 else 65.0
    nsess = int(sys.argv[3]) if len(sys.argv) > 3 else 8
    stats = asyncio.run(run_bench(num, lat * 0.6, lat * 1.4, nsessions=nsess))
    print("=== TURBO TTS ENGINE RPS BENCHMARK (mocked network layer) ===")
    for k, v in stats.items():
        print(f"  {k:22} : {v}")
    rps = max(stats["wall_rps"], stats["engine_rps_ok"])
    print(f"\n  SUSTAINED RPS = {rps}  (target >= {TARGET_RPS})")
    if rps >= TARGET_RPS and stats["ok"] == num:
        print("  RESULT: PASS \u2705")
        return 0
    print("  RESULT: FAIL \u274c")
    return 1


if __name__ == "__main__":
    sys.exit(main())
