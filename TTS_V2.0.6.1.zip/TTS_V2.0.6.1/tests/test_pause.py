"""Headless test for the pause/resume primitive of the turbo TTS engine.

We cannot launch the PyQt6 GUI in CI, but the actual freeze logic lives in the
async worker loop (turbo_tts._run). This test drives that real loop with the
same socket-level mock used by bench_rps, then:

  1. sets the pause_event mid-run and asserts progress FREEZES (no new segments
     complete while paused),
  2. clears the pause_event and asserts the job RESUMES and completes fully.

Run:  python3 tests/test_pause.py
"""
import asyncio
import os
import sys
import threading
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# Disable disk cache so every request goes through the (mocked) network path;
# otherwise a cache hit would make "pause" meaningless.
os.environ["INTRO_PRO_TTS_CACHE"] = "0"
# Pin the engine's per-session limits for this test so it stays independent of
# the app's (now extreme) production defaults. This keeps the pause window wide
# enough to observe a deterministic freeze regardless of shipped defaults.
os.environ["INTRO_PRO_TTS_PER_SESSION"] = "8"
os.environ["INTRO_PRO_TTS_PER_SESSION_START"] = "8"

from tests.bench_rps import TB, install_mock, make_sessions_from  # noqa: E402


async def _drive():
    # Slow, steady latency so the run lasts long enough to observe a freeze.
    install_mock(60.0, 90.0)

    num = 400
    segments = [(i, "Pause test sentence %d unique." % i) for i in range(num)]
    sids = [("%032x" % i)[:32] for i in range(1, 5)]  # 4 sessions
    pick_session = make_sessions_from(sids)

    progress = {"done": 0}

    def progress_cb(done, total):
        progress["done"] = done

    pause_event = threading.Event()
    cancel_event = threading.Event()

    task = asyncio.create_task(TB.synthesize_segments(
        segments,
        pick_session=pick_session,
        voice="BV074_streaming",
        concurrency=256,
        rate_per_sec=0,
        hedge_ms=0,
        progress_cb=progress_cb,
        cancel_event=cancel_event,
        pause_event=pause_event,
    ))

    # Let it run a bit, then pause.
    await asyncio.sleep(0.35)
    before = progress["done"]
    assert before > 0, "engine made no progress before pause (test setup issue)"
    assert before < num, "job finished before we could pause (increase num/latency)"
    pause_event.set()

    # Give in-flight requests time to drain, then sample twice while paused.
    await asyncio.sleep(0.35)
    frozen_a = progress["done"]
    await asyncio.sleep(0.35)
    frozen_b = progress["done"]

    # While paused, no NEW dispatch happens -> progress must not keep climbing.
    assert frozen_a == frozen_b, (
        "progress advanced while paused: %d -> %d" % (frozen_a, frozen_b))
    assert frozen_b < num, "job completed while paused (freeze failed)"
    assert not task.done(), "task finished while paused (freeze failed)"

    # Resume -> must run to completion.
    pause_event.clear()
    results = await asyncio.wait_for(task, timeout=30.0)
    assert progress["done"] == num, "did not finish after resume: %d/%d" % (
        progress["done"], num)
    assert len(results) == num
    good = sum(1 for _, a in results if a)
    assert good == num, "some segments missing after resume: %d/%d" % (good, num)

    return before, frozen_b, num


async def _drive_cancel_while_paused():
    """A paused job must still be cancellable (button 'Huy' fallback / close)."""
    install_mock(60.0, 90.0)
    segments = [(i, "Cancel while paused %d." % i) for i in range(400)]
    sids = [("%032x" % i)[:32] for i in range(1, 5)]
    pick_session = make_sessions_from(sids)
    pause_event = threading.Event()
    cancel_event = threading.Event()
    task = asyncio.create_task(TB.synthesize_segments(
        segments, pick_session=pick_session, voice="BV074_streaming",
        concurrency=256, rate_per_sec=0, hedge_ms=0,
        cancel_event=cancel_event, pause_event=pause_event))
    await asyncio.sleep(0.3)
    pause_event.set()
    await asyncio.sleep(0.2)
    cancel_event.set()
    pause_event.clear()  # cancel() clears pause in real code; mimic it here too
    await asyncio.wait_for(task, timeout=10.0)
    return True


def main():
    t0 = time.perf_counter()
    before, frozen, num = asyncio.run(_drive())
    print("[ok] freeze: %d done before pause, held at %d while paused, "
          "resumed to %d/%d" % (before, frozen, num, num))
    asyncio.run(_drive_cancel_while_paused())
    print("[ok] cancel-while-paused: worker exited cleanly")
    print("ALL PAUSE TESTS PASSED in %.2fs" % (time.perf_counter() - t0))


if __name__ == "__main__":
    main()
